<?php
// ======================================================
// NEW ORDER - REDESIGNED WITH IMAGES (FIXED)
// ======================================================

/**
 * @see requireCashier()
 * @see sanitize()
 * @see getAllCategories()
 * @see SITE_URL
 */

require_once '../../config/database.php';
requireCashier();

// GCash payment details (QR code / number) set by the admin in System Settings
$pdo = getDBConnection();
$gcashSettings = ['gcash_qr_image' => '', 'gcash_number' => '', 'gcash_name' => ''];
$discountRates = ['senior_discount_rate' => 20.00, 'pwd_discount_rate' => 20.00];
try {
    $stmt = $pdo->query("SELECT gcash_qr_image, gcash_number, gcash_name, senior_discount_rate, pwd_discount_rate FROM settings WHERE id = 1");
    $row = $stmt->fetch();
    if ($row) {
        $gcashSettings = array_merge($gcashSettings, $row);
        if ($row['senior_discount_rate'] !== null && $row['senior_discount_rate'] !== '') {
            $discountRates['senior_discount_rate'] = (float)$row['senior_discount_rate'];
        }
        if ($row['pwd_discount_rate'] !== null && $row['pwd_discount_rate'] !== '') {
            $discountRates['pwd_discount_rate'] = (float)$row['pwd_discount_rate'];
        }
    }
} catch (PDOException $e) {
    // Columns may not exist yet if the migration hasn't been run - fail silently,
    // GCash will just show the reference number field without a QR code, and
    // discounts will default to 20%.
}
$gcashQrFile = $gcashSettings['gcash_qr_image'];
$gcashQrExists = !empty($gcashQrFile) && file_exists('../../assets/images/payment/' . $gcashQrFile);

$orderType = isset($_GET['type']) ? $_GET['type'] : 'dine_in';
if (!in_array($orderType, ['dine_in', 'take_out'])) { 
    $orderType = 'dine_in'; 
}

// Start session to store cart
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Initialize cart in session if not exists
if (!isset($_SESSION['pos_cart'])) {
    $_SESSION['pos_cart'] = [];
}

// Get current cart from session
$cart = $_SESSION['pos_cart'];

// Get the current order type from session
if (!isset($_SESSION['pos_order_type'])) {
    $_SESSION['pos_order_type'] = $orderType;
}

if ($_SESSION['pos_order_type'] !== $orderType) {
    $_SESSION['pos_order_type'] = $orderType;
}

$currentOrderType = $_SESSION['pos_order_type'];

if (isset($_GET['switch']) && $_GET['switch'] === 'true') {
    $_SESSION['pos_order_type'] = $orderType;
    $currentOrderType = $orderType;
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'add_to_cart') {
        $item_id = (int)$_POST['item_id'];
        $name = sanitize($_POST['name']);
        $price = (float)$_POST['price'];
        $stock = (int)$_POST['stock'];
        $quantity = (int)$_POST['quantity'];
        $image = sanitize($_POST['image'] ?? '');
        
        $found = false;
        foreach ($_SESSION['pos_cart'] as &$item) {
            if ($item['id'] === $item_id) {
                if ($item['quantity'] + $quantity <= $stock) {
                    $item['quantity'] += $quantity;
                } else {
                    echo json_encode(['success' => false, 'error' => 'Not enough stock!']);
                    exit;
                }
                $found = true;
                break;
            }
        }
        if (!$found) {
            if ($quantity <= $stock) {
                $_SESSION['pos_cart'][] = [
                    'id' => $item_id,
                    'name' => $name,
                    'price' => $price,
                    'quantity' => $quantity,
                    'stock' => $stock,
                    'image' => $image
                ];
            } else {
                echo json_encode(['success' => false, 'error' => 'Not enough stock!']);
                exit;
            }
        }
        
        echo json_encode(['success' => true, 'cart' => $_SESSION['pos_cart']]);
        exit;
    }
    
    if ($_POST['action'] === 'update_quantity') {
        $index = (int)$_POST['index'];
        $quantity = (int)$_POST['quantity'];
        if (isset($_SESSION['pos_cart'][$index])) {
            if ($quantity <= 0) {
                array_splice($_SESSION['pos_cart'], $index, 1);
            } elseif ($quantity <= $_SESSION['pos_cart'][$index]['stock']) {
                $_SESSION['pos_cart'][$index]['quantity'] = $quantity;
            } else {
                echo json_encode(['success' => false, 'error' => 'Not enough stock!', 'cart' => $_SESSION['pos_cart']]);
                exit;
            }
        }
        echo json_encode(['success' => true, 'cart' => $_SESSION['pos_cart']]);
        exit;
    }
    
    if ($_POST['action'] === 'remove_from_cart') {
        $index = (int)$_POST['index'];
        if (isset($_SESSION['pos_cart'][$index])) {
            array_splice($_SESSION['pos_cart'], $index, 1);
        }
        echo json_encode(['success' => true, 'cart' => $_SESSION['pos_cart']]);
        exit;
    }
    
    if ($_POST['action'] === 'clear_cart') {
        $_SESSION['pos_cart'] = [];
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'get_cart') {
        echo json_encode(['success' => true, 'cart' => $_SESSION['pos_cart'], 'order_type' => $_SESSION['pos_order_type']]);
        exit;
    }
}

$categories = getAllCategories();

include '../../includes/header.php';
?>

<style>
/* ======================================================
   MODERN RESTAURANT MENU STYLES
   ====================================================== */

/* Page Layout */
.pos-container {
    display: grid;
    grid-template-columns: 1fr 380px;
    gap: 24px;
    max-width: 1400px;
    margin: 0 auto;
}

/* Menu Section */
.pos-menu {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
    padding: 20px;
}

/* Category Tabs */
.pos-categories {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 20px;
    padding-bottom: 16px;
    border-bottom: 2px solid #f0f0f0;
}

.pos-category-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    width: 84px;
    padding: 12px 8px 10px;
    border: 1px solid #eef0f2;
    border-radius: 16px;
    background: #fff;
    cursor: pointer;
    font-family: 'Poppins', sans-serif;
    font-size: 0.72rem;
    font-weight: 600;
    color: #666;
    transition: all 0.25s ease;
    box-shadow: 0 2px 6px rgba(0,0,0,0.04);
}

.pos-category-icon {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.05rem;
    background: rgba(44, 95, 45, 0.1);
    color: var(--primary);
    transition: all 0.25s ease;
}

/* A little color variety across the tiles, like the reference board */
.pos-category-icon img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 12px;
}

.pos-category-btn:nth-child(6n+2) .pos-category-icon { background: rgba(230, 126, 34, 0.12); color: #e67e22; }
.pos-category-btn:nth-child(6n+3) .pos-category-icon { background: rgba(41, 128, 185, 0.12); color: #2980b9; }
.pos-category-btn:nth-child(6n+4) .pos-category-icon { background: rgba(155, 89, 182, 0.12); color: #9b59b6; }
.pos-category-btn:nth-child(6n+5) .pos-category-icon { background: rgba(211, 84, 0, 0.12); color: #d35400; }
.pos-category-btn:nth-child(6n+6) .pos-category-icon { background: rgba(22, 160, 133, 0.12); color: #16a085; }

.pos-category-label {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
}

.pos-category-btn:hover {
    border-color: var(--primary);
    color: var(--primary);
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(0,0,0,0.08);
}

.pos-category-btn.active {
    border-color: var(--primary);
    background: var(--primary);
    color: #fff;
    box-shadow: 0 6px 16px rgba(44, 95, 45, 0.3);
}

.pos-category-btn.active .pos-category-icon {
    background: rgba(255,255,255,0.22);
    color: #fff;
}

/* Category tiles with an uploaded picture: image fills the whole tile,
   label sits as a readable overlay at the bottom (instead of the small
   icon + label layout used for tiles without a picture). */
.pos-category-btn.has-image {
    position: relative;
    width: 96px;
    height: 96px;
    padding: 0;
    overflow: hidden;
    justify-content: flex-end;
}

.pos-category-cover {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.pos-category-label-overlay {
    position: relative;
    z-index: 1;
    width: 100%;
    padding: 22px 6px 8px;
    background: linear-gradient(180deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.72) 100%);
    color: #fff;
    text-shadow: 0 1px 3px rgba(0,0,0,0.5);
    border-radius: 0 0 15px 15px;
}

.pos-category-btn.has-image.active {
    box-shadow: 0 0 0 3px var(--primary), 0 6px 16px rgba(44, 95, 45, 0.35);
}

.pos-category-btn.has-image.active .pos-category-label-overlay {
    background: linear-gradient(180deg, rgba(44,95,45,0) 0%, rgba(44,95,45,0.85) 100%);
}

/* Menu Items Grid */
.pos-items {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 16px;
    max-height: 600px;
    overflow-y: auto;
    padding: 4px;
    min-height: 200px;
}

/* Item Card - Modern Design */
.pos-item-card {
    background: #fff;
    border-radius: 16px;
    border: 1px solid #eef0f2;
    overflow: hidden;
    cursor: pointer;
    transition: all 0.25s ease;
    position: relative;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.pos-item-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 10px 28px rgba(0,0,0,0.14);
    border-color: var(--primary);
}

.pos-item-card:active {
    transform: scale(0.97);
}

.pos-item-card .item-image {
    width: 100%;
    height: 140px;
    object-fit: cover;
    background: #f0f2f5;
}

.pos-item-card .item-image-placeholder {
    width: 100%;
    height: 140px;
    background: linear-gradient(135deg, #f0f2f5, #e8eaed);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2.5rem;
    color: #ccc;
}

.pos-item-card .item-info {
    padding: 12px 14px;
}

.pos-item-card .item-name {
    font-size: 0.95rem;
    font-weight: 600;
    color: var(--text-dark);
    margin-bottom: 4px;
    display: -webkit-box;
   -webkit-line-clamp: 2;
line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.pos-item-card .item-price {
    font-size: 1.05rem;
    font-weight: 700;
    color: var(--primary);
}

.pos-item-card .item-stock {
    font-size: 0.7rem;
    color: var(--text-light);
    margin-top: 4px;
}

.pos-item-card .item-stock .in-stock {
    color: #27ae60;
}
.pos-item-card .item-stock .low-stock {
    color: #f39c12;
}
.pos-item-card .item-stock .out-of-stock {
    color: #e74c3c;
}

.pos-item-card .item-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 0.65rem;
    font-weight: 600;
    background: rgba(0,0,0,0.7);
    color: #fff;
}

.pos-item-card .item-badge.popular {
    background: #f39c12;
}

.pos-item-card .item-badge.new {
    background: #2ecc71;
}

.pos-item-card .item-badge.low-stock {
    background: #e74c3c;
}

.pos-item-card.out-of-stock {
    opacity: 0.6;
    cursor: not-allowed;
}

.pos-item-card.out-of-stock:hover {
    transform: none;
    box-shadow: none;
}

.pos-item-card .item-add-hint {
    position: absolute;
    bottom: 8px;
    right: 10px;
    background: var(--primary);
    color: #fff;
    border: none;
    border-radius: 50%;
    width: 32px;
    height: 32px;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 10px rgba(44, 95, 45, 0.3);
    opacity: 0;
    transform: scale(0.8);
}

.pos-item-card:hover .item-add-hint {
    opacity: 1;
    transform: scale(1);
}

.pos-item-card .item-add-hint:hover {
    transform: scale(1.1);
    background: var(--primary-dark);
}

/* Cart Section */
.pos-cart {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
    padding: 20px;
    display: flex;
    flex-direction: column;
    max-height: 700px;
    position: sticky;
    top: 90px;
}

.pos-cart-header {
    font-weight: 600;
    font-size: 1.1rem;
    padding-bottom: 12px;
    border-bottom: 2px solid #f0f0f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.pos-cart-header .cart-count {
    background: var(--primary);
    color: #fff;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 0.75rem;
}

.pos-cart-items {
    flex: 1;
    overflow-y: auto;
    padding: 8px 0;
}

/* Cart Item */
.cart-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px;
    margin-bottom: 8px;
    border-radius: 12px;
    border: 1px solid #f2f3f5;
    background: #fbfbfc;
    transition: all 0.25s;
}

.cart-item:hover {
    background: #fff;
    border-color: #e4e8e5;
    box-shadow: 0 3px 10px rgba(0,0,0,0.06);
}

.cart-item .cart-item-image {
    width: 48px;
    height: 48px;
    border-radius: 10px;
    object-fit: cover;
    background: #f0f2f5;
    flex-shrink: 0;
    box-shadow: 0 1px 4px rgba(0,0,0,0.08);
}

.cart-item .cart-item-image-placeholder {
    width: 48px;
    height: 48px;
    border-radius: 10px;
    background: #f0f2f5;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    color: #ccc;
    flex-shrink: 0;
}

.cart-item .item-details {
    flex: 1;
}

.cart-item .item-name {
    font-size: 0.85rem;
    font-weight: 500;
    color: var(--text-dark);
}

.cart-item .item-qty-price {
    font-size: 0.75rem;
    color: var(--text-light);
}

/* Cart item quantity stepper (edit qty directly in cart) */
.cart-qty-control {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 4px;
}

.cart-qty-control button {
    width: 22px;
    height: 22px;
    border-radius: 6px;
    border: 1px solid #ddd;
    background: #f8f9fa;
    color: var(--text-dark);
    font-size: 0.85rem;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    line-height: 1;
    padding: 0;
    transition: background 0.2s;
}

.cart-qty-control button:hover {
    background: var(--primary);
    color: #fff;
    border-color: var(--primary);
}

.cart-qty-control button:disabled {
    opacity: 0.4;
    cursor: not-allowed;
}

.cart-qty-control .cart-qty-num {
    min-width: 20px;
    text-align: center;
    font-size: 0.8rem;
    font-weight: 600;
}

/* Floating "Go to Cart" button */
.go-to-cart-btn {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 900;
    background: var(--primary);
    color: #fff;
    border: none;
    border-radius: 50px;
    padding: 14px 22px;
    font-size: 0.9rem;
    font-weight: 600;
    box-shadow: 0 4px 16px rgba(44,95,45,0.35);
    cursor: pointer;
    display: none;
    align-items: center;
    gap: 10px;
    transition: transform 0.2s, background 0.2s;
}

.go-to-cart-btn.show {
    display: inline-flex;
}

.go-to-cart-btn:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
}

.go-to-cart-btn .go-to-cart-badge {
    background: rgba(255,255,255,0.25);
    padding: 2px 9px;
    border-radius: 20px;
    font-size: 0.78rem;
}

.pos-cart.highlight-cart {
    animation: cartHighlightPulse 1s ease;
}

@keyframes cartHighlightPulse {
    0% { box-shadow: 0 2px 12px rgba(0,0,0,0.08); }
    30% { box-shadow: 0 0 0 4px rgba(44,95,45,0.35); }
    100% { box-shadow: 0 2px 12px rgba(0,0,0,0.08); }
}

.cart-item .item-subtotal {
    font-weight: 600;
    color: var(--primary);
    font-size: 0.9rem;
}

.cart-item .remove-btn {
    background: none;
    border: none;
    color: #ccc;
    cursor: pointer;
    font-size: 0.85rem;
    width: 26px;
    height: 26px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: all 0.25s;
}

.cart-item .remove-btn:hover {
    color: #fff;
    background: var(--accent);
}

/* Cart Footer */
.pos-cart-footer {
    border-top: 2px solid #f0f0f0;
    padding: 14px 14px 4px;
    margin: 4px -6px 0;
    background: linear-gradient(180deg, #f7faf7, #fff);
    border-radius: 0 0 14px 14px;
}

.cart-total {
    display: flex;
    justify-content: space-between;
    font-size: 1.2rem;
    font-weight: 700;
    margin-bottom: 8px;
}

.cart-total .total-amount {
    color: var(--primary);
}

.cart-fee {
    display: flex;
    justify-content: space-between;
    font-size: 0.85rem;
    color: var(--text-light);
    margin-bottom: 4px;
}

.pos-action-buttons {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    margin-top: 12px;
}

.btn-checkout {
    background: var(--primary);
    color: #fff;
    grid-column: span 2;
    padding: 14px;
    border: none;
    border-radius: 14px;
    font-weight: 600;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s;
    font-family: 'Poppins', sans-serif;
}

.btn-checkout:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(44, 95, 45, 0.3);
}

.btn-checkout:active {
    transform: scale(0.98);
}

.btn-clear {
    background: #fee;
    color: var(--accent);
    padding: 10px;
    border: none;
    border-radius: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
    font-family: 'Poppins', sans-serif;
}

.btn-clear:hover {
    background: #fdd;
}

/* Empty Cart */
.empty-cart {
    text-align: center;
    padding: 40px 20px;
    color: var(--text-light);
}

.empty-cart i {
    font-size: 3rem;
    display: block;
    margin-bottom: 12px;
    color: #ddd;
}

.empty-cart p {
    font-size: 0.9rem;
}

/* Order Type Badge */
.order-type-badge {
    display: inline-block;
    padding: 4px 16px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.85rem;
}
.order-type-badge.dine-in {
    background: #cce5ff;
    color: #004085;
}
.order-type-badge.take-out {
    background: #fff3cd;
    color: #856404;
}

.cart-count-badge {
    background: #e74c3c;
    color: white;
    border-radius: 50%;
    padding: 2px 8px;
    font-size: 0.7rem;
    font-weight: 600;
    margin-left: 4px;
}

/* Quantity Modal */
.quantity-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 10000;
    align-items: center;
    justify-content: center;
    backdrop-filter: blur(4px);
}
.quantity-modal.show {
    display: flex;
}
.quantity-modal-content {
    background: #fff;
    border-radius: 20px;
    padding: 32px;
    max-width: 380px;
    width: 90%;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    animation: modalSlideIn 0.3s ease;
}
.quantity-modal-content h3 {
    text-align: center;
    margin-bottom: 5px;
    color: #2c5f2d;
}
.quantity-modal-content .item-name-display {
    text-align: center;
    font-size: 1.1rem;
    color: var(--text-dark);
    margin-bottom: 15px;
    font-weight: 500;
}
.quantity-modal-content .item-price-display {
    text-align: center;
    font-size: 0.9rem;
    color: var(--text-light);
    margin-bottom: 15px;
}
.quantity-modal-content .stock-info {
    text-align: center;
    font-size: 0.8rem;
    color: var(--text-light);
    margin-bottom: 15px;
}
.quantity-modal-content .stock-info .available {
    color: #2c5f2d;
    font-weight: 600;
}
.quantity-modal-content .quantity-control {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    margin: 20px 0;
}
.quantity-modal-content .quantity-control button {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    border: 2px solid #e0e0e0;
    background: #f8f9fa;
    font-size: 1.3rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    color: var(--text-dark);
}
.quantity-modal-content .quantity-control button:hover {
    border-color: #2c5f2d;
    background: #f0f7f0;
}
.quantity-modal-content .quantity-control button:active {
    transform: scale(0.95);
}
.quantity-modal-content .quantity-control button:disabled {
    opacity: 0.4;
    cursor: not-allowed;
}
.quantity-modal-content .quantity-control .quantity-display {
    font-size: 2rem;
    font-weight: 700;
    min-width: 50px;
    text-align: center;
    color: var(--text-dark);
}
.quantity-modal-content .btn-group {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}
.quantity-modal-content .btn-group button {
    flex: 1;
    padding: 12px;
    border: none;
    border-radius: 10px;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}
.quantity-modal-content .btn-group .btn-add {
    background: #2c5f2d;
    color: #fff;
}
.quantity-modal-content .btn-group .btn-add:hover {
    background: #1a3d1b;
}
.quantity-modal-content .btn-group .btn-add:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}
.quantity-modal-content .btn-group .btn-cancel-qty {
    background: #e0e0e0;
    color: #333;
}
.quantity-modal-content .btn-group .btn-cancel-qty:hover {
    background: #d0d0d0;
}

/* Checkout Modal */
.checkout-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.6);
    z-index: 9999;
    align-items: center;
    justify-content: center;
    backdrop-filter: blur(4px);
}
.checkout-modal.show {
    display: flex;
}
.checkout-modal-content {
    background: #fff;
    border-radius: 20px;
    padding: 32px;
    max-width: 450px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    animation: modalSlideIn 0.3s ease;
}
.checkout-modal-content h3 {
    text-align: center;
    margin-bottom: 20px;
    color: #2c5f2d;
}
.checkout-modal-content .total-display {
    text-align: center;
    font-size: 2rem;
    font-weight: 700;
    color: #2c5f2d;
    padding: 15px;
    background: #f0f7f0;
    border-radius: 12px;
    margin-bottom: 20px;
}
.checkout-modal-content .total-display small {
    font-size: 0.9rem;
    color: #636e72;
    font-weight: 400;
}
.checkout-modal-content .form-group {
    margin-bottom: 15px;
}
.checkout-modal-content .form-group label {
    display: block;
    font-weight: 500;
    margin-bottom: 5px;
    font-size: 0.9rem;
}
.checkout-modal-content .form-group input {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 1.1rem;
    font-family: 'Poppins', sans-serif;
    transition: border-color 0.3s;
}
.checkout-modal-content .form-group input:focus {
    border-color: #2c5f2d;
    outline: none;
}
.checkout-modal-content .form-group select {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 1rem;
    font-family: 'Poppins', sans-serif;
    background: #fff;
    transition: border-color 0.3s;
}
.checkout-modal-content .form-group select:focus {
    border-color: #2c5f2d;
    outline: none;
}
.checkout-modal-content .form-group small.field-hint {
    display: block;
    margin-top: 5px;
    font-size: 0.78rem;
    color: #888;
}
.checkout-modal-content .form-group small.field-error {
    display: block;
    margin-top: 5px;
    font-size: 0.8rem;
    color: #e74c3c;
    font-weight: 500;
}
.checkout-modal-content .form-group input.input-error {
    border-color: #e74c3c;
}
.discount-summary-row {
    display: flex;
    justify-content: space-between;
    font-size: 0.85rem;
    color: #2c5f2d;
    background: #eafaf0;
    padding: 8px 12px;
    border-radius: 8px;
    margin: -10px 0 15px;
    font-weight: 600;
}
.payment-method-options {
    display: flex;
    gap: 10px;
}
.payment-method-option {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 10px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    cursor: pointer;
    font-size: 0.9rem;
    font-weight: 500;
    color: #555;
    transition: all 0.3s ease;
}
.payment-method-option input {
    display: none;
}
.payment-method-option.active {
    border-color: #2c5f2d;
    background: #eafaf0;
    color: #2c5f2d;
}
.payment-method-option i {
    font-size: 1.1rem;
}
.gcash-qr-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    background: #f3f7ff;
    border: 1px solid #dbe6ff;
    border-radius: 12px;
    padding: 16px;
    margin-bottom: 14px;
}
.gcash-qr-image {
    width: 160px;
    height: 160px;
    object-fit: contain;
    border-radius: 8px;
    background: #fff;
    padding: 6px;
    border: 1px solid #e0e0e0;
    margin-bottom: 10px;
}
.gcash-qr-details {
    margin-bottom: 6px;
}
.gcash-qr-name {
    font-weight: 700;
    color: #0072ce;
    font-size: 1rem;
}
.gcash-qr-number {
    font-weight: 600;
    color: #444;
    font-size: 0.9rem;
    letter-spacing: 0.5px;
}
.gcash-qr-hint {
    font-size: 0.75rem;
    color: #888;
}

/* Senior/PWD ID photo capture */
.id-photo-empty {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    background: #f7f7f7;
    border: 1px dashed #ccc;
    border-radius: 10px;
    padding: 10px 12px;
    font-size: 0.85rem;
    color: #777;
}
.id-photo-empty .id-photo-actions {
    flex-direction: row;
    flex-wrap: wrap;
}
.id-photo-empty i {
    font-size: 1.1rem;
    color: #999;
}
.id-photo-empty span {
    flex: 1;
}
.btn-scan-id {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: #2e7d32;
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 8px 14px;
    font-size: 0.82rem;
    font-weight: 600;
    cursor: pointer;
    white-space: nowrap;
}
.btn-scan-id:hover {
    background: #256428;
}
.btn-scan-id-remove {
    background: #c62828;
}
.btn-scan-id-remove:hover {
    background: #a52121;
}
.btn-scan-id-primary {
    background: #0072ce;
}
.btn-scan-id-primary:hover {
    background: #005ea3;
}
.id-photo-preview-wrap {
    display: flex;
    align-items: center;
    gap: 12px;
    background: #f7f7f7;
    border: 1px solid #e0e0e0;
    border-radius: 10px;
    padding: 10px;
}
.id-photo-preview {
    width: 90px;
    height: 60px;
    object-fit: cover;
    border-radius: 6px;
    border: 1px solid #ddd;
    background: #fff;
}
.id-photo-actions {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

/* Camera scanner modal */
.id-scanner-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.7);
    z-index: 3000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px;
}
.id-scanner-box {
    background: #fff;
    border-radius: 14px;
    width: 100%;
    max-width: 420px;
    overflow: hidden;
    display: flex;
    flex-direction: column;
}
.id-scanner-header {
    background: #2e7d32;
    color: #fff;
    padding: 14px 16px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 8px;
}
.id-scanner-close {
    margin-left: auto;
    background: transparent;
    border: none;
    color: #fff;
    font-size: 1rem;
    cursor: pointer;
}
.id-scanner-body {
    padding: 16px;
    display: flex;
    flex-direction: column;
    align-items: center;
}
#idScannerCameraWrap {
    position: relative;
    width: 100%;
    background: #000;
    border-radius: 10px;
    overflow: hidden;
}
#idScannerVideo {
    width: 100%;
    display: block;
    max-height: 320px;
    object-fit: cover;
}
.id-scanner-frame {
    position: absolute;
    inset: 10%;
    border: 3px dashed rgba(255,255,255,0.75);
    border-radius: 10px;
    pointer-events: none;
}
#idScannerCapturedImg {
    width: 100%;
    max-height: 320px;
    object-fit: contain;
    border-radius: 10px;
    background: #000;
}
.id-scanner-error {
    color: #c62828;
    font-size: 0.85rem;
    margin-top: 10px;
    text-align: center;
}
.id-scanner-footer {
    padding: 14px 16px;
    display: flex;
    gap: 10px;
    justify-content: center;
    border-top: 1px solid #eee;
}
.checkout-modal-content .change-display {
    text-align: center;
    padding: 12px;
    border-radius: 10px;
    margin: 10px 0;
    font-size: 1.1rem;
}
.checkout-modal-content .change-display.positive {
    background: #d4edda;
    color: #155724;
}
.checkout-modal-content .change-display.negative {
    background: #f8d7da;
    color: #721c24;
}
.checkout-modal-content .btn-group {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}
.checkout-modal-content .btn-group button {
    flex: 1;
    padding: 12px;
    border: none;
    border-radius: 10px;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}
.checkout-modal-content .btn-group .btn-confirm {
    background: #2c5f2d;
    color: #fff;
}
.checkout-modal-content .btn-group .btn-confirm:hover {
    background: #1a3d1b;
}
.checkout-modal-content .btn-group .btn-confirm:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}
.checkout-modal-content .btn-group .btn-cancel {
    background: #e0e0e0;
    color: #333;
}
.checkout-modal-content .btn-group .btn-cancel:hover {
    background: #d0d0d0;
}

@keyframes modalSlideIn {
    from { transform: translateY(-30px) scale(0.95); opacity: 0; }
    to { transform: translateY(0) scale(1); opacity: 1; }
}

/* Responsive */
@media (max-width: 992px) {
    .pos-container {
        grid-template-columns: 1fr;
    }
    .pos-cart {
        position: static;
        max-height: 400px;
    }
}

@media (max-width: 768px) {
    .pos-items {
        grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    }
    .pos-item-card .item-image,
    .pos-item-card .item-image-placeholder {
        height: 100px;
    }
    .pos-categories {
        gap: 6px;
    }
    .pos-category-btn {
        width: 68px;
        padding: 9px 6px 8px;
        font-size: 0.65rem;
    }
    .pos-category-icon {
        width: 32px;
        height: 32px;
        font-size: 0.9rem;
    }
    .pos-category-btn.has-image {
        width: 74px;
        height: 74px;
    }
}

/* Toast Notification */
.custom-toast {
    position: fixed;
    bottom: 30px;
    right: 30px;
    padding: 15px 25px;
    border-radius: 12px;
    color: #fff;
    font-weight: 500;
    z-index: 99999;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    animation: slideInUp 0.3s ease;
    max-width: 350px;
    font-family: 'Poppins', sans-serif;
    font-size: 0.9rem;
}

@keyframes slideInUp {
    from { transform: translateY(30px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
@keyframes slideOutDown {
    from { transform: translateY(0); opacity: 1; }
    to { transform: translateY(30px); opacity: 0; }
}
</style>

<!-- Page Header -->
<div class="page-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
    <div>
        <h2>
            <i class="fas fa-<?php echo $currentOrderType == 'dine_in' ? 'chair' : 'shopping-bag'; ?>"></i> 
            New Order - <?php echo $currentOrderType == 'dine_in' ? 'Dine In' : 'Take Out'; ?>
            <span class="order-type-badge <?php echo $currentOrderType == 'dine_in' ? 'dine-in' : 'take-out'; ?>">
                <i class="fas fa-<?php echo $currentOrderType == 'dine_in' ? 'utensils' : 'box'; ?>"></i>
                <?php echo strtoupper($currentOrderType == 'dine_in' ? 'Dine In' : 'Take Out'); ?>
            </span>
        </h2>
        <p>Cashier: <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
    </div>
    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <a href="dashboard.php" class="btn btn-primary" style="text-decoration: none; display: inline-flex; align-items: center; gap: 8px;">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
        <?php if ($currentOrderType == 'dine_in'): ?>
        <a href="?type=take_out&switch=true" class="btn btn-warning" style="text-decoration: none; display: inline-flex; align-items: center; gap: 8px; color: #fff;">
            <i class="fas fa-shopping-bag"></i> Switch to Take Out
            <?php if (count($_SESSION['pos_cart']) > 0): ?>
            <span class="cart-count-badge"><?php echo count($_SESSION['pos_cart']); ?></span>
            <?php endif; ?>
        </a>
        <?php else: ?>
        <a href="?type=dine_in&switch=true" class="btn btn-primary" style="text-decoration: none; display: inline-flex; align-items: center; gap: 8px;">
            <i class="fas fa-chair"></i> Switch to Dine In
            <?php if (count($_SESSION['pos_cart']) > 0): ?>
            <span class="cart-count-badge"><?php echo count($_SESSION['pos_cart']); ?></span>
            <?php endif; ?>
        </a>
        <?php endif; ?>
    </div>
</div>

<?php
function categoryIcon(string $name): string {
    $name = strtolower($name);
    $map = [
        'chicken'      => 'fa-drumstick-bite',
        'pork'         => 'fa-bone',
        'beef'         => 'fa-burger',
        'fish'         => 'fa-fish',
        'squid'        => 'fa-water',
        'shrimp'       => 'fa-anchor',
        'vegetable'    => 'fa-carrot',
        'noodles'      => 'fa-bowl-food',
        'breakfast'    => 'fa-egg',
        'beverages'    => 'fa-mug-hot',
        'we also serve'=> 'fa-utensils',
        'dessert'      => 'fa-ice-cream',
        'snack'        => 'fa-cookie-bite',
        'rice'         => 'fa-bowl-rice',
        'soup'         => 'fa-bowl-food',
    ];
    foreach ($map as $key => $icon) {
        if (strpos($name, $key) !== false) return $icon;
    }
    return 'fa-tag';
}
?>
<!-- Main POS Container -->
<div class="pos-container">
    <!-- Menu Section -->
    <div class="pos-menu">
        <!-- Category Tabs -->
        <div class="pos-categories" id="categoryContainer">
            <?php 
            $first = true;
            $categoryUploadWebDir = __DIR__ . '/../../assets/uploads/categories';
            foreach ($categories as $cat): 
                $catImagePath = !empty($cat['image']) && file_exists($categoryUploadWebDir . '/' . $cat['image'])
                    ? SITE_URL . 'assets/uploads/categories/' . htmlspecialchars($cat['image'])
                    : null;
            ?>
            <button class="pos-category-btn <?php echo $catImagePath ? 'has-image' : ''; ?> <?php echo $first ? 'active' : ''; ?>" data-category="<?php echo $cat['id']; ?>">
                <?php if ($catImagePath): ?>
                    <img src="<?php echo $catImagePath; ?>" alt="<?php echo htmlspecialchars($cat['name']); ?>" class="pos-category-cover">
                    <span class="pos-category-label pos-category-label-overlay"><?php echo htmlspecialchars($cat['name']); ?></span>
                <?php else: ?>
                    <span class="pos-category-icon"><i class="fas <?php echo categoryIcon($cat['name']); ?>"></i></span>
                    <span class="pos-category-label"><?php echo htmlspecialchars($cat['name']); ?></span>
                <?php endif; ?>
            </button>
            <?php 
            $first = false;
            endforeach; 
            ?>
        </div>
        
        <!-- Menu Items Grid -->
        <div class="pos-items" id="menuItems">
            <div style="text-align: center; padding: 60px 20px; color: var(--text-light); grid-column: 1 / -1;">
                <i class="fas fa-spinner fa-spin" style="font-size: 2.5rem; display: block; margin-bottom: 12px;"></i>
                <p>Loading menu...</p>
            </div>
        </div>
    </div>
    
    <!-- Cart Section -->
    <div class="pos-cart" id="posCartPanel">
        <div class="pos-cart-header">
            <span><i class="fas fa-receipt"></i> Bill</span>
            <span class="cart-count" id="itemCount"><?php echo count($_SESSION['pos_cart']); ?> items</span>
        </div>
        <div class="pos-cart-items" id="cartItems">
            <?php if (empty($_SESSION['pos_cart'])): ?>
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <p>Your cart is empty</p>
                <small style="color: #bbb;">Click on menu items to add</small>
            </div>
            <?php else: ?>
            <?php 
            $subtotal = 0;
            foreach ($_SESSION['pos_cart'] as $index => $item): 
                $itemTotal = $item['price'] * $item['quantity'];
                $subtotal += $itemTotal;
            ?>
            <div class="cart-item" data-index="<?php echo $index; ?>">
                <?php if (!empty($item['image'])): ?>
                    <img src="<?php echo SITE_URL; ?>assets/uploads/menu/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="cart-item-image">
                <?php else: ?>
                    <div class="cart-item-image-placeholder">
                        <i class="fas fa-utensils"></i>
                    </div>
                <?php endif; ?>
                <div class="item-details">
                    <div class="item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                    <div class="item-qty-price">₱<?php echo number_format($item['price'], 2); ?> each</div>
                    <div class="cart-qty-control">
                        <button type="button" onclick="changeCartItemQty(<?php echo $index; ?>, -1)">−</button>
                        <span class="cart-qty-num"><?php echo $item['quantity']; ?></span>
                        <button type="button" onclick="changeCartItemQty(<?php echo $index; ?>, 1)">+</button>
                    </div>
                </div>
                <div>
                    <span class="item-subtotal">₱<?php echo number_format($itemTotal, 2); ?></span>
                    <button class="remove-btn" onclick="removeFromCart(<?php echo $index; ?>)">✕</button>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="pos-cart-footer">
            <?php 
            $subtotal = 0;
            foreach ($_SESSION['pos_cart'] as $item) {
                $subtotal += $item['price'] * $item['quantity'];
            }
            $takeoutFee = 0; // Takeout fee removed per owner request
            ?>
            <div class="cart-total">
                <span>Subtotal</span>
                <span id="cartSubtotal">₱<?php echo number_format($subtotal, 2); ?></span>
            </div>
            <div class="cart-fee" id="feeRow" style="display:none;">
                <span>Takeout Fee</span>
                <span id="feeDisplay">₱0.00</span>
            </div>
            <div class="cart-total" style="border-top: 2px solid #f0f0f0; padding-top: 12px; margin-top: 4px;">
                <span style="font-size: 1.1rem;">Total</span>
                <span class="total-amount" id="cartTotal">₱<?php echo number_format($subtotal + $takeoutFee, 2); ?></span>
            </div>
            <div class="pos-action-buttons">
                <button class="btn-clear" onclick="clearCart()"><i class="fas fa-trash-alt"></i> Clear</button>
                <button class="btn-checkout" onclick="showCheckoutModal()">
                    <i class="fas fa-cash-register"></i> Checkout
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Floating "Go to Cart" button - jumps/highlights the cart, useful once several items have been picked -->
<button type="button" class="go-to-cart-btn" id="goToCartBtn" onclick="goToCart()">
    <i class="fas fa-shopping-cart"></i>
    Go to Cart
    <span class="go-to-cart-badge" id="goToCartBadge">0</span>
</button>

<!-- Quantity Modal -->
<div class="quantity-modal" id="quantityModal">
    <div class="quantity-modal-content">
        <h3><i class="fas fa-plus-circle"></i> Enter Quantity</h3>
        <div class="item-name-display" id="qtyItemName">Item Name</div>
        <div class="item-price-display" id="qtyItemPrice">₱0.00</div>
        <div class="stock-info">Available: <span class="available" id="qtyStock">0</span></div>
        
        <div class="quantity-control">
            <button onclick="changeQuantity(-1)" id="qtyMinus">−</button>
            <span class="quantity-display" id="qtyDisplay">1</span>
            <button onclick="changeQuantity(1)" id="qtyPlus">+</button>
        </div>
        
        <div class="btn-group">
            <button class="btn-add" id="qtyAddBtn" onclick="confirmQuantity()">
                <i class="fas fa-cart-plus"></i> Add to Cart
            </button>
            <button class="btn-cancel-qty" onclick="closeQuantityModal()">Cancel</button>
        </div>
    </div>
</div>

<!-- Checkout Modal -->
<div class="checkout-modal" id="checkoutModal">
    <div class="checkout-modal-content">
        <h3><i class="fas fa-cash-register"></i> Checkout</h3>
        <div class="total-display">
            <small>Total Amount</small><br>
            ₱<span id="modalTotal">0.00</span>
        </div>

        <div class="discount-summary-row" id="discountSummaryRow" style="display:none;">
            <span id="discountSummaryLabel">Senior/PWD Discount</span>
            <span>-₱<span id="discountAmountDisplay">0.00</span></span>
        </div>
        
        <?php if ($currentOrderType == 'take_out'): ?>
        <div class="alert alert-info" style="font-size: 0.85rem; padding: 10px 14px; border-radius: 8px; background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb;">
            <i class="fas fa-info-circle"></i> Takeout fee of ₱10.00 per item included.
        </div>
        <?php endif; ?>

        <div class="form-group">
            <label for="discountType"><i class="fas fa-tags"></i> Discount</label>
            <select id="discountType" onchange="onDiscountChange()">
                <option value="none">No Discount</option>
                <option value="senior">Senior Citizen (<?php echo rtrim(rtrim(number_format($discountRates['senior_discount_rate'], 2), '0'), '.'); ?>%)</option>
                <option value="pwd">PWD (<?php echo rtrim(rtrim(number_format($discountRates['pwd_discount_rate'], 2), '0'), '.'); ?>%)</option>
            </select>
        </div>

        <div class="form-group" id="discountIdGroup" style="display:none;">
            <label for="discountIdNumber"><i class="fas fa-id-card"></i> Senior/PWD ID Number</label>
            <input type="text" id="discountIdNumber" placeholder="Enter ID number" oninput="onDiscountIdInput()">
            <small class="field-error" id="discountIdError" style="display:none;">ID number is required before proceeding to payment.</small>

            <div id="idPhotoBox" style="margin-top: 10px;">
                <div id="idPhotoEmpty" class="id-photo-empty">
                    <i class="fas fa-camera"></i>
                    <span>No ID photo yet</span>
                    <div class="id-photo-actions">
                        <button type="button" class="btn-scan-id" onclick="openIdScanner()"><i class="fas fa-camera"></i> Scan ID</button>
                        <button type="button" class="btn-scan-id" onclick="document.getElementById('idPhotoUploadInput').click()"><i class="fas fa-upload"></i> Upload Photo</button>
                    </div>
                </div>
                <div id="idPhotoPreviewWrap" class="id-photo-preview-wrap" style="display:none;">
                    <img id="idPhotoPreview" class="id-photo-preview" alt="Captured ID">
                    <div class="id-photo-actions">
                        <button type="button" class="btn-scan-id" onclick="openIdScanner()"><i class="fas fa-camera"></i> Scan Again</button>
                        <button type="button" class="btn-scan-id" onclick="document.getElementById('idPhotoUploadInput').click()"><i class="fas fa-upload"></i> Upload Instead</button>
                        <button type="button" class="btn-scan-id btn-scan-id-remove" onclick="removeIdPhoto()"><i class="fas fa-trash"></i> Remove</button>
                    </div>
                </div>
                <input type="file" id="idPhotoUploadInput" accept="image/*" style="display:none;" onchange="handleIdPhotoUpload(event)">
            </div>
        </div>

        <div class="form-group">
            <label><i class="fas fa-wallet"></i> Payment Method</label>
            <div class="payment-method-options">
                <label class="payment-method-option active" id="paymentOptionCash">
                    <input type="radio" name="paymentMethod" value="cash" checked onchange="onPaymentMethodChange()">
                    <i class="fas fa-money-bill-wave"></i> Cash
                </label>
                <label class="payment-method-option" id="paymentOptionGcash">
                    <input type="radio" name="paymentMethod" value="gcash" onchange="onPaymentMethodChange()">
                    <i class="fas fa-mobile-alt"></i> GCash
                </label>
            </div>
        </div>
        
        <div class="form-group" id="cashGroup">
            <label for="cashAmount"><i class="fas fa-money-bill-wave"></i> Cash Amount</label>
            <input type="number" id="cashAmount" placeholder="Enter cash amount" step="0.01" min="0" oninput="calculateChange()">
        </div>
        
        <div id="changeDisplay" class="change-display" style="display: none;">
            Change: ₱<span id="changeAmount">0.00</span>
        </div>

        <div class="form-group" id="gcashGroup" style="display:none;">
            <?php if ($gcashQrExists): ?>
            <div class="gcash-qr-card">
                <img src="<?php echo SITE_URL; ?>assets/images/payment/<?php echo htmlspecialchars($gcashQrFile); ?>" alt="GCash QR Code" class="gcash-qr-image">
                <?php if (!empty($gcashSettings['gcash_name']) || !empty($gcashSettings['gcash_number'])): ?>
                <div class="gcash-qr-details">
                    <?php if (!empty($gcashSettings['gcash_name'])): ?>
                        <div class="gcash-qr-name"><?php echo htmlspecialchars($gcashSettings['gcash_name']); ?></div>
                    <?php endif; ?>
                    <?php if (!empty($gcashSettings['gcash_number'])): ?>
                        <div class="gcash-qr-number"><?php echo htmlspecialchars($gcashSettings['gcash_number']); ?></div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <div class="gcash-qr-hint">Let the customer scan this QR code, or send to the number above.</div>
            </div>
            <?php endif; ?>
            <label for="gcashReference"><i class="fas fa-mobile-alt"></i> GCash Reference Number</label>
            <input type="text" id="gcashReference" placeholder="Enter GCash reference number" oninput="onGcashReferenceInput()">
            <small class="field-hint">Ask the customer for the reference number shown on their GCash receipt.</small>
        </div>
        
        <div class="btn-group">
            <button class="btn-confirm" id="confirmPayment" disabled onclick="processPayment()">
                <i class="fas fa-check"></i> Confirm Payment
            </button>
            <button class="btn-cancel" onclick="closeCheckoutModal()">
                <i class="fas fa-times"></i> Cancel
            </button>
        </div>
    </div>
</div>

<!-- ID Scanner Camera Modal -->
<div id="idScannerModal" class="id-scanner-overlay" style="display:none;">
    <div class="id-scanner-box">
        <div class="id-scanner-header">
            <i class="fas fa-id-card"></i> Scan Senior/PWD ID
            <button type="button" class="id-scanner-close" onclick="closeIdScanner()"><i class="fas fa-times"></i></button>
        </div>
        <div class="id-scanner-body">
            <div id="idScannerCameraWrap">
                <video id="idScannerVideo" autoplay playsinline></video>
                <div class="id-scanner-frame"></div>
            </div>
            <canvas id="idScannerCanvas" style="display:none;"></canvas>
            <img id="idScannerCapturedImg" style="display:none;">
            <p id="idScannerError" class="id-scanner-error" style="display:none;"></p>
        </div>
        <div class="id-scanner-footer">
            <button type="button" class="btn-scan-id" id="idScannerCaptureBtn" onclick="captureIdPhoto()"><i class="fas fa-camera"></i> Capture</button>
            <button type="button" class="btn-scan-id" id="idScannerRetakeBtn" onclick="retakeIdPhoto()" style="display:none;"><i class="fas fa-redo"></i> Retake</button>
            <button type="button" class="btn-scan-id btn-scan-id-primary" id="idScannerUseBtn" onclick="useIdPhoto()" style="display:none;"><i class="fas fa-check"></i> Use This Photo</button>
        </div>
    </div>
</div>

<input type="hidden" id="orderType" value="<?php echo $currentOrderType; ?>">

<script>
// ======================================================
// COMPLETE JAVASCRIPT - FIXED
// ======================================================

// Initialize variables
var cart = <?php echo json_encode($_SESSION['pos_cart']); ?>;
var currentCategory = <?php echo !empty($categories) ? $categories[0]['id'] : 0; ?>;
var orderType = '<?php echo $currentOrderType; ?>';
var grandTotal = 0;

// Quantity modal variables
var qtyItemId = 0;
var qtyItemName = '';
var qtyItemPrice = 0;
var qtyItemStock = 0;
var qtyItemImage = '';
var qtyCurrent = 1;

// SITE_URL from PHP
var SITE_URL = '<?php echo SITE_URL; ?>';

// ======================================================
// QUANTITY MODAL FUNCTIONS
// ======================================================

function openQuantityModal(itemId, itemName, itemPrice, itemStock, itemImage) {
    qtyItemId = itemId;
    qtyItemName = itemName;
    qtyItemPrice = itemPrice;
    qtyItemStock = itemStock;
    qtyItemImage = itemImage || '';
    qtyCurrent = 1;
    
    document.getElementById('qtyItemName').textContent = itemName;
    document.getElementById('qtyItemPrice').textContent = '₱' + parseFloat(itemPrice).toFixed(2);
    document.getElementById('qtyStock').textContent = itemStock;
    document.getElementById('qtyDisplay').textContent = '1';
    document.getElementById('qtyAddBtn').disabled = false;
    
    updateQuantityButtons();
    document.getElementById('quantityModal').classList.add('show');
}

function closeQuantityModal() {
    document.getElementById('quantityModal').classList.remove('show');
}

function changeQuantity(change) {
    var newQty = qtyCurrent + change;
    if (newQty < 1) newQty = 1;
    if (newQty > qtyItemStock) newQty = qtyItemStock;
    qtyCurrent = newQty;
    document.getElementById('qtyDisplay').textContent = qtyCurrent;
    updateQuantityButtons();
}

function updateQuantityButtons() {
    var minusBtn = document.getElementById('qtyMinus');
    var plusBtn = document.getElementById('qtyPlus');
    var addBtn = document.getElementById('qtyAddBtn');
    
    minusBtn.disabled = qtyCurrent <= 1;
    plusBtn.disabled = qtyCurrent >= qtyItemStock;
    addBtn.disabled = qtyCurrent < 1 || qtyCurrent > qtyItemStock;
}

function confirmQuantity() {
    if (qtyCurrent < 1 || qtyCurrent > qtyItemStock) {
        alert('Invalid quantity!');
        return;
    }
    closeQuantityModal();
    addToCart(qtyItemId, qtyItemName, qtyItemPrice, qtyItemStock, qtyCurrent, qtyItemImage);
}

// ======================================================
// LOAD MENU ITEMS - FIXED
// ======================================================

function loadMenu(categoryId) {
    var menuContainer = document.getElementById('menuItems');
    
    menuContainer.innerHTML = `
        <div style="text-align: center; padding: 60px 20px; color: var(--text-light); grid-column: 1 / -1;">
            <i class="fas fa-spinner fa-spin" style="font-size: 2.5rem; display: block; margin-bottom: 12px;"></i>
            <p>Loading menu...</p>
        </div>
    `;
    
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '../api/get_menu_with_images.php?category_id=' + categoryId, true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                var data = JSON.parse(xhr.responseText);
                console.log('Menu data:', data);
                
                if (data.success && data.items.length > 0) {
                    var html = '';
                    data.items.forEach(function(item) {
                        var outOfStock = item.stock <= 0;
                        var stockLabel = outOfStock ? 'Out of Stock' : (item.stock <= 10 ? 'Low Stock' : 'In Stock');
                        var stockClass = outOfStock ? 'out-of-stock' : (item.stock <= 10 ? 'low-stock' : 'in-stock');
                        var imageUrl = item.image ? SITE_URL + 'assets/uploads/menu/' + item.image : '';
                        
                        html += `
                            <div class="pos-item-card ${outOfStock ? 'out-of-stock' : ''}" 
                                 onclick="${outOfStock ? '' : "quickAddToCart(" + item.id + ", '" + item.name.replace(/'/g, "\\'") + "', " + item.price + ", " + item.stock + ", '" + (item.image || '') + "')"}"
                                 title="${outOfStock ? 'Out of Stock' : 'Click to add 1 to cart'}">
                                ${item.image ? 
                                    `<img src="${imageUrl}" alt="${item.name}" class="item-image" onerror="this.style.display='none'">` :
                                    `<div class="item-image-placeholder"><i class="fas fa-utensils"></i></div>`
                                }
                                ${item.stock <= 0 ? `<span class="item-badge low-stock">OUT OF STOCK</span>` : ''}
                                ${item.stock <= 10 && item.stock > 0 ? `<span class="item-badge low-stock">LOW STOCK</span>` : ''}
                                <div class="item-info">
                                    <div class="item-name">${item.name}</div>
                                    <div class="item-price">₱${parseFloat(item.price).toFixed(2)}</div>
                                    <div class="item-stock">
                                        <span class="${stockClass}">${stockLabel}</span> (${item.stock})
                                    </div>
                                </div>
                                ${!outOfStock ? `<button class="item-add-hint" onclick="event.stopPropagation(); openQuantityModal(${item.id}, '${item.name.replace(/'/g, "\\'")}', ${item.price}, ${item.stock}, '${item.image || ''}')" title="Choose a quantity"><i class="fas fa-plus"></i></button>` : ''}
                            </div>
                        `;
                    });
                    menuContainer.innerHTML = html;
                } else {
                    menuContainer.innerHTML = `
                        <div style="text-align: center; padding: 60px 20px; color: var(--text-light); grid-column: 1 / -1;">
                            <i class="fas fa-utensils" style="font-size: 2.5rem; display: block; margin-bottom: 12px; color: #ddd;"></i>
                            <p>No items in this category</p>
                        </div>
                    `;
                }
            } catch(e) {
                console.error('Error parsing JSON:', e);
                menuContainer.innerHTML = `
                    <div style="text-align: center; padding: 60px 20px; color: var(--accent); grid-column: 1 / -1;">
                        <i class="fas fa-exclamation-circle" style="font-size: 2.5rem; display: block; margin-bottom: 12px;"></i>
                        <p>Error loading menu. Please refresh the page.</p>
                    </div>
                `;
            }
        } else {
            console.error('Error loading menu:', xhr.status, xhr.statusText);
            menuContainer.innerHTML = `
                <div style="text-align: center; padding: 60px 20px; color: var(--accent); grid-column: 1 / -1;">
                    <i class="fas fa-exclamation-circle" style="font-size: 2.5rem; display: block; margin-bottom: 12px;"></i>
                    <p>Error loading menu. Please refresh the page.</p>
                    <small style="color: var(--text-light);">Status: ${xhr.status}</small>
                </div>
            `;
        }
    };
    xhr.onerror = function() {
        console.error('Network error loading menu');
        menuContainer.innerHTML = `
            <div style="text-align: center; padding: 60px 20px; color: var(--accent); grid-column: 1 / -1;">
                <i class="fas fa-exclamation-circle" style="font-size: 2.5rem; display: block; margin-bottom: 12px;"></i>
                <p>Network error loading menu. Please check your connection.</p>
            </div>
        `;
    };
    xhr.send();
}

// ======================================================
// CATEGORY CLICK HANDLER
// ======================================================

document.addEventListener('click', function(e) {
    var target = e.target.closest('.pos-category-btn');
    if (target) {
        document.querySelectorAll('.pos-category-btn').forEach(function(btn) {
            btn.classList.remove('active');
        });
        target.classList.add('active');
        currentCategory = parseInt(target.dataset.category);
        loadMenu(currentCategory);
    }
});

// ======================================================
// CART FUNCTIONS
// ======================================================

function quickAddToCart(id, name, price, stock, image) {
    addToCart(id, name, price, stock, 1, image);
}

function addToCart(id, name, price, stock, quantity, image) {
    var existing = cart.find(function(item) { return item.id === id; });
    if (existing) {
        if (existing.quantity + quantity > stock) { 
            showToast('❌ Not enough stock! Available: ' + stock, 'error');
            return; 
        }
        existing.quantity += quantity;
    } else {
        cart.push({ 
            id: id, 
            name: name, 
            price: price, 
            quantity: quantity, 
            stock: stock,
            image: image || ''
        });
    }
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                var data = JSON.parse(xhr.responseText);
                if (data.success) {
                    cart = data.cart;
                    updateCart();
                    showToast('✅ Added ' + quantity + 'x ' + name + ' to cart!', 'success');
                } else {
                    showToast('❌ ' + data.error, 'error');
                }
            } catch(e) {
                updateCart();
            }
        } else {
            updateCart();
        }
    };
    var params = 'action=add_to_cart&item_id=' + id + '&name=' + encodeURIComponent(name) + '&price=' + price + '&stock=' + stock + '&quantity=' + quantity + '&image=' + encodeURIComponent(image || '');
    xhr.send(params);
}

function updateCart() {
    var isTakeout = orderType === 'take_out';
    var cartContainer = document.getElementById('cartItems');
    var itemCount = document.getElementById('itemCount');
    var cartSubtotal = document.getElementById('cartSubtotal');
    var feeDisplay = document.getElementById('feeDisplay');
    var cartTotal = document.getElementById('cartTotal');
    
    if (cart.length === 0) {
        cartContainer.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <p>Your cart is empty</p>
                <small style="color: #bbb;">Click on menu items to add</small>
            </div>
        `;
        itemCount.textContent = '0 items';
        cartSubtotal.textContent = '₱0.00';
        if (isTakeout && feeDisplay) feeDisplay.textContent = '₱0.00';
        cartTotal.textContent = '₱0.00';
        updateGoToCartButton();
        return;
    }
    
    var html = ''; 
    var subtotal = 0; 
    var feeTotal = 0; // Takeout fee removed per owner request
    
    cart.forEach(function(item, index) {
        var itemTotal = item.price * item.quantity;
        subtotal += itemTotal;
        
        var imageHtml = item.image ? 
            '<img src="' + SITE_URL + 'assets/uploads/menu/' + item.image + '" alt="' + item.name + '" class="cart-item-image" onerror="this.style.display=\'none\'">' :
            '<div class="cart-item-image-placeholder"><i class="fas fa-utensils"></i></div>';
        
        html += `
            <div class="cart-item" data-index="${index}">
                ${imageHtml}
                <div class="item-details">
                    <div class="item-name">${item.name}</div>
                    <div class="item-qty-price">₱${parseFloat(item.price).toFixed(2)} each</div>
                    <div class="cart-qty-control">
                        <button type="button" onclick="changeCartItemQty(${index}, -1)">−</button>
                        <span class="cart-qty-num">${item.quantity}</span>
                        <button type="button" onclick="changeCartItemQty(${index}, 1)">+</button>
                    </div>
                </div>
                <div>
                    <span class="item-subtotal">₱${itemTotal.toFixed(2)}</span>
                    <button class="remove-btn" onclick="removeFromCart(${index})">✕</button>
                </div>
            </div>
        `;
    });
    
    cartContainer.innerHTML = html;
    var totalItems = cart.reduce(function(sum, item) { return sum + item.quantity; }, 0);
    itemCount.textContent = totalItems + ' items';
    cartSubtotal.textContent = '₱' + subtotal.toFixed(2);
    if (isTakeout && feeDisplay) feeDisplay.textContent = '₱' + feeTotal.toFixed(2);
    cartTotal.textContent = '₱' + (subtotal + feeTotal).toFixed(2);
    updateGoToCartButton();
}

function changeCartItemQty(index, delta) {
    var item = cart[index];
    if (!item) return;
    var newQty = item.quantity + delta;

    if (newQty < 1) {
        removeFromCart(index);
        return;
    }
    if (newQty > item.stock) {
        showToast('❌ Not enough stock! Available: ' + item.stock, 'error');
        return;
    }

    item.quantity = newQty; // update instantly on screen
    updateCart();

    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                var data = JSON.parse(xhr.responseText);
                if (data.success) {
                    cart = data.cart;
                } else {
                    showToast('❌ ' + data.error, 'error');
                    if (data.cart) cart = data.cart;
                }
                updateCart();
            } catch(e) {
                updateCart();
            }
        } else {
            updateCart();
        }
    };
    xhr.send('action=update_quantity&index=' + index + '&quantity=' + newQty);
}

function goToCart() {
    var cartPanel = document.getElementById('posCartPanel');
    if (!cartPanel) return;
    cartPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    cartPanel.classList.remove('highlight-cart');
    // restart the animation even if it was just played
    void cartPanel.offsetWidth;
    cartPanel.classList.add('highlight-cart');
}

function updateGoToCartButton() {
    var btn = document.getElementById('goToCartBtn');
    var badge = document.getElementById('goToCartBadge');
    if (!btn || !badge) return;
    var totalItems = cart.reduce(function(sum, item) { return sum + item.quantity; }, 0);
    badge.textContent = totalItems;
    if (totalItems > 0) {
        btn.classList.add('show');
    } else {
        btn.classList.remove('show');
    }
}

function removeFromCart(index) { 
    var item = cart[index];
    if (!item) return;
    
    cart.splice(index, 1);
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                var data = JSON.parse(xhr.responseText);
                if (data.success) {
                    cart = data.cart;
                    updateCart();
                    showToast('🗑️ Removed item from cart', 'info');
                }
            } catch(e) {
                updateCart();
            }
        } else {
            updateCart();
        }
    };
    xhr.send('action=remove_from_cart&index=' + index);
}

function clearCart() { 
    if (cart.length === 0) return; 
    if (confirm('Clear all items from cart?')) { 
        cart = [];
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.location.href, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            updateCart();
            showToast('🗑️ Cart cleared', 'info');
        };
        xhr.send('action=clear_cart');
    } 
}

// ======================================================
// TOAST NOTIFICATION
// ======================================================

function showToast(message, type) {
    var existing = document.querySelector('.custom-toast');
    if (existing) existing.remove();
    
    var toast = document.createElement('div');
    toast.className = 'custom-toast';
    toast.style.cssText = `
        position: fixed;
        bottom: 30px;
        right: 30px;
        padding: 15px 25px;
        border-radius: 12px;
        color: #fff;
        font-weight: 500;
        z-index: 99999;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        animation: slideInUp 0.3s ease;
        max-width: 350px;
        font-family: 'Poppins', sans-serif;
        font-size: 0.9rem;
    `;
    
    if (type === 'success') {
        toast.style.background = '#2c5f2d';
    } else if (type === 'error') {
        toast.style.background = '#e74c3c';
    } else {
        toast.style.background = '#3498db';
    }
    
    toast.innerHTML = '<i class="fas fa-' + (type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle') + '"></i> ' + message;
    document.body.appendChild(toast);
    
    setTimeout(function() {
        toast.style.animation = 'slideOutDown 0.3s ease forwards';
        setTimeout(function() { toast.remove(); }, 300);
    }, 3000);
}

// ======================================================
// CHECKOUT FUNCTIONS
// ======================================================

var discountType = 'none';
var paymentMethod = 'cash';
var currentSubtotal = 0;
var currentDiscountAmount = 0;
// Rates are configured by the admin in System Settings (defaults to 20% each)
var SENIOR_DISCOUNT_RATE = <?php echo (float)$discountRates['senior_discount_rate']; ?> / 100;
var PWD_DISCOUNT_RATE = <?php echo (float)$discountRates['pwd_discount_rate']; ?> / 100;

function showCheckoutModal() {
    if (cart.length === 0) {
        showToast('❌ Cart is empty! Add items first.', 'error');
        return;
    }

    // Reset discount + payment state every time the modal opens
    discountType = 'none';
    paymentMethod = 'cash';
    document.getElementById('discountType').value = 'none';
    document.getElementById('discountIdNumber').value = '';
    document.getElementById('discountIdGroup').style.display = 'none';
    document.getElementById('discountIdError').style.display = 'none';
    document.getElementById('discountIdNumber').classList.remove('input-error');
    removeIdPhoto();
    document.getElementById('gcashReference').value = '';
    document.querySelector('input[name="paymentMethod"][value="cash"]').checked = true;
    document.getElementById('paymentOptionCash').classList.add('active');
    document.getElementById('paymentOptionGcash').classList.remove('active');
    document.getElementById('cashGroup').style.display = 'block';
    document.getElementById('gcashGroup').style.display = 'none';

    recomputeTotals();
    document.getElementById('checkoutModal').classList.add('show');
    setTimeout(function() { document.getElementById('cashAmount').focus(); }, 300);
}

function closeCheckoutModal() {
    document.getElementById('checkoutModal').classList.remove('show');
}

function recomputeTotals() {
    var takeoutFee = 0; // Takeout fee removed per owner request
    currentSubtotal = cart.reduce(function(sum, item) { return sum + (item.price * item.quantity); }, 0);
    var activeRate = discountType === 'senior' ? SENIOR_DISCOUNT_RATE : (discountType === 'pwd' ? PWD_DISCOUNT_RATE : 0);
    currentDiscountAmount = (discountType === 'senior' || discountType === 'pwd')
        ? Math.round(currentSubtotal * activeRate * 100) / 100
        : 0;
    grandTotal = currentSubtotal - currentDiscountAmount + takeoutFee;
    if (grandTotal < 0) grandTotal = 0;

    document.getElementById('modalTotal').textContent = grandTotal.toFixed(2);

    var discountRow = document.getElementById('discountSummaryRow');
    if (currentDiscountAmount > 0) {
        discountRow.style.display = 'flex';
        var ratePct = Math.round(activeRate * 10000) / 100; // trims float noise, keeps up to 2 decimals
        var label = (discountType === 'senior' ? 'Senior Citizen Discount' : 'PWD Discount') + ' (' + ratePct + '%)';
        document.getElementById('discountSummaryLabel').textContent = label;
        document.getElementById('discountAmountDisplay').textContent = currentDiscountAmount.toFixed(2);
    } else {
        discountRow.style.display = 'none';
    }

    document.getElementById('cashAmount').value = grandTotal.toFixed(2);
    document.getElementById('cashAmount').min = grandTotal;

    calculateChange();
}

// ======================================================
// DISCOUNT (SENIOR CITIZEN / PWD)
// ======================================================

function onDiscountChange() {
    discountType = document.getElementById('discountType').value;
    var idGroup = document.getElementById('discountIdGroup');
    var idInput = document.getElementById('discountIdNumber');

    if (discountType === 'senior' || discountType === 'pwd') {
        idGroup.style.display = 'block';
    } else {
        idGroup.style.display = 'none';
        idInput.value = '';
        idInput.classList.remove('input-error');
        document.getElementById('discountIdError').style.display = 'none';
        removeIdPhoto();
    }

    recomputeTotals();
    updateConfirmState();
}

function onDiscountIdInput() {
    var idInput = document.getElementById('discountIdNumber');
    if (idInput.value.trim().length > 0) {
        idInput.classList.remove('input-error');
        document.getElementById('discountIdError').style.display = 'none';
    }
    updateConfirmState();
}

// ======================================================
// SENIOR/PWD ID CAMERA SCANNER
// Captures a photo of the customer's ID for compliance
// record-keeping. The cashier still types the ID number
// by hand for the receipt/order record.
// ======================================================

var idScannerStream = null;
var capturedIdPhoto = null; // base64 JPEG data URL, set once a photo is confirmed with "Use This Photo"

function openIdScanner() {
    var modal = document.getElementById('idScannerModal');
    var video = document.getElementById('idScannerVideo');
    var errorEl = document.getElementById('idScannerError');

    modal.style.display = 'flex';
    resetScannerUI();
    errorEl.style.display = 'none';

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        errorEl.textContent = 'Camera access is not supported on this browser/device. Please use the Upload Photo button instead.';
        errorEl.style.display = 'block';
        document.getElementById('idScannerCaptureBtn').style.display = 'none';
        return;
    }

    function showCameraError(err) {
        errorEl.textContent = 'Could not access the camera (' + err.name + '). Please allow camera permission, or use the Upload Photo button instead.';
        errorEl.style.display = 'block';
        document.getElementById('idScannerCaptureBtn').style.display = 'none';
    }

    // Try the rear ("environment") camera first, since that's best for scanning
    // a physical ID. Some laptops/desktops have no rear camera at all, which
    // makes the browser throw NotFoundError/OverconstrainedError instead of
    // just picking another camera - so fall back to any available camera.
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false })
        .then(function(stream) {
            idScannerStream = stream;
            video.srcObject = stream;
        })
        .catch(function(err) {
            if (err.name === 'NotFoundError' || err.name === 'OverconstrainedError' || err.name === 'NotReadableError') {
                navigator.mediaDevices.getUserMedia({ video: true, audio: false })
                    .then(function(stream) {
                        idScannerStream = stream;
                        video.srcObject = stream;
                    })
                    .catch(showCameraError);
            } else {
                showCameraError(err);
            }
        });
}

function stopIdScannerStream() {
    if (idScannerStream) {
        idScannerStream.getTracks().forEach(function(track) { track.stop(); });
        idScannerStream = null;
    }
}

function resetScannerUI() {
    document.getElementById('idScannerCameraWrap').style.display = 'block';
    document.getElementById('idScannerCapturedImg').style.display = 'none';
    document.getElementById('idScannerCaptureBtn').style.display = 'inline-flex';
    document.getElementById('idScannerRetakeBtn').style.display = 'none';
    document.getElementById('idScannerUseBtn').style.display = 'none';
}

function closeIdScanner() {
    stopIdScannerStream();
    document.getElementById('idScannerModal').style.display = 'none';
    // If the cashier closes the scanner without capturing anything and a
    // discount is still selected, they can retry later via the "Scan ID" button.
}

function captureIdPhoto() {
    var video = document.getElementById('idScannerVideo');
    var canvas = document.getElementById('idScannerCanvas');
    var capturedImg = document.getElementById('idScannerCapturedImg');

    if (!video.videoWidth) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);

    var dataUrl = canvas.toDataURL('image/jpeg', 0.7);
    capturedImg.src = dataUrl;

    document.getElementById('idScannerCameraWrap').style.display = 'none';
    capturedImg.style.display = 'block';
    document.getElementById('idScannerCaptureBtn').style.display = 'none';
    document.getElementById('idScannerRetakeBtn').style.display = 'inline-flex';
    document.getElementById('idScannerUseBtn').style.display = 'inline-flex';

    stopIdScannerStream();
}

function retakeIdPhoto() {
    resetScannerUI();
    openIdScanner();
}

function useIdPhoto() {
    var capturedImg = document.getElementById('idScannerCapturedImg');
    capturedIdPhoto = capturedImg.src;

    document.getElementById('idPhotoEmpty').style.display = 'none';
    document.getElementById('idPhotoPreviewWrap').style.display = 'flex';
    document.getElementById('idPhotoPreview').src = capturedIdPhoto;

    stopIdScannerStream();
    document.getElementById('idScannerModal').style.display = 'none';

    document.getElementById('discountIdNumber').focus();
}

function handleIdPhotoUpload(event) {
    var file = event.target.files && event.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
        showToast('❌ Please choose an image file.', 'error');
        event.target.value = '';
        return;
    }

    var reader = new FileReader();
    reader.onload = function(e) {
        capturedIdPhoto = e.target.result;
        document.getElementById('idPhotoEmpty').style.display = 'none';
        document.getElementById('idPhotoPreviewWrap').style.display = 'flex';
        document.getElementById('idPhotoPreview').src = capturedIdPhoto;
        document.getElementById('discountIdNumber').focus();
    };
    reader.onerror = function() {
        showToast('❌ Could not read that image. Please try another file.', 'error');
    };
    reader.readAsDataURL(file);

    event.target.value = ''; // allow re-selecting the same file later
}

function removeIdPhoto() {
    capturedIdPhoto = null;
    document.getElementById('idPhotoEmpty').style.display = 'flex';
    document.getElementById('idPhotoPreviewWrap').style.display = 'none';
    document.getElementById('idPhotoPreview').src = '';
}

// ======================================================
// PAYMENT METHOD (CASH / GCASH)
// ======================================================

function onPaymentMethodChange() {
    var selected = document.querySelector('input[name="paymentMethod"]:checked');
    paymentMethod = selected ? selected.value : 'cash';

    document.getElementById('paymentOptionCash').classList.toggle('active', paymentMethod === 'cash');
    document.getElementById('paymentOptionGcash').classList.toggle('active', paymentMethod === 'gcash');

    if (paymentMethod === 'gcash') {
        document.getElementById('cashGroup').style.display = 'none';
        document.getElementById('changeDisplay').style.display = 'none';
        document.getElementById('gcashGroup').style.display = 'block';
    } else {
        document.getElementById('cashGroup').style.display = 'block';
        document.getElementById('gcashGroup').style.display = 'none';
        calculateChange();
    }

    updateConfirmState();
}

function onGcashReferenceInput() {
    updateConfirmState();
}

function calculateChange() {
    var cashInput = document.getElementById('cashAmount');
    var changeDisplay = document.getElementById('changeDisplay');
    var changeAmount = document.getElementById('changeAmount');

    if (paymentMethod !== 'cash') {
        changeDisplay.style.display = 'none';
        updateConfirmState();
        return;
    }

    var cash = parseFloat(cashInput.value) || 0;
    var change = cash - grandTotal;

    if (cash > 0) {
        changeDisplay.style.display = 'block';
        changeAmount.textContent = change.toFixed(2);
        changeDisplay.className = change >= 0 ? 'change-display positive' : 'change-display negative';
    } else {
        changeDisplay.style.display = 'none';
    }

    updateConfirmState();
}

// ======================================================
// CONFIRM BUTTON STATE
// Requires: senior/PWD ID number (if discount selected) BEFORE
// the cashier can proceed with either cash or GCash payment.
// ======================================================

function updateConfirmState() {
    var confirmBtn = document.getElementById('confirmPayment');
    if (!confirmBtn) return;

    var discountOk = true;
    if (discountType === 'senior' || discountType === 'pwd') {
        var idNumber = document.getElementById('discountIdNumber').value.trim();
        discountOk = idNumber.length > 0;
    }

    var paymentOk = false;
    if (paymentMethod === 'cash') {
        var cash = parseFloat(document.getElementById('cashAmount').value) || 0;
        paymentOk = cash >= grandTotal;
    } else if (paymentMethod === 'gcash') {
        var ref = document.getElementById('gcashReference').value.trim();
        paymentOk = ref.length > 0;
    }

    confirmBtn.disabled = !(discountOk && paymentOk);
}

function processPayment() {
    // Guard: senior/PWD ID number must be provided before proceeding to payment
    if (discountType === 'senior' || discountType === 'pwd') {
        var idInput = document.getElementById('discountIdNumber');
        var idNumber = idInput.value.trim();
        if (idNumber.length === 0) {
            idInput.classList.add('input-error');
            document.getElementById('discountIdError').style.display = 'block';
            showToast('❌ Please enter the Senior/PWD ID number first!', 'error');
            idInput.focus();
            return;
        }
    }

    var cashAmount = 0;
    var changeAmount = 0;
    var referenceNumber = '';

    if (paymentMethod === 'cash') {
        cashAmount = parseFloat(document.getElementById('cashAmount').value) || 0;
        if (cashAmount < grandTotal) {
            showToast('❌ Insufficient payment!', 'error');
            return;
        }
        changeAmount = cashAmount - grandTotal;
    } else if (paymentMethod === 'gcash') {
        referenceNumber = document.getElementById('gcashReference').value.trim();
        if (referenceNumber.length === 0) {
            showToast('❌ Please enter the GCash reference number!', 'error');
            document.getElementById('gcashReference').focus();
            return;
        }
        cashAmount = grandTotal;
        changeAmount = 0;
    }

    var confirmBtn = document.getElementById('confirmPayment');
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

    var orderData = {
        order_type: orderType,
        items: JSON.stringify(cart),
        subtotal: currentSubtotal,
        takeout_fee: 0, // Takeout fee removed per owner request
        discount_type: discountType,
        discount_id_number: (discountType === 'senior' || discountType === 'pwd')
            ? document.getElementById('discountIdNumber').value.trim() : '',
        discount_amount: currentDiscountAmount,
        total: grandTotal,
        payment_method: paymentMethod,
        reference_number: referenceNumber,
        payment_amount: cashAmount,
        change_amount: changeAmount,
        discount_id_image: (discountType === 'senior' || discountType === 'pwd') ? (capturedIdPhoto || '') : ''
    };
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'process_order.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                var data = JSON.parse(xhr.responseText);
                if (data.success) {
                    closeCheckoutModal();
                    showToast('✅ Order completed! #' + data.order_number, 'success');
                    generateReceipt(data.order_id);
                    
                    cart = [];
                    capturedIdPhoto = null;
                    var clearXhr = new XMLHttpRequest();
                    clearXhr.open('POST', window.location.href, true);
                    clearXhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    clearXhr.send('action=clear_cart');
                    updateCart();
                    loadMenu(currentCategory);
                } else {
                    showToast('❌ Error: ' + data.error, 'error');
                    confirmBtn.disabled = false;
                    confirmBtn.innerHTML = '<i class="fas fa-check"></i> Confirm Payment';
                }
            } catch(e) {
                showToast('❌ Error processing order!', 'error');
                confirmBtn.disabled = false;
                confirmBtn.innerHTML = '<i class="fas fa-check"></i> Confirm Payment';
            }
        } else {
            showToast('❌ Error processing order!', 'error');
            confirmBtn.disabled = false;
            confirmBtn.innerHTML = '<i class="fas fa-check"></i> Confirm Payment';
        }
    };
    xhr.onerror = function() {
        showToast('❌ Network error! Please try again.', 'error');
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = '<i class="fas fa-check"></i> Confirm Payment';
    };
    
    var params = [];
    for (var key in orderData) {
        params.push(encodeURIComponent(key) + '=' + encodeURIComponent(orderData[key]));
    }
    xhr.send(params.join('&'));
}

function generateReceipt(orderId) {
    window.open('receipt.php?order_id=' + orderId, '_blank', 'width=800,height=600');
}

// ======================================================
// INITIALIZATION
// ======================================================

document.addEventListener('DOMContentLoaded', function() {
    loadMenu(currentCategory);
    updateCart();
    
    // Auto-refresh cart from session every 30 seconds
    setInterval(function() {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.location.href, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    if (data.success) {
                        cart = data.cart;
                        orderType = data.order_type;
                        updateCart();
                    }
                } catch(e) {}
            }
        };
        xhr.send('action=get_cart');
    }, 30000);
});

// Close modals on outside click
document.getElementById('quantityModal').addEventListener('click', function(e) {
    if (e.target === this) closeQuantityModal();
});
document.getElementById('checkoutModal').addEventListener('click', function(e) {
    if (e.target === this) closeCheckoutModal();
});

// Close modals with ESC key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeQuantityModal();
        closeCheckoutModal();
    }
});
</script>

<?php include '../../includes/footer.php'; ?>