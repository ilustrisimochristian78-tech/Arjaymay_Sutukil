<?php
// ======================================================
// PROCESS PAYMENT (Cashier)
// ======================================================
require_once '../../config/database.php';
requireCashier();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$orderId = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;
$paymentMethod = isset($_POST['payment_method']) ? sanitize($_POST['payment_method']) : 'cash';
$amount = isset($_POST['amount']) ? (float)$_POST['amount'] : 0;
$referenceNumber = isset($_POST['reference_number']) ? sanitize($_POST['reference_number']) : '';

if ($orderId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid order ID']);
    exit;
}

if ($amount <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid payment amount']);
    exit;
}

$pdo = getDBConnection();

try {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND status = 'pending'");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch();

    if (!$order) {
        echo json_encode(['success' => false, 'error' => 'Order not found or already completed']);
        exit;
    }

    if ($amount < $order['total']) {
        echo json_encode(['success' => false, 'error' => 'Insufficient payment amount']);
        exit;
    }

    $change = $amount - $order['total'];

    $pdo->beginTransaction();

    try {
        // Record the payment but don't close out the order here - it should
        // only flip to 'completed' once the kitchen marks it 'served'
        // (see modules/api/update_order_status.php), same as process_order.php.
        $stmt = $pdo->prepare("UPDATE orders SET payment_method = ?, payment_amount = ?, change_amount = ? WHERE id = ?");
        $stmt->execute([$paymentMethod, $amount, $change, $orderId]);

        $stmt = $pdo->prepare("INSERT INTO payments (order_id, amount, payment_method, reference_number, status) VALUES (?, ?, ?, ?, 'completed')");
        $stmt->execute([$orderId, $amount, $paymentMethod, $referenceNumber]);

        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'payment_processed', ?)");
        $stmt->execute([$_SESSION['user_id'], "Payment processed for order #{$order['order_number']}: " . formatCurrency($amount)]);

        $pdo->commit();

        echo json_encode([
            'success' => true,
            'order_id' => $orderId,
            'order_number' => $order['order_number'],
            'total' => $order['total'],
            'payment_amount' => $amount,
            'change' => $change,
            'payment_method' => $paymentMethod
        ]);

    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>