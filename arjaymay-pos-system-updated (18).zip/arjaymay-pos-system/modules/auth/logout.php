<?php
// ======================================================
// LOGOUT
// ======================================================
require_once '../../config/database.php';

if (isLoggedIn()) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'logout', ?)");
    $stmt->execute([
        $_SESSION['user_id'],
        "User {$_SESSION['full_name']} logged out"
    ]);
}

$_SESSION = array();
session_destroy();

header('Location: ../../index.php');
exit;
?>