<?php
// ======================================================
// MENU MANAGEMENT - WITH IMAGE UPLOAD (FIXED DELETION)
// ======================================================

/**
 * @see requireAdmin()
 * @see getDBConnection()
 * @see sanitize()
 * @see getAllCategories()
 * @see formatCurrency()
 * @see SITE_URL
 */

// Include database configuration
require_once '../../config/database.php';
requireAdmin();

$pdo = getDBConnection();
$message = '';
$error = '';

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $name = sanitize($_POST['name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $price = (float)($_POST['price'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $description = sanitize($_POST['description'] ?? '');
    $item_id = (int)($_POST['item_id'] ?? 0);
    
    if ($action === 'add') {
        try {
            // Handle image upload
            $imageName = '';
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $imageName = uploadImage($_FILES['image']);
                if ($imageName === false) {
                    $error = 'Failed to upload image. Please check file type and size.';
                }
            }
            
            $stmt = $pdo->prepare("INSERT INTO menu_items (category_id, name, description, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$category_id, $name, $description, $price, $stock, $imageName]);
            $message = 'Menu item added successfully!';
            
            $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'add_menu_item', ?)");
            $stmt->execute([$_SESSION['user_id'], "Added menu item: $name"]);
            
        } catch (PDOException $e) {
            $error = 'Error: ' . $e->getMessage();
        }
    } 
    elseif ($action === 'edit' && $item_id > 0) {
        try {
            // Check if new image is uploaded
            $imageName = '';
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                // Delete old image
                $stmt = $pdo->prepare("SELECT image FROM menu_items WHERE id = ?");
                $stmt->execute([$item_id]);
                $oldItem = $stmt->fetch();
                if ($oldItem && !empty($oldItem['image'])) {
                    deleteImage($oldItem['image']);
                }
                
                $imageName = uploadImage($_FILES['image']);
                if ($imageName === false) {
                    $error = 'Failed to upload image. Please check file type and size.';
                }
            }
            
            if ($imageName !== '') {
                $stmt = $pdo->prepare("UPDATE menu_items SET category_id = ?, name = ?, description = ?, price = ?, stock = ?, image = ? WHERE id = ?");
                $stmt->execute([$category_id, $name, $description, $price, $stock, $imageName, $item_id]);
            } else {
                $stmt = $pdo->prepare("UPDATE menu_items SET category_id = ?, name = ?, description = ?, price = ?, stock = ? WHERE id = ?");
                $stmt->execute([$category_id, $name, $description, $price, $stock, $item_id]);
            }
            $message = 'Menu item updated successfully!';
            
            $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'edit_menu_item', ?)");
            $stmt->execute([$_SESSION['user_id'], "Updated menu item: $name"]);
            
        } catch (PDOException $e) {
            $error = 'Error: ' . $e->getMessage();
        }
    }
}

// ======================================================
// HANDLE DELETE - FIXED
// ======================================================
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    try {
        // Get item data before deleting
        $stmt = $pdo->prepare("SELECT image, name FROM menu_items WHERE id = ?");
        $stmt->execute([$id]);
        $item = $stmt->fetch();
        
        if ($item) {
            // Delete the image file from server
            if (!empty($item['image'])) {
                $imagePath = '../../assets/uploads/menu/' . $item['image'];
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }
            }
            
            // Delete the database record
            $stmt = $pdo->prepare("DELETE FROM menu_items WHERE id = ?");
            $stmt->execute([$id]);
            
            // Also delete related order_items if any
            $stmt = $pdo->prepare("DELETE FROM order_items WHERE menu_item_id = ?");
            $stmt->execute([$id]);
            
            $message = 'Menu item deleted successfully!';
            
            // Log activity
            $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'delete_menu_item', ?)");
            $stmt->execute([$_SESSION['user_id'], "Deleted menu item: {$item['name']}"]);
        } else {
            $error = 'Item not found.';
        }
        
    } catch (PDOException $e) {
        $error = 'Error: ' . $e->getMessage();
    }
    
    // Refresh the page to show updated list
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// ======================================================
// IMAGE UPLOAD FUNCTIONS - FIXED WITH TYPE HINTS
// ======================================================

function uploadImage(array $file): string|false {
    $uploadDir = '../../assets/uploads/menu/';
    
    // Create directory if not exists
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $maxSize = 2 * 1024 * 1024; // 2MB
    
    $mimeType = mime_content_type($file['tmp_name']);
    
    if (!in_array($mimeType, $allowedTypes)) {
        return false;
    }
    
    if ($file['size'] > $maxSize) {
        return false;
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'menu_' . time() . '_' . rand(1000, 9999) . '.' . $extension;
    $filepath = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return $filename;
    }
    
    return false;
}

function deleteImage(string $filename): void {
    $filepath = '../../assets/uploads/menu/' . $filename;
    if (file_exists($filepath)) {
        unlink($filepath);
    }
}

// ======================================================
// GET DATA
// ======================================================

$stmt = $pdo->query("SELECT m.*, c.name as category_name FROM menu_items m LEFT JOIN categories c ON m.category_id = c.id ORDER BY c.sort_order, m.name");
$menuItems = $stmt->fetchAll();
$categories = getAllCategories();

include '../../includes/header.php';
?>

<style>
/* ======================================================
   MENU MANAGEMENT STYLES
   ====================================================== */

.menu-container {
    max-width: 1200px;
    margin: 0 auto;
}

/* Quick Action Cards */
.quick-action-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 12px;
    padding: 20px;
}

.quick-action-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 16px;
    border: 2px solid #e0e0e0;
    border-radius: 12px;
    text-decoration: none;
    color: var(--text-dark);
    transition: all 0.3s ease;
    background: #f8f9fa;
}

.quick-action-card:hover {
    border-color: var(--primary);
    transform: translateY(-2px);
    box-shadow: var(--shadow);
    background: #fff;
}

.quick-action-card i {
    font-size: 1.8rem;
    margin-bottom: 8px;
    color: var(--primary);
}

.quick-action-card span {
    font-size: 0.85rem;
    font-weight: 500;
    text-align: center;
}

/* Menu Item Image Preview */
.menu-item-image {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 8px;
    background: #f0f2f5;
}

.menu-item-image-placeholder {
    width: 50px;
    height: 50px;
    border-radius: 8px;
    background: #f0f2f5;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ccc;
    font-size: 1.2rem;
}

.menu-item-image-preview {
    max-width: 150px;
    max-height: 150px;
    border-radius: 8px;
    border: 2px solid #e0e0e0;
    margin-top: 8px;
}

.image-upload-wrapper {
    position: relative;
    display: inline-block;
}

.image-upload-wrapper .upload-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    background: #f0f2f5;
    border: 2px dashed #ccc;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
    font-family: 'Poppins', sans-serif;
    font-size: 0.85rem;
    color: var(--text-light);
}

.image-upload-wrapper .upload-btn:hover {
    border-color: var(--primary);
    background: #f0f7f0;
}

.image-upload-wrapper input[type="file"] {
    position: absolute;
    opacity: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
}

/* Modal */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 2000;
    align-items: center;
    justify-content: center;
}

.modal-overlay.show {
    display: flex;
}

.modal {
    background: #fff;
    border-radius: var(--radius);
    padding: 32px;
    max-width: 550px;
    width: 95%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.modal-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: var(--text-light);
}

.modal-close:hover {
    color: var(--text-dark);
}

/* Form */
.form-group {
    margin-bottom: 16px;
}

.form-group label {
    display: block;
    font-size: 0.85rem;
    font-weight: 500;
    color: var(--text-dark);
    margin-bottom: 4px;
}

.form-group label .required {
    color: #e74c3c;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 10px 14px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-size: 0.95rem;
    transition: all 0.3s;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: var(--primary);
    outline: none;
    box-shadow: 0 0 0 3px rgba(44, 95, 45, 0.1);
}

.form-group textarea {
    resize: vertical;
    min-height: 60px;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}

@media (max-width: 768px) {
    .form-row {
        grid-template-columns: 1fr;
    }
}

.btn-primary {
    background: var(--primary);
    color: #fff;
    padding: 10px 24px;
    border: none;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-primary:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
}

.btn-secondary {
    background: #e0e0e0;
    color: var(--text-dark);
    padding: 10px 24px;
    border: none;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-secondary:hover {
    background: #d0d0d0;
}

.btn-danger {
    background: #e74c3c;
    color: #fff;
    padding: 6px 14px;
    border: none;
    border-radius: 6px;
    font-family: 'Poppins', sans-serif;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-danger:hover {
    background: #c0392b;
}

.btn-warning {
    background: var(--secondary);
    color: #fff;
    padding: 6px 14px;
    border: none;
    border-radius: 6px;
    font-family: 'Poppins', sans-serif;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-warning:hover {
    background: #d4951a;
}

.btn-sm {
    padding: 4px 10px;
    font-size: 0.75rem;
}

.btn-group {
    display: flex;
    gap: 12px;
    margin-top: 16px;
}

.btn-group .btn {
    flex: 1;
}

/* Table */
.table-container {
    background: var(--bg-card);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    overflow: hidden;
    margin-bottom: 24px;
}

.table-header {
    padding: 16px 24px;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
}

.table-header h3 {
    font-size: 1.1rem;
    color: var(--text-dark);
}

table {
    width: 100%;
    border-collapse: collapse;
}

table thead {
    background: #f8f9fa;
}

table th {
    padding: 12px 16px;
    text-align: left;
    font-size: 0.8rem;
    font-weight: 600;
    color: var(--text-light);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #eee;
}

table td {
    padding: 12px 16px;
    border-bottom: 1px solid #f0f0f0;
    font-size: 0.9rem;
    vertical-align: middle;
}

table tr:hover {
    background: #f8f9fa;
}

/* Badge */
.badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
    display: inline-block;
}

.badge-success { background: #d4edda; color: #155724; }
.badge-danger { background: #f8d7da; color: #721c24; }
.badge-warning { background: #fff3cd; color: #856404; }
.badge-info { background: #d1ecf1; color: #0c5460; }
.badge-primary { background: #cce5ff; color: #004085; }

/* Alert */
.alert {
    padding: 12px 20px;
    border-radius: var(--radius);
    margin-bottom: 16px;
    font-size: 0.9rem;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.alert-danger {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

/* Responsive */
@media (max-width: 768px) {
    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    table th, table td {
        padding: 8px 10px;
        font-size: 0.75rem;
    }
    .modal {
        padding: 20px;
    }
}
</style>

<div class="menu-container">
    <div class="page-header">
        <h2><i class="fas fa-utensils"></i> Menu Management</h2>
        <p>Manage your restaurant menu items with images</p>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <!-- Quick Actions -->
    <div class="table-container">
        <div class="table-header"><h3><i class="fas fa-bolt"></i> Quick Actions</h3></div>
        <div class="quick-action-grid">
            <button class="quick-action-card" onclick="showAddModal()">
                <i class="fas fa-plus-circle"></i>
                <span>Add Menu Item</span>
            </button>
            <a href="category_management.php" class="quick-action-card">
                <i class="fas fa-tags"></i>
                <span>Manage Categories</span>
            </a>
            <a href="view_stocks.php" class="quick-action-card">
                <i class="fas fa-warehouse"></i>
                <span>View Stocks</span>
            </a>
            <a href="dashboard.php" class="quick-action-card">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </div>
    </div>

    <!-- Menu Items Table -->
    <div class="table-container">
        <div class="table-header">
            <h3><i class="fas fa-list"></i> Menu Items</h3>
            <div style="display: flex; gap: 10px; align-items: center;">
                <span class="badge badge-primary"><?php echo count($menuItems); ?> items</span>
                <button class="btn-primary" onclick="showAddModal()" style="padding: 8px 16px; font-size: 0.85rem;">
                    <i class="fas fa-plus"></i> Add Item
                </button>
            </div>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th style="width: 60px;">Image</th>
                        <th>ID</th>
                        <th>Category</th>
                        <th>Item Name</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($menuItems)): ?>
                    <tr><td colspan="8" style="text-align: center; padding: 40px; color: var(--text-light);">
                        <i class="fas fa-utensils" style="font-size: 2rem; display: block; margin-bottom: 10px;"></i>
                        No menu items found. Add your first menu item!
                    </td></tr>
                    <?php else: ?>
                    <?php foreach ($menuItems as $item): ?>
                    <tr>
                        <td>
                            <?php if (!empty($item['image']) && file_exists('../../assets/uploads/menu/' . $item['image'])): ?>
                                <img src="<?php echo SITE_URL; ?>assets/uploads/menu/<?php echo htmlspecialchars($item['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($item['name']); ?>" 
                                     class="menu-item-image">
                            <?php else: ?>
                                <div class="menu-item-image-placeholder">
                                    <i class="fas fa-utensils"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>#<?php echo $item['id']; ?></td>
                        <td><span class="badge badge-primary"><?php echo htmlspecialchars($item['category_name']); ?></span></td>
                        <td><strong><?php echo htmlspecialchars($item['name']); ?></strong></td>
                        <td>₱<?php echo number_format($item['price'], 2); ?></td>
                        <td><?php echo $item['stock']; ?></td>
                        <td>
                            <?php
                            $statusClass = 'badge-success';
                            $statusText = 'Available';
                            if ($item['stock'] <= 0) { $statusClass = 'badge-danger'; $statusText = 'Out of Stock'; }
                            elseif ($item['stock'] <= 10) { $statusClass = 'badge-warning'; $statusText = 'Low Stock'; }
                            ?>
                            <span class="badge <?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                        </td>
                        <td>
                            <button class="btn-warning btn-sm" onclick='editItem(<?php echo json_encode($item); ?>)'>
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-danger btn-sm" onclick="deleteItem(<?php echo $item['id']; ?>, '<?php echo addslashes($item['name']); ?>')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="itemModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="modalTitle"><i class="fas fa-plus"></i> Add Menu Item</h3>
            <button class="modal-close" onclick="hideModal()">&times;</button>
        </div>
        <form method="POST" action="" enctype="multipart/form-data" id="itemForm">
            <input type="hidden" name="action" id="formAction" value="add">
            <input type="hidden" name="item_id" id="itemId" value="0">
            
            <div class="form-group">
                <label for="category_id">Category <span class="required">*</span></label>
                <select id="category_id" name="category_id" required>
                    <option value="">Select Category</option>
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="name">Item Name <span class="required">*</span></label>
                <input type="text" id="name" name="name" placeholder="Enter item name" required>
            </div>
            
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="2" placeholder="Enter description (optional)"></textarea>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="price">Price <span class="required">*</span></label>
                    <input type="number" id="price" name="price" step="0.01" min="0" placeholder="0.00" required>
                </div>
                <div class="form-group">
                    <label for="stock">Stock <span class="required">*</span></label>
                    <input type="number" id="stock" name="stock" min="0" placeholder="0" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="image">Item Image</label>
                <div class="image-upload-wrapper">
                    <label class="upload-btn" for="imageInput">
                        <i class="fas fa-camera"></i> Choose Image
                        <input type="file" id="imageInput" name="image" accept="image/*" onchange="previewImage(this)">
                    </label>
                    <small style="display: block; margin-top: 4px; color: var(--text-light); font-size: 0.75rem;">
                        Max size: 2MB. Allowed: JPG, PNG, GIF, WEBP
                    </small>
                </div>
                <div id="imagePreviewContainer" style="display: none; margin-top: 8px;">
                    <img id="imagePreview" class="menu-item-image-preview" alt="Preview">
                    <button type="button" onclick="removeImage()" style="display: block; margin-top: 4px; background: none; border: none; color: #e74c3c; cursor: pointer; font-size: 0.8rem;">
                        <i class="fas fa-times"></i> Remove Image
                    </button>
                </div>
                <input type="hidden" id="existingImage" name="existing_image" value="">
            </div>
            
            <div class="btn-group">
                <button type="submit" class="btn-primary" id="saveBtn">
                    <i class="fas fa-save"></i> Save Item
                </button>
                <button type="button" class="btn-secondary" onclick="hideModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal-overlay" id="deleteModal">
    <div class="modal" style="max-width: 400px;">
        <div class="modal-header">
            <h3 style="color: var(--accent);"><i class="fas fa-exclamation-triangle"></i> Delete Menu Item</h3>
            <button class="modal-close" onclick="hideDeleteModal()">&times;</button>
        </div>
        <form method="GET" action="" id="deleteForm">
            <input type="hidden" name="delete" id="deleteItemId" value="">
            <p>Are you sure you want to delete <strong id="deleteItemName"></strong>?</p>
            <p style="color: var(--text-light); font-size: 0.85rem; margin-top: 8px;">This action cannot be undone.</p>
            <div class="btn-group" style="margin-top: 16px;">
                <button type="submit" class="btn-danger" style="flex: 1; padding: 10px;"><i class="fas fa-trash"></i> Delete</button>
                <button type="button" class="btn-secondary" onclick="hideDeleteModal()" style="flex: 1; padding: 10px;">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
// ======================================================
// MODAL FUNCTIONS
// ======================================================

function showAddModal() {
    document.getElementById('modalTitle').innerHTML = '<i class="fas fa-plus"></i> Add Menu Item';
    document.getElementById('formAction').value = 'add';
    document.getElementById('itemId').value = '0';
    document.getElementById('category_id').value = '';
    document.getElementById('name').value = '';
    document.getElementById('description').value = '';
    document.getElementById('price').value = '';
    document.getElementById('stock').value = '';
    document.getElementById('existingImage').value = '';
    document.getElementById('imagePreviewContainer').style.display = 'none';
    document.getElementById('imageInput').value = '';
    document.getElementById('itemModal').classList.add('show');
}

function editItem(item) {
    document.getElementById('modalTitle').innerHTML = '<i class="fas fa-edit"></i> Edit Menu Item';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('itemId').value = item.id;
    document.getElementById('category_id').value = item.category_id;
    document.getElementById('name').value = item.name;
    document.getElementById('description').value = item.description || '';
    document.getElementById('price').value = item.price;
    document.getElementById('stock').value = item.stock;
    document.getElementById('existingImage').value = item.image || '';
    
    // Show existing image preview
    if (item.image) {
        const previewContainer = document.getElementById('imagePreviewContainer');
        const preview = document.getElementById('imagePreview');
        preview.src = '<?php echo SITE_URL; ?>assets/uploads/menu/' + item.image;
        previewContainer.style.display = 'block';
    } else {
        document.getElementById('imagePreviewContainer').style.display = 'none';
    }
    
    document.getElementById('imageInput').value = '';
    document.getElementById('itemModal').classList.add('show');
}

function hideModal() {
    document.getElementById('itemModal').classList.remove('show');
}

function showDeleteModal(id, name) {
    document.getElementById('deleteItemId').value = id;
    document.getElementById('deleteItemName').textContent = name;
    document.getElementById('deleteModal').classList.add('show');
}

function hideDeleteModal() {
    document.getElementById('deleteModal').classList.remove('show');
}

function deleteItem(id, name) {
    showDeleteModal(id, name);
}

// ======================================================
// IMAGE PREVIEW
// ======================================================

function previewImage(input) {
    const previewContainer = document.getElementById('imagePreviewContainer');
    const preview = document.getElementById('imagePreview');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            previewContainer.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        // Check if there's an existing image
        const existingImage = document.getElementById('existingImage').value;
        if (existingImage) {
            preview.src = '<?php echo SITE_URL; ?>assets/uploads/menu/' + existingImage;
            previewContainer.style.display = 'block';
        } else {
            previewContainer.style.display = 'none';
        }
    }
}

function removeImage() {
    document.getElementById('imageInput').value = '';
    document.getElementById('imagePreviewContainer').style.display = 'none';
    document.getElementById('existingImage').value = '';
}

// ======================================================
// CLOSE MODALS ON OUTSIDE CLICK
// ======================================================

document.getElementById('itemModal').addEventListener('click', function(e) {
    if (e.target === this) hideModal();
});

document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) hideDeleteModal();
});

// ======================================================
// CLOSE MODALS WITH ESC KEY
// ======================================================

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        hideModal();
        hideDeleteModal();
    }
});
</script>

<?php include '../../includes/footer.php'; ?>