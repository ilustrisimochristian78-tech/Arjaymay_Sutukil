<?php
require_once '../../config/database.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$orderId = (int)($_POST['order_id'] ?? 0);
$status = $_POST['status'] ?? '';

$validStatuses = ['pending', 'preparing', 'ready', 'served'];
if (!in_array($status, $validStatuses)) {
    echo json_encode(['success' => false, 'error' => 'Invalid status']);
    exit;
}

if ($orderId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid order ID']);
    exit;
}

$pdo = getDBConnection();

try {
    if ($status === 'served') {
        // When the kitchen marks an order served, it's complete: close it out.
        $stmt = $pdo->prepare("UPDATE orders SET kitchen_status = ?, status = 'completed' WHERE id = ?");
    } else {
        $stmt = $pdo->prepare("UPDATE orders SET kitchen_status = ? WHERE id = ?");
    }
    $stmt->execute([$status, $orderId]);
    
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'kitchen_update', ?)");
    $stmt->execute([$_SESSION['user_id'], "Order #$orderId status updated to: $status"]);
    
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>