<?php
require_once '../../config/database.php';
requireCashier();

$pdo = getDBConnection();

$stmt = $pdo->query("SELECT o.*, u.full_name as cashier_name FROM orders o LEFT JOIN users u ON o.cashier_id = u.id WHERE o.kitchen_status = 'pending' AND o.status != 'cancelled' ORDER BY o.created_at ASC");
$pendingOrders = $stmt->fetchAll();

$stmt = $pdo->query("SELECT o.*, u.full_name as cashier_name FROM orders o LEFT JOIN users u ON o.cashier_id = u.id WHERE o.kitchen_status = 'preparing' AND o.status != 'cancelled' ORDER BY o.created_at ASC");
$preparingOrders = $stmt->fetchAll();

$stmt = $pdo->query("SELECT o.*, u.full_name as cashier_name FROM orders o LEFT JOIN users u ON o.cashier_id = u.id WHERE o.kitchen_status = 'ready' AND o.status != 'cancelled' ORDER BY o.created_at ASC");
$readyOrders = $stmt->fetchAll();

include '../../includes/header.php';
?>

<div class="page-header">
    <h2><i class="fas fa-kitchen-set"></i> Kitchen Display</h2>
    <p>Monitor and manage kitchen orders</p>
</div>

<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;">
    <!-- Pending -->
    <div class="table-container">
        <div class="table-header" style="background: #fff3cd; border-bottom: 3px solid var(--secondary);">
            <h3><i class="fas fa-clock" style="color: var(--secondary);"></i> Pending</h3>
            <span class="badge badge-warning"><?php echo count($pendingOrders); ?></span>
        </div>
        <div style="max-height: 500px; overflow-y: auto;">
            <?php if (empty($pendingOrders)): ?>
            <div style="padding: 20px; text-align: center; color: var(--text-light);">No pending orders</div>
            <?php else: ?>
            <?php foreach ($pendingOrders as $order): ?>
            <div style="padding: 12px 16px; border-bottom: 1px solid #f0f0f0; background: #fffef7;">
                <div style="display: flex; justify-content: space-between;">
                    <strong style="color: var(--secondary);">#<?php echo $order['order_number']; ?></strong>
                    <span style="font-size: 0.8rem; color: var(--text-light);"><?php echo date('h:i A', strtotime($order['created_at'])); ?></span>
                </div>
                <div style="font-size: 0.85rem;"><?php echo formatCurrency($order['total']); ?> <span class="badge badge-info"><?php echo $order['order_type']; ?></span></div>
                <button class="btn btn-primary btn-sm" style="margin-top: 6px; width: 100%;" onclick="updateStatus(<?php echo $order['id']; ?>, 'preparing')"><i class="fas fa-utensils"></i> Start Preparing</button>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Preparing -->
    <div class="table-container">
        <div class="table-header" style="background: #cce5ff; border-bottom: 3px solid #3498db;">
            <h3><i class="fas fa-utensils" style="color: #3498db;"></i> Preparing</h3>
            <span class="badge badge-primary"><?php echo count($preparingOrders); ?></span>
        </div>
        <div style="max-height: 500px; overflow-y: auto;">
            <?php if (empty($preparingOrders)): ?>
            <div style="padding: 20px; text-align: center; color: var(--text-light);">No orders preparing</div>
            <?php else: ?>
            <?php foreach ($preparingOrders as $order): ?>
            <div style="padding: 12px 16px; border-bottom: 1px solid #f0f0f0; background: #f0f7ff;">
                <div style="display: flex; justify-content: space-between;">
                    <strong style="color: #3498db;">#<?php echo $order['order_number']; ?></strong>
                    <span style="font-size: 0.8rem; color: var(--text-light);"><?php echo date('h:i A', strtotime($order['created_at'])); ?></span>
                </div>
                <div style="font-size: 0.85rem;"><?php echo formatCurrency($order['total']); ?> <span class="badge badge-info"><?php echo $order['order_type']; ?></span></div>
                <button class="btn btn-success btn-sm" style="margin-top: 6px; width: 100%;" onclick="updateStatus(<?php echo $order['id']; ?>, 'ready')"><i class="fas fa-check"></i> Mark as Ready</button>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Ready -->
    <div class="table-container">
        <div class="table-header" style="background: #d4edda; border-bottom: 3px solid var(--primary);">
            <h3><i class="fas fa-check-circle" style="color: var(--primary);"></i> Ready</h3>
            <span class="badge badge-success"><?php echo count($readyOrders); ?></span>
        </div>
        <div style="max-height: 500px; overflow-y: auto;">
            <?php if (empty($readyOrders)): ?>
            <div style="padding: 20px; text-align: center; color: var(--text-light);">No orders ready</div>
            <?php else: ?>
            <?php foreach ($readyOrders as $order): ?>
            <div style="padding: 12px 16px; border-bottom: 1px solid #f0f0f0; background: #f0fff4;">
                <div style="display: flex; justify-content: space-between;">
                    <strong style="color: var(--primary);">#<?php echo $order['order_number']; ?></strong>
                    <span style="font-size: 0.8rem; color: var(--text-light);"><?php echo date('h:i A', strtotime($order['created_at'])); ?></span>
                </div>
                <div style="font-size: 0.85rem;"><?php echo formatCurrency($order['total']); ?> <span class="badge badge-info"><?php echo $order['order_type']; ?></span></div>
                <button class="btn btn-secondary btn-sm" style="margin-top: 6px; width: 100%;" onclick="updateStatus(<?php echo $order['id']; ?>, 'served')"><i class="fas fa-check-double"></i> Serve</button>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function updateStatus(orderId, status) {
    var params = new URLSearchParams({ order_id: orderId, status: status });
    fetch('../api/update_order_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString(),
        credentials: 'same-origin'
    })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.success) { location.reload(); }
            else { alert('Error: ' + data.error); }
        })
        .catch(function() { alert('Error updating order status!'); });
}
</script>

<?php include '../../includes/footer.php'; ?>