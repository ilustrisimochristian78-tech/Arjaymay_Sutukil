<?php
// ======================================================
// CASHIER DASHBOARD - PROFESSIONAL DESIGN
// ======================================================

// First include the database file
require_once '../../config/database.php';

// Now the functions are available
requireCashier();

$pdo = getDBConnection();
$today = getCurrentDate();
$report = getDailySalesReport($today);

$stmt = $pdo->query("SELECT COUNT(*) as count FROM menu_items WHERE stock <= 10 AND stock > 0");
$lowStock = $stmt->fetch()['count'];
$stmt = $pdo->query("SELECT COUNT(*) as count FROM menu_items WHERE stock <= 0");
$outOfStock = $stmt->fetch()['count'];

// ======================================================
// BEST SELLING ITEMS (Today) - WITH IMAGES
// ======================================================
$stmt = $pdo->prepare("
    SELECT 
        m.id,
        m.name,
        m.price,
        m.stock,
        m.image,
        c.name as category_name,
        SUM(oi.quantity) as total_quantity,
        SUM(oi.subtotal) as total_sales
    FROM order_items oi
    JOIN menu_items m ON oi.menu_item_id = m.id
    JOIN categories c ON m.category_id = c.id
    JOIN orders o ON oi.order_id = o.id
    WHERE DATE(o.created_at) = CURDATE() 
    AND o.status = 'completed'
    GROUP BY m.id, m.name, m.price, m.stock, m.image, c.name
    ORDER BY total_quantity DESC
    LIMIT 5
");
$stmt->execute();
$bestSellingToday = $stmt->fetchAll();

// ======================================================
// BEST SELLING ITEMS (This Week) - WITH IMAGES
// ======================================================
$stmt = $pdo->prepare("
    SELECT 
        m.id,
        m.name,
        m.price,
        m.stock,
        m.image,
        SUM(oi.quantity) as total_quantity,
        SUM(oi.subtotal) as total_sales
    FROM order_items oi
    JOIN menu_items m ON oi.menu_item_id = m.id
    JOIN orders o ON oi.order_id = o.id
    WHERE WEEK(o.created_at) = WEEK(CURDATE()) 
    AND YEAR(o.created_at) = YEAR(CURDATE())
    AND o.status = 'completed'
    GROUP BY m.id, m.name, m.price, m.stock, m.image
    ORDER BY total_quantity DESC
    LIMIT 5
");
$stmt->execute();
$bestSellingWeek = $stmt->fetchAll();

// ======================================================
// BEST SELLING ITEMS (This Month)
// ======================================================
$stmt = $pdo->prepare("
    SELECT 
        m.id,
        m.name,
        m.price,
        m.stock,
        m.image,
        SUM(oi.quantity) as total_quantity,
        SUM(oi.subtotal) as total_sales
    FROM order_items oi
    JOIN menu_items m ON oi.menu_item_id = m.id
    JOIN orders o ON oi.order_id = o.id
    WHERE MONTH(o.created_at) = MONTH(CURDATE()) 
    AND YEAR(o.created_at) = YEAR(CURDATE())
    AND o.status = 'completed'
    GROUP BY m.id, m.name, m.price, m.stock, m.image
    ORDER BY total_quantity DESC
    LIMIT 5
");
$stmt->execute();
$bestSellingMonth = $stmt->fetchAll();

// ======================================================
// SALES SUMMARY: Daily / Weekly / Monthly totals, split by
// order type, for the Sales Summary pie chart below.
// ======================================================
$todayDate = new DateTime($today);
$weekStart = (clone $todayDate)->modify('monday this week')->format('Y-m-d');
$weekEnd = (clone $todayDate)->modify('sunday this week')->format('Y-m-d');
$monthStart = (clone $todayDate)->modify('first day of this month')->format('Y-m-d');
$monthEnd = (clone $todayDate)->modify('last day of this month')->format('Y-m-d');

$salesSummary = [
    'daily'   => $report,
    'weekly'  => getRangeSalesReport($weekStart, $weekEnd),
    'monthly' => getRangeSalesReport($monthStart, $monthEnd),
];

// ======================================================
// RECENT ORDERS
// ======================================================
$stmt = $pdo->prepare("
    SELECT o.*, u.full_name as cashier_name
    FROM orders o
    LEFT JOIN users u ON o.cashier_id = u.id
    WHERE o.cashier_id = ?
    ORDER BY o.created_at DESC
    LIMIT 10
");
$stmt->execute([$_SESSION['user_id']]);
$recentOrders = $stmt->fetchAll();

include '../../includes/header.php';
?>

<style>
/* ======================================================
   PROFESSIONAL CASHIER DASHBOARD
   ====================================================== */

:root {
    --primary: #2c5f2d;
    --primary-light: #3d8b40;
    --primary-dark: #1a3d1b;
    --secondary: #f5a623;
    --accent: #e74c3c;
    --bg-light: #f0f2f5;
    --bg-card: #ffffff;
    --text-dark: #2d3436;
    --text-light: #636e72;
    --shadow: 0 2px 12px rgba(0,0,0,0.08);
    --radius: 12px;
    --transition: all 0.3s ease;
}

.dashboard-wrapper {
    max-width: 1400px;
    margin: 0 auto;
}

/* Page Header */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
    margin-bottom: 24px;
}

.page-header h1 {
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--text-dark);
    margin: 0;
}

.page-header h1 small {
    font-size: 0.9rem;
    font-weight: 400;
    color: var(--text-light);
}

.page-header .header-actions {
    display: flex;
    gap: 10px;
}

.page-header .header-actions .btn {
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-weight: 500;
    cursor: pointer;
    transition: var(--transition);
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-primary {
    background: var(--primary);
    color: #fff;
}

.btn-primary:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(44, 95, 45, 0.3);
}

.btn-secondary {
    background: var(--bg-light);
    color: var(--text-dark);
}

.btn-secondary:hover {
    background: #e0e0e0;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 20px 24px;
    box-shadow: var(--shadow);
    transition: var(--transition);
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.12);
}

.stat-card .stat-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 8px;
}

.stat-card .stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    color: #fff;
}

.stat-icon.green { background: var(--primary); }
.stat-icon.blue { background: #3498db; }
.stat-icon.orange { background: var(--secondary); }
.stat-icon.purple { background: #9b59b6; }

.stat-card .stat-value {
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--text-dark);
}

.stat-card .stat-label {
    font-size: 0.85rem;
    color: var(--text-light);
}

/* Quick Actions */
.quick-actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 12px;
    padding: 20px;
}

.quick-action-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px 16px;
    background: #f8f9fa;
    border-radius: 10px;
    text-decoration: none;
    color: var(--text-dark);
    transition: var(--transition);
    border: 2px solid transparent;
    text-align: center;
}

.quick-action-card:hover {
    border-color: var(--primary);
    background: #fff;
    transform: translateY(-4px);
    box-shadow: var(--shadow);
}

.quick-action-card i {
    font-size: 2rem;
    margin-bottom: 8px;
    color: var(--primary);
}

.quick-action-card span {
    font-size: 0.85rem;
    font-weight: 500;
}

.quick-action-card small {
    font-size: 0.65rem;
    color: var(--text-light);
    margin-top: 2px;
}

/* Best Seller Grid */
.best-seller-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
    gap: 15px;
    padding: 15px;
}

.best-seller-card {
    background: #fff;
    border: 1px solid #e0e0e0;
    border-radius: var(--radius);
    overflow: hidden;
    transition: var(--transition);
    position: relative;
    cursor: pointer;
}

.best-seller-card:hover {
    border-color: var(--primary);
    transform: translateY(-4px);
    box-shadow: 0 8px 25px rgba(44, 95, 45, 0.15);
}

.best-seller-card:active {
    transform: scale(0.97);
}

.best-seller-card .card-image {
    width: 100%;
    height: 130px;
    object-fit: cover;
    background: #f0f2f5;
}

.best-seller-card .card-image-placeholder {
    width: 100%;
    height: 130px;
    background: linear-gradient(135deg, #f0f2f5, #e8eaed);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    color: #ccc;
}

.best-seller-card .rank {
    position: absolute;
    top: 8px;
    left: 8px;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 0.75rem;
    color: #fff;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    z-index: 1;
}

.rank.gold { background: #f39c12; }
.rank.silver { background: #bdc3c7; color: #2c3e50; }
.rank.bronze { background: #e67e22; }
.rank.default { background: var(--primary); }

.best-seller-card .card-body {
    padding: 10px 12px 12px;
}

.best-seller-card .item-name {
    font-weight: 600;
    font-size: 0.85rem;
    color: var(--text-dark);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.best-seller-card .item-category {
    font-size: 0.6rem;
    color: var(--text-light);
    background: #f0f2f5;
    padding: 1px 8px;
    border-radius: 10px;
    display: inline-block;
    margin-bottom: 2px;
}

.best-seller-card .item-price {
    font-size: 0.9rem;
    font-weight: 700;
    color: var(--primary);
}

.best-seller-card .item-stats {
    display: flex;
    justify-content: space-between;
    padding-top: 6px;
    border-top: 1px solid #f0f0f0;
    font-size: 0.65rem;
    color: var(--text-light);
    margin-top: 4px;
}

.best-seller-card .item-stats .qty {
    color: var(--primary);
    font-weight: 600;
}

.best-seller-card .item-stats .sales {
    color: #2980b9;
    font-weight: 600;
}

.best-seller-card .stock-badge {
    font-size: 0.55rem;
    padding: 1px 8px;
    border-radius: 10px;
    background: #d4edda;
    color: #155724;
    display: inline-block;
    margin-top: 3px;
}

.best-seller-card .stock-badge.low {
    background: #fff3cd;
    color: #856404;
}

.best-seller-card .stock-badge.out {
    background: #f8d7da;
    color: #721c24;
}

.best-seller-card .add-hint {
    font-size: 0.55rem;
    color: var(--text-light);
    margin-top: 3px;
    opacity: 0;
    transition: opacity 0.3s;
}

.best-seller-card:hover .add-hint {
    opacity: 1;
}

.best-seller-card .quick-add-btn {
    position: absolute;
    bottom: -10px;
    right: 10px;
    background: var(--primary);
    color: #fff;
    border: none;
    border-radius: 50%;
    width: 28px;
    height: 28px;
    font-size: 0.8rem;
    cursor: pointer;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 10px rgba(44, 95, 45, 0.3);
    z-index: 2;
}

.best-seller-card .quick-add-btn:hover {
    transform: scale(1.1);
    background: var(--primary-dark);
}

.best-seller-card.out-of-stock {
    opacity: 0.6;
    cursor: not-allowed;
}

.best-seller-card.out-of-stock:hover {
    transform: none;
    box-shadow: none;
}

.empty-sellers {
    text-align: center;
    padding: 40px;
    color: var(--text-light);
    grid-column: 1 / -1;
}

.empty-sellers i {
    font-size: 2rem;
    display: block;
    margin-bottom: 8px;
    color: #ddd;
}

/* Table Container */
.table-container {
    background: var(--bg-card);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    overflow: hidden;
    margin-bottom: 24px;
}

.table-header {
    padding: 14px 20px;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}

.table-header h3 {
    font-size: 0.95rem;
    font-weight: 600;
    color: var(--text-dark);
    margin: 0;
}

.table-header .badge {
    background: var(--primary);
    color: #fff;
    padding: 2px 12px;
    border-radius: 20px;
    font-size: 0.7rem;
}

.table-responsive {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table thead {
    background: #f8f9fa;
}

table th {
    padding: 10px 14px;
    text-align: left;
    font-size: 0.7rem;
    font-weight: 600;
    color: var(--text-light);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #eee;
}

table td {
    padding: 10px 14px;
    border-bottom: 1px solid #f0f0f0;
    font-size: 0.82rem;
}

table tr:hover {
    background: #f8f9fa;
}

/* Badges */
.badge-status {
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 0.65rem;
    font-weight: 500;
    display: inline-block;
}

.badge-status.success { background: #d4edda; color: #155724; }
.badge-status.danger { background: #f8d7da; color: #721c24; }
.badge-status.warning { background: #fff3cd; color: #856404; }
.badge-status.info { background: #d1ecf1; color: #0c5460; }
.badge-status.primary { background: #cce5ff; color: #004085; }

/* Action Buttons */
.btn-action {
    padding: 5px 8px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: var(--transition);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 0.75rem;
}

.btn-action:hover {
    transform: scale(1.05);
}

.btn-eye {
    background: #3498db;
    color: #fff;
}

.btn-eye:hover {
    background: #2980b9;
}

.btn-receipt {
    background: #27ae60;
    color: #fff;
}

.btn-receipt:hover {
    background: #1e8449;
}

/* Quantity Modal */
.quantity-modal-bestseller {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 10001;
    align-items: center;
    justify-content: center;
}

.quantity-modal-bestseller.show {
    display: flex;
}

.quantity-modal-bestseller .modal-content {
    background: #fff;
    border-radius: 16px;
    padding: 30px;
    max-width: 380px;
    width: 90%;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    animation: modalSlideIn 0.3s ease;
}

.quantity-modal-bestseller .modal-content h3 {
    text-align: center;
    margin-bottom: 5px;
    color: #2c5f2d;
}

.quantity-modal-bestseller .modal-content .item-name-display {
    text-align: center;
    font-size: 1.1rem;
    color: var(--text-dark);
    margin-bottom: 5px;
    font-weight: 500;
}

.quantity-modal-bestseller .modal-content .item-price-display {
    text-align: center;
    font-size: 0.9rem;
    color: var(--text-light);
    margin-bottom: 15px;
}

.quantity-modal-bestseller .modal-content .stock-info {
    text-align: center;
    font-size: 0.8rem;
    color: var(--text-light);
    margin-bottom: 15px;
}

.quantity-modal-bestseller .modal-content .stock-info .available {
    color: #2c5f2d;
    font-weight: 600;
}

.quantity-modal-bestseller .modal-content .quantity-control {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    margin: 20px 0;
}

.quantity-modal-bestseller .modal-content .quantity-control button {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    border: 2px solid #e0e0e0;
    background: #f8f9fa;
    font-size: 1.3rem;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    color: var(--text-dark);
}

.quantity-modal-bestseller .modal-content .quantity-control button:hover {
    border-color: #2c5f2d;
    background: #f0f7f0;
}

.quantity-modal-bestseller .modal-content .quantity-control button:disabled {
    opacity: 0.4;
    cursor: not-allowed;
}

.quantity-modal-bestseller .modal-content .quantity-control .quantity-display {
    font-size: 1.8rem;
    font-weight: 700;
    min-width: 50px;
    text-align: center;
    color: var(--text-dark);
}

.quantity-modal-bestseller .modal-content .btn-group {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}

.quantity-modal-bestseller .modal-content .btn-group button {
    flex: 1;
    padding: 12px;
    border: none;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
}

.quantity-modal-bestseller .modal-content .btn-group .btn-add {
    background: #2c5f2d;
    color: #fff;
}

.quantity-modal-bestseller .modal-content .btn-group .btn-add:hover {
    background: #1a3d1b;
}

.quantity-modal-bestseller .modal-content .btn-group .btn-add:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.quantity-modal-bestseller .modal-content .btn-group .btn-cancel-qty {
    background: #e0e0e0;
    color: #333;
}

@keyframes modalSlideIn {
    from { transform: translateY(-30px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

/* Responsive */
@media (max-width: 992px) {
    .best-seller-grid {
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    }
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr 1fr;
    }
    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }
    .quick-actions-grid {
        grid-template-columns: 1fr 1fr;
    }
    .best-seller-grid {
        grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    }
}

@media (max-width: 480px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    .quick-actions-grid {
        grid-template-columns: 1fr;
    }
    .best-seller-grid {
        grid-template-columns: 1fr 1fr;
    }
}
</style>

<div class="dashboard-wrapper">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1>
                <i class="fas fa-tachometer-alt" style="color: var(--primary);"></i> 
                Dashboard
                <small>Welcome back, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Cashier'); ?></small>
            </h1>
        </div>
        <div class="header-actions">
            <a href="new_order.php?type=dine_in" class="btn btn-primary">
                <i class="fas fa-chair"></i> New Order
            </a>
            <a href="kitchen_display.php" class="btn btn-secondary">
                <i class="fas fa-kitchen-set"></i> Kitchen
            </a>
            <a href="search_transaction.php" class="btn btn-secondary">
                <i class="fas fa-search"></i> Search
            </a>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-top">
                <div class="stat-icon green"><i class="fas fa-shopping-cart"></i></div>
            </div>
            <div class="stat-value"><?php echo $report['total_orders'] ?? 0; ?></div>
            <div class="stat-label">Today's Orders</div>
        </div>
        <div class="stat-card">
            <div class="stat-top">
                <div class="stat-icon blue"><i class="fas fa-money-bill-wave"></i></div>
            </div>
            <div class="stat-value">₱<?php echo number_format($report['total_sales'] ?? 0, 2); ?></div>
            <div class="stat-label">Today's Sales</div>
        </div>
        <div class="stat-card">
            <div class="stat-top">
                <div class="stat-icon orange"><i class="fas fa-boxes"></i></div>
            </div>
            <div class="stat-value"><?php echo $report['dine_in_orders'] ?? 0; ?></div>
            <div class="stat-label">Dine In</div>
        </div>
        <div class="stat-card">
            <div class="stat-top">
                <div class="stat-icon purple"><i class="fas fa-shopping-bag"></i></div>
            </div>
            <div class="stat-value"><?php echo $report['takeout_orders'] ?? 0; ?></div>
            <div class="stat-label">Take Out</div>
        </div>
    </div>

    <!-- Best Seller -->
    <div class="table-container">
        <div class="table-header">
            <h3><i class="fas fa-trophy" style="color: #f39c12;"></i> Best Sellers</h3>
            <div style="display: flex; align-items: center; gap: 12px;">
                <div class="bs-tabs">
                    <button class="bs-tab active" data-grid-tab="today" onclick="switchBestSellerGrid('today')">Today</button>
                    <button class="bs-tab" data-grid-tab="week" onclick="switchBestSellerGrid('week')">This Week</button>
                    <button class="bs-tab" data-grid-tab="month" onclick="switchBestSellerGrid('month')">This Month</button>
                </div>
                <span class="badge">Top 5</span>
            </div>
        </div>
        <?php
        $bestSellerGridPanels = ['today' => $bestSellingToday, 'week' => $bestSellingWeek, 'month' => $bestSellingMonth];
        foreach ($bestSellerGridPanels as $gridTabKey => $gridItems):
        ?>
        <div class="best-seller-grid bs-grid-panel" id="bsGridPanel-<?php echo $gridTabKey; ?>" style="<?php echo $gridTabKey !== 'today' ? 'display:none;' : ''; ?>">
            <?php if (empty($gridItems)): ?>
            <div class="empty-sellers">
                <i class="fas fa-chart-line"></i>
                <p>No sales data yet</p>
            </div>
            <?php else: ?>
            <?php 
            $rank = 1;
            $rankClasses = ['gold', 'silver', 'bronze'];
            foreach ($gridItems as $item): 
                $rankClass = isset($rankClasses[$rank-1]) ? $rankClasses[$rank-1] : 'default';
                $isOutOfStock = $item['stock'] <= 0;
                $imagePath = !empty($item['image']) && file_exists('../../assets/uploads/menu/' . $item['image']) ? SITE_URL . 'assets/uploads/menu/' . $item['image'] : '';
            ?>
            <div class="best-seller-card <?php echo $isOutOfStock ? 'out-of-stock' : ''; ?>" 
                 onclick="<?php echo !$isOutOfStock ? "openBestSellerQty(" . $item['id'] . ", '" . addslashes($item['name']) . "', " . $item['price'] . ", " . $item['stock'] . ")" : ''; ?>"
                 title="<?php echo $isOutOfStock ? 'Out of Stock' : 'Click to add to cart'; ?>">
                <div class="rank <?php echo $rankClass; ?>">#<?php echo $rank; ?></div>
                
                <?php if ($imagePath): ?>
                    <img src="<?php echo $imagePath; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="card-image" onerror="this.style.display='none'">
                <?php else: ?>
                    <div class="card-image-placeholder"><i class="fas fa-utensils"></i></div>
                <?php endif; ?>
                
                <div class="card-body">
                    <div class="item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                    <div class="item-category"><?php echo htmlspecialchars($item['category_name'] ?? ''); ?></div>
                    <div class="item-price">₱<?php echo number_format($item['price'], 2); ?></div>
                    <div class="item-stats">
                        <span class="qty"><?php echo $item['total_quantity']; ?> sold</span>
                        <span class="sales">₱<?php echo number_format($item['total_sales'], 2); ?></span>
                    </div>
                </div>
                <button class="quick-add-btn" onclick="event.stopPropagation(); <?php echo !$isOutOfStock ? "openBestSellerQty(" . $item['id'] . ", '" . addslashes($item['name']) . "', " . $item['price'] . ", " . $item['stock'] . ")" : ''; ?>">
                    <i class="fas fa-plus"></i>
                </button>
            </div>
            <?php 
            $rank++; 
            endforeach; 
            ?>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Best Sellers Chart -->
    <div class="table-container">
        <div class="table-header">
            <h3><i class="fas fa-chart-bar" style="color: #f39c12;"></i> Best Sellers Chart</h3>
            <div class="bs-tabs">
                <button class="bs-tab active" data-tab="today" onclick="switchBSTab('today')">Today</button>
                <button class="bs-tab" data-tab="week" onclick="switchBSTab('week')">This Week</button>
                <button class="bs-tab" data-tab="month" onclick="switchBSTab('month')">This Month</button>
            </div>
        </div>
        <div style="padding: 16px 20px; overflow-x: auto;">
            <canvas id="bestSellersBarChart" height="200"></canvas>
        </div>
    </div>

    <!-- Sales Summary: Daily / Weekly / Monthly -->
    <div class="table-container">
        <div class="table-header">
            <h3><i class="fas fa-chart-pie" style="color: var(--primary);"></i> Sales Summary</h3>
            <div class="bs-tabs">
                <button class="bs-tab active" data-ss-tab="daily" onclick="switchSalesSummary('daily')">Daily</button>
                <button class="bs-tab" data-ss-tab="weekly" onclick="switchSalesSummary('weekly')">Weekly</button>
                <button class="bs-tab" data-ss-tab="monthly" onclick="switchSalesSummary('monthly')">Monthly</button>
            </div>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0;" class="ss-layout">
            <div style="padding: 20px;">
                <div class="ss-stats-grid">
                    <div class="ss-stat">
                        <div class="ss-stat-label">Total Sales</div>
                        <div class="ss-stat-value" id="ssTotalSales">₱0.00</div>
                    </div>
                    <div class="ss-stat">
                        <div class="ss-stat-label">Total Orders</div>
                        <div class="ss-stat-value" id="ssTotalOrders">0</div>
                    </div>
                    <div class="ss-stat">
                        <div class="ss-stat-label"><span style="color:#2c5f2d;">&#9679;</span> Dine In</div>
                        <div class="ss-stat-value" id="ssDineIn">₱0.00</div>
                    </div>
                    <div class="ss-stat">
                        <div class="ss-stat-label"><span style="color:#f5a623;">&#9679;</span> Take Out</div>
                        <div class="ss-stat-value" id="ssTakeout">₱0.00</div>
                    </div>
                </div>
            </div>
            <div style="padding: 16px 20px; border-left: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: center;">
                <canvas id="salesSummaryPieChart" width="260" height="260"></canvas>
            </div>
        </div>
    </div>

    <style>
    .bs-tabs { display: flex; gap: 6px; }
    .bs-tab {
        border: none; background: var(--bg-light); color: var(--text-dark);
        padding: 6px 14px; border-radius: 20px; font-size: 0.78rem; font-weight: 500;
        cursor: pointer; font-family: 'Poppins', sans-serif; transition: var(--transition);
    }
    .bs-tab.active { background: var(--primary); color: #fff; }
    .ss-stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .ss-stat { background: var(--bg-light); border-radius: 10px; padding: 14px 16px; }
    .ss-stat-label { font-size: 0.75rem; color: var(--text-light); font-weight: 500; margin-bottom: 6px; }
    .ss-stat-value { font-size: 1.15rem; font-weight: 700; color: var(--text-dark); }
    @media (max-width: 768px) {
        .ss-layout { grid-template-columns: 1fr !important; }
        .ss-layout > div:last-child { border-left: none !important; border-top: 1px solid #f0f0f0; }
    }
    </style>

    <!-- Recent Orders -->
    <div class="table-container">
        <div class="table-header">
            <h3><i class="fas fa-clock" style="color: var(--primary);"></i> Your Recent Orders</h3>
            <span class="badge"><?php echo count($recentOrders); ?> orders</span>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ORDER #</th>
                        <th>TYPE</th>
                        <th>TOTAL</th>
                        <th>STATUS</th>
                        <th>DATE/TIME</th>
                        <th>ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recentOrders)): ?>
                    <tr><td colspan="6" style="text-align: center; padding: 30px; color: var(--text-light);">
                        <i class="fas fa-receipt" style="font-size: 2rem; display: block; margin-bottom: 8px;"></i>
                        No orders yet
                    </td></tr>
                    <?php else: ?>
                    <?php foreach ($recentOrders as $order): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($order['order_number']); ?></strong></td>
                        <td>
                            <span class="badge-status <?php echo $order['order_type'] == 'dine_in' ? 'primary' : 'warning'; ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $order['order_type'])); ?>
                            </span>
                        </td>
                        <td><strong>₱<?php echo number_format($order['total'], 2); ?></strong></td>
                        <td>
                            <span class="badge-status <?php echo $order['status'] == 'completed' ? 'success' : 'warning'; ?>">
                                <?php echo ucfirst($order['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('M d, Y h:i A', strtotime($order['created_at'])); ?></td>
                        <td>
                            <button class="btn-action btn-eye view-receipt" 
                                    data-order="<?php echo $order['id']; ?>" 
                                    data-order-number="<?php echo $order['order_number']; ?>"
                                    title="View Receipt">
                                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                            </button>
                            <button class="btn-action btn-receipt print-receipt" 
                                    data-order="<?php echo $order['id']; ?>" 
                                    data-order-number="<?php echo $order['order_number']; ?>"
                                    title="Print Receipt">
                                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Quantity Modal -->
<div class="quantity-modal-bestseller" id="bestSellerQtyModal">
    <div class="modal-content">
        <h3><i class="fas fa-plus-circle"></i> Enter Quantity</h3>
        <div class="item-name-display" id="bsQtyItemName">Item Name</div>
        <div class="item-price-display" id="bsQtyItemPrice">₱0.00</div>
        <div class="stock-info">Available: <span class="available" id="bsQtyStock">0</span></div>
        
        <div class="quantity-control">
            <button onclick="changeBSQuantity(-1)" id="bsQtyMinus">−</button>
            <span class="quantity-display" id="bsQtyDisplay">1</span>
            <button onclick="changeBSQuantity(1)" id="bsQtyPlus">+</button>
        </div>
        
        <div class="btn-group">
            <button class="btn-add" id="bsQtyAddBtn" onclick="confirmBSQuantity()">
                <i class="fas fa-cart-plus"></i> Add to Cart
            </button>
            <button class="btn-cancel-qty" onclick="closeBSQtyModal()">Cancel</button>
        </div>
    </div>
</div>

<script>
// ======================================================
// BEST SELLER QUANTITY MODAL
// ======================================================

let bsItemId = 0;
let bsItemName = '';
let bsItemPrice = 0;
let bsItemStock = 0;
let bsCurrentQty = 1;

function openBestSellerQty(itemId, itemName, itemPrice, itemStock) {
    if (itemStock <= 0) {
        alert('Sorry, ' + itemName + ' is out of stock!');
        return;
    }
    
    bsItemId = itemId;
    bsItemName = itemName;
    bsItemPrice = itemPrice;
    bsItemStock = itemStock;
    bsCurrentQty = 1;
    
    document.getElementById('bsQtyItemName').textContent = itemName;
    document.getElementById('bsQtyItemPrice').textContent = '₱' + parseFloat(itemPrice).toFixed(2);
    document.getElementById('bsQtyStock').textContent = itemStock;
    document.getElementById('bsQtyDisplay').textContent = '1';
    document.getElementById('bsQtyAddBtn').disabled = false;
    
    updateBSQuantityButtons();
    document.getElementById('bestSellerQtyModal').classList.add('show');
}

function closeBSQtyModal() {
    document.getElementById('bestSellerQtyModal').classList.remove('show');
}

function changeBSQuantity(change) {
    let newQty = bsCurrentQty + change;
    if (newQty < 1) newQty = 1;
    if (newQty > bsItemStock) newQty = bsItemStock;
    bsCurrentQty = newQty;
    document.getElementById('bsQtyDisplay').textContent = bsCurrentQty;
    updateBSQuantityButtons();
}

function updateBSQuantityButtons() {
    const minusBtn = document.getElementById('bsQtyMinus');
    const plusBtn = document.getElementById('bsQtyPlus');
    const addBtn = document.getElementById('bsQtyAddBtn');
    
    minusBtn.disabled = bsCurrentQty <= 1;
    plusBtn.disabled = bsCurrentQty >= bsItemStock;
    addBtn.disabled = bsCurrentQty < 1 || bsCurrentQty > bsItemStock;
}

function confirmBSQuantity() {
    if (bsCurrentQty < 1 || bsCurrentQty > bsItemStock) {
        alert('Invalid quantity!');
        return;
    }
    
    closeBSQtyModal();
    
    // Add to cart via fetch (no jQuery required)
    var params = new URLSearchParams({
        action: 'add_to_cart',
        item_id: bsItemId,
        name: bsItemName,
        price: bsItemPrice,
        stock: bsItemStock,
        quantity: bsCurrentQty
    });
    fetch('new_order.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString(),
        credentials: 'same-origin'
    })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.success) {
                alert('✅ Added ' + bsCurrentQty + 'x ' + bsItemName + ' to cart!');
            } else {
                alert('❌ ' + (data.error || 'Failed to add item'));
            }
        })
        .catch(function() {
            alert('❌ Error adding item to cart');
        });
}

// ======================================================
// RECEIPT FUNCTIONS
// ======================================================

document.addEventListener('click', function(e) {
    var viewBtn = e.target.closest('.view-receipt');
    if (viewBtn) {
        var orderId = viewBtn.getAttribute('data-order');
        window.open('receipt.php?order_id=' + orderId, '_blank', 'width=800,height=600');
        return;
    }
    var printBtn = e.target.closest('.print-receipt');
    if (printBtn) {
        var pOrderId = printBtn.getAttribute('data-order');
        if (!confirm('Print this receipt?')) return;
        var printWindow = window.open('receipt.php?order_id=' + pOrderId, '_blank', 'width=800,height=600');
        if (!printWindow) alert('Please allow popups to print the receipt.');
    }
});

// Close modal on outside click
document.getElementById('bestSellerQtyModal').addEventListener('click', function(e) {
    if (e.target === this) closeBSQtyModal();
});

// Close modal with ESC key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeBSQtyModal();
});

// ======================================================
// BEST SELLER QUICK-ADD GRID TABS (Today / Week / Month)
// ======================================================
function switchBestSellerGrid(tab) {
    document.querySelectorAll('.bs-tab[data-grid-tab]').forEach(function(b) { b.classList.remove('active'); });
    document.querySelector('.bs-tab[data-grid-tab="' + tab + '"]').classList.add('active');
    document.querySelectorAll('.bs-grid-panel').forEach(function(p) { p.style.display = 'none'; });
    document.getElementById('bsGridPanel-' + tab).style.display = '';
}

// ======================================================
// BEST SELLERS BAR CHART + SALES SUMMARY PIE CHART
// Both hand-drawn on <canvas> with no external library, so
// they keep working with no internet connection.
// ======================================================
function switchBSTab(tab) {
    document.querySelectorAll('.bs-tab[data-tab]').forEach(function(b) { b.classList.remove('active'); });
    document.querySelector('.bs-tab[data-tab="' + tab + '"]').classList.add('active');
    drawBestSellersBarChart(tab);
}

var bestSellersData = <?php echo json_encode([
    'today' => array_map(function($d) { return ['label' => $d['name'], 'qty' => (int)$d['total_quantity']]; }, $bestSellingToday),
    'week'  => array_map(function($d) { return ['label' => $d['name'], 'qty' => (int)$d['total_quantity']]; }, $bestSellingWeek),
    'month' => array_map(function($d) { return ['label' => $d['name'], 'qty' => (int)$d['total_quantity']]; }, $bestSellingMonth),
]); ?>;
var currentBSTab = 'today';

function drawBestSellersBarChart(tab) {
    currentBSTab = tab || currentBSTab;
    var canvas = document.getElementById('bestSellersBarChart');
    if (!canvas) return;
    var data = bestSellersData[currentBSTab] || [];

    var dpr = window.devicePixelRatio || 1;
    var cssWidth = canvas.parentElement.clientWidth;
    var cssHeight = 200;
    canvas.style.width = cssWidth + 'px';
    canvas.style.height = cssHeight + 'px';
    canvas.width = cssWidth * dpr;
    canvas.height = cssHeight * dpr;

    var ctx = canvas.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, cssWidth, cssHeight);

    if (data.length === 0) {
        ctx.fillStyle = '#888';
        ctx.font = '12px Poppins, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('No sales data yet', cssWidth / 2, cssHeight / 2);
        return;
    }

    var padding = { top: 10, right: 16, bottom: 34, left: 34 };
    var chartW = cssWidth - padding.left - padding.right;
    var chartH = cssHeight - padding.top - padding.bottom;
    var maxQty = Math.max.apply(null, data.map(function(d) { return d.qty; }).concat([1]));
    var niceMax = Math.ceil(maxQty * 1.15);

    ctx.strokeStyle = '#eee';
    ctx.fillStyle = '#888';
    ctx.font = '10px Poppins, sans-serif';
    ctx.textAlign = 'right';
    var steps = 4;
    for (var i = 0; i <= steps; i++) {
        var y = padding.top + chartH - (chartH * i / steps);
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(padding.left + chartW, y);
        ctx.stroke();
        ctx.fillText(Math.round(niceMax * i / steps), padding.left - 8, y + 3);
    }

    var barColors = ['#2c5f2d', '#3d8b40', '#f5a623', '#e67e22', '#e74c3c'];
    var slotWidth = chartW / data.length;
    var barWidth = Math.min(slotWidth * 0.55, 70);

    data.forEach(function(d, i) {
        var barHeight = niceMax > 0 ? (d.qty / niceMax) * chartH : 0;
        var x = padding.left + slotWidth * i + (slotWidth - barWidth) / 2;
        var y = padding.top + chartH - barHeight;

        ctx.fillStyle = barColors[i % barColors.length];
        ctx.fillRect(x, y, barWidth, barHeight);

        ctx.fillStyle = '#2d3436';
        ctx.font = '10px Poppins, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(d.qty, x + barWidth / 2, y - 4);

        var label = d.label.length > 10 ? d.label.substring(0, 9) + '…' : d.label;
        ctx.fillStyle = '#636e72';
        ctx.font = '9px Poppins, sans-serif';
        ctx.fillText(label, x + barWidth / 2, padding.top + chartH + 14);
    });
}

var salesSummaryData = <?php echo json_encode($salesSummary); ?>;
var currentSSTab = 'daily';

function switchSalesSummary(tab) {
    currentSSTab = tab;
    document.querySelectorAll('.bs-tab[data-ss-tab]').forEach(function(b) { b.classList.remove('active'); });
    document.querySelector('.bs-tab[data-ss-tab="' + tab + '"]').classList.add('active');

    var d = salesSummaryData[tab];
    document.getElementById('ssTotalSales').textContent = '\u20b1' + Number(d.total_sales).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    document.getElementById('ssTotalOrders').textContent = d.total_orders;
    document.getElementById('ssDineIn').textContent = '\u20b1' + Number(d.dine_in_sales).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    document.getElementById('ssTakeout').textContent = '\u20b1' + Number(d.takeout_sales).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});

    drawSalesSummaryPieChart();
}

function drawSalesSummaryPieChart() {
    var canvas = document.getElementById('salesSummaryPieChart');
    if (!canvas) return;
    var d = salesSummaryData[currentSSTab];
    var dineIn = Number(d.dine_in_sales) || 0;
    var takeout = Number(d.takeout_sales) || 0;
    var total = dineIn + takeout;

    var dpr = window.devicePixelRatio || 1;
    var size = 260;
    canvas.style.width = size + 'px';
    canvas.style.height = size + 'px';
    canvas.width = size * dpr;
    canvas.height = size * dpr;

    var ctx = canvas.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, size, size);

    var cx = size / 2, cy = size / 2 - 10, radius = 85;

    if (total <= 0) {
        ctx.fillStyle = '#eee';
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#888';
        ctx.font = '12px Poppins, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('No sales data yet', cx, cy);
        return;
    }

    var slices = [
        { label: 'Dine In', value: dineIn, color: '#2c5f2d' },
        { label: 'Take Out', value: takeout, color: '#f5a623' }
    ];

    var startAngle = -Math.PI / 2;
    slices.forEach(function(s) {
        var sliceAngle = (s.value / total) * Math.PI * 2;
        if (s.value <= 0) return;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, radius, startAngle, startAngle + sliceAngle);
        ctx.closePath();
        ctx.fillStyle = s.color;
        ctx.fill();

        var midAngle = startAngle + sliceAngle / 2;
        var pct = Math.round((s.value / total) * 100);
        if (pct > 0) {
            var lx = cx + Math.cos(midAngle) * (radius * 0.65);
            var ly = cy + Math.sin(midAngle) * (radius * 0.65);
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 12px Poppins, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(pct + '%', lx, ly);
        }
        startAngle += sliceAngle;
    });

    ctx.textAlign = 'left';
    ctx.font = '11px Poppins, sans-serif';
    slices.forEach(function(s, i) {
        var ly = cy + radius + 26 + i * 18;
        ctx.fillStyle = s.color;
        ctx.fillRect(cx - 70, ly - 9, 10, 10);
        ctx.fillStyle = '#2d3436';
        ctx.fillText(s.label, cx - 55, ly);
    });
}

window.addEventListener('resize', function() { drawBestSellersBarChart(); drawSalesSummaryPieChart(); });
document.addEventListener('DOMContentLoaded', function() { drawBestSellersBarChart('today'); switchSalesSummary('daily'); });

</script>

<?php include '../../includes/footer.php'; ?>