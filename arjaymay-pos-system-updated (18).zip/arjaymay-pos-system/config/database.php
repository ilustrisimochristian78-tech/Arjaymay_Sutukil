<?php
// ======================================================
// CONFIGURATION FILE - ENHANCED
// ======================================================

// Database Configuration
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_NAME')) define('DB_NAME', 'arjaymay_pos');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');

// Application Configuration
if (!defined('SITE_NAME')) define('SITE_NAME', 'Arjaymay Sutukil POS');
if (!defined('SITE_URL')) define('SITE_URL', 'http://localhost/arjaymay-pos-system/');
if (!defined('TIMEZONE')) define('TIMEZONE', 'Asia/Manila');
if (!defined('TAKEOUT_FEE')) define('TAKEOUT_FEE', 0.00); // Takeout fee removed per owner request
if (!defined('TAX_RATE')) define('TAX_RATE', 0.00);

// Session Configuration
ini_set('session.gc_maxlifetime', 3600);
ini_set('session.cookie_lifetime', 3600);
session_start();

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set(TIMEZONE);

// ======================================================
// DATABASE CONNECTION
// ======================================================
function getDBConnection(): PDO {
    static $migrated = false;
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
        if (!$migrated) {
            $migrated = true;
            runSchemaMigrations($pdo);
        }
        return $pdo;
    } catch (PDOException $e) {
        die("Database Connection Failed: " . $e->getMessage());
    }
}

// ======================================================
// AUTO SCHEMA MIGRATIONS
// Keeps older/existing databases in sync with columns the
// app expects, without needing to manually visit a one-off
// migration script. Safe to run on every request: each
// check is skipped if the column already exists.
// ======================================================
function columnEnumHasValue(PDO $pdo, string $table, string $column, string $value): bool {
    $stmt = $pdo->prepare("
        SELECT COLUMN_TYPE FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
    ");
    $stmt->execute([$table, $column]);
    $columnType = $stmt->fetchColumn();
    if ($columnType === false) return true; // column doesn't exist - nothing to modify, treat as "already fine"
    return strpos($columnType, "'" . $value . "'") !== false;
}

function columnExists(PDO $pdo, string $table, string $column): bool {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
    ");
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}

function runSchemaMigrations(PDO $pdo): void {
    try {
        // --- settings table may not exist at all on a brand new install ---
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS settings (
                id INT PRIMARY KEY,
                site_name VARCHAR(150) DEFAULT 'Arjaymay Sutukil',
                site_logo VARCHAR(255) DEFAULT '',
                site_favicon VARCHAR(255) DEFAULT '',
                background_image VARCHAR(255) DEFAULT ''
            )
        ");

        // --- orders: Senior/PWD discount tracking ---
        if (!columnExists($pdo, 'orders', 'discount_type')) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN discount_type ENUM('none','senior','pwd') DEFAULT 'none' AFTER discount");
        }
        if (!columnExists($pdo, 'orders', 'discount_id_number')) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN discount_id_number VARCHAR(50) DEFAULT NULL AFTER discount_type");
        }
        if (!columnExists($pdo, 'orders', 'discount_id_image')) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN discount_id_image VARCHAR(255) DEFAULT NULL AFTER discount_id_number");
        }

        // --- orders/payments: make sure gcash is an allowed payment method ---
        // IMPORTANT: only run this ALTER when actually needed. Running an
        // unconditional ALTER TABLE on every request takes a metadata lock
        // that queues behind any open transaction on that table (e.g. an
        // in-progress order/payment), which is what made GCash checkout
        // appear to hang forever. Once 'gcash' is present, this is skipped.
        if (!columnEnumHasValue($pdo, 'orders', 'payment_method', 'gcash')) {
            $pdo->exec("ALTER TABLE orders MODIFY COLUMN payment_method ENUM('cash','card','gcash') DEFAULT 'cash'");
        }
        if (!columnEnumHasValue($pdo, 'payments', 'payment_method', 'gcash')) {
            $pdo->exec("ALTER TABLE payments MODIFY COLUMN payment_method ENUM('cash','card','gcash') NOT NULL");
        }

        // --- settings: GCash QR code / number / account name ---
        if (!columnExists($pdo, 'settings', 'gcash_qr_image')) {
            $pdo->exec("ALTER TABLE settings ADD COLUMN gcash_qr_image VARCHAR(255) DEFAULT ''");
            // Seed the QR image bundled with this build, if present, so GCash
            // works immediately without an extra upload step.
            $seedFile = __DIR__ . '/../assets/images/payment/gcash_qr.jpg';
            if (file_exists($seedFile)) {
                $pdo->exec("UPDATE settings SET gcash_qr_image = 'gcash_qr.jpg' WHERE id = 1 AND (gcash_qr_image IS NULL OR gcash_qr_image = '')");
            }
        }
        if (!columnExists($pdo, 'settings', 'gcash_number')) {
            $pdo->exec("ALTER TABLE settings ADD COLUMN gcash_number VARCHAR(50) DEFAULT ''");
        }
        if (!columnExists($pdo, 'settings', 'gcash_name')) {
            $pdo->exec("ALTER TABLE settings ADD COLUMN gcash_name VARCHAR(100) DEFAULT ''");
        }

        // --- settings: configurable Senior Citizen / PWD discount rates ---
        if (!columnExists($pdo, 'settings', 'senior_discount_rate')) {
            $pdo->exec("ALTER TABLE settings ADD COLUMN senior_discount_rate DECIMAL(5,2) DEFAULT 20.00");
        }
        if (!columnExists($pdo, 'settings', 'pwd_discount_rate')) {
            $pdo->exec("ALTER TABLE settings ADD COLUMN pwd_discount_rate DECIMAL(5,2) DEFAULT 20.00");
        }
    } catch (PDOException $e) {
        // Never let a migration hiccup break the whole app - log and continue.
        error_log('Schema migration warning: ' . $e->getMessage());
    }
}

// ======================================================
// SESSION HELPER FUNCTIONS
// ======================================================
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

function isAdmin(): bool {
    return isLoggedIn() && $_SESSION['role'] === 'admin';
}

function isCashier(): bool {
    return isLoggedIn() && $_SESSION['role'] === 'cashier';
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . SITE_URL . 'modules/auth/login.php');
        exit;
    }
}

function requireAdmin(): void {
    requireLogin();
    if (!isAdmin()) {
        header('Location: ' . SITE_URL . 'index.php');
        exit;
    }
}

function requireCashier(): void {
    requireLogin();
    if (!isCashier()) {
        header('Location: ' . SITE_URL . 'index.php');
        exit;
    }
}

// ======================================================
// HELPER FUNCTIONS
// ======================================================
function sanitize(string $input): string {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function formatCurrency(float $amount): string {
    return '₱' . number_format($amount, 2);
}

function generateOrderNumber(): string {
    return 'ORD-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

function getCurrentDateTime(): string {
    return date('Y-m-d H:i:s');
}

function getCurrentDate(): string {
    return date('Y-m-d');
}

function getCurrentTime(): string {
    return date('H:i:s');
}

function generateToken(): string {
    return bin2hex(random_bytes(32));
}

function isValidEmail(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// ======================================================
// SITE SETTINGS FUNCTIONS - LOGO & BRANDING
// ======================================================

function getSiteSettings(): array {
    $pdo = getDBConnection();
    $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
    $settings = $stmt->fetch();
    
    if (!$settings) {
        // Create default settings if not exists
        $stmt = $pdo->prepare("INSERT INTO settings (id, site_name, site_logo, site_favicon, background_image) VALUES (1, 'Arjaymay Sutukil', '', '', '')");
        $stmt->execute();
        return [
            'site_name' => 'Arjaymay Sutukil',
            'site_logo' => '',
            'site_favicon' => '',
            'background_image' => ''
        ];
    }
    
    return $settings;
}

function getSiteLogo(): string {
    $settings = getSiteSettings();
    if (!empty($settings['site_logo']) && file_exists(__DIR__ . '/../assets/images/logo/' . $settings['site_logo'])) {
        return SITE_URL . 'assets/images/logo/' . $settings['site_logo'];
    }
    return '';
}

function getSiteFavicon(): string {
    $settings = getSiteSettings();
    if (!empty($settings['site_favicon']) && file_exists(__DIR__ . '/../assets/images/logo/' . $settings['site_favicon'])) {
        return SITE_URL . 'assets/images/logo/' . $settings['site_favicon'];
    }
    return '';
}

function getBackgroundImage(): string {
    $settings = getSiteSettings();
    if (!empty($settings['background_image']) && file_exists(__DIR__ . '/../assets/images/background/' . $settings['background_image'])) {
        return SITE_URL . 'assets/images/background/' . $settings['background_image'];
    }
    return '';
}

// ======================================================
// MENU FUNCTIONS
// ======================================================
function getAllCategories(): array {
    $pdo = getDBConnection();
    $stmt = $pdo->query("SELECT * FROM categories WHERE status = 'active' ORDER BY sort_order, name");
    return $stmt->fetchAll();
}

function getMenuItemsByCategory(int $categoryId): array {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT * FROM menu_items 
        WHERE category_id = ? AND status != 'out_of_stock'
        ORDER BY name
    ");
    $stmt->execute([$categoryId]);
    return $stmt->fetchAll();
}

function getMenuItemById(int $id): ?array {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM menu_items WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function updateStock(int $itemId, int $quantity): bool {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        UPDATE menu_items 
        SET stock = stock - ?, 
            status = CASE 
                WHEN stock - ? <= 0 THEN 'out_of_stock'
                WHEN stock - ? <= 10 THEN 'low_stock'
                ELSE 'available'
            END
        WHERE id = ?
    ");
    return $stmt->execute([$quantity, $quantity, $quantity, $itemId]);
}

// ======================================================
// USER FUNCTIONS
// ======================================================
function createUser(array $data): array {
    $pdo = getDBConnection();
    
    try {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$data['username']]);
        if ($stmt->fetch()) {
            return ['success' => false, 'error' => 'Username already exists'];
        }
        
        if (!empty($data['email'])) {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$data['email']]);
            if ($stmt->fetch()) {
                return ['success' => false, 'error' => 'Email already exists'];
            }
        }
        
        $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("
            INSERT INTO users (username, password, full_name, email, phone, role, is_first_login)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $data['username'],
            $hashedPassword,
            $data['full_name'],
            $data['email'] ?? null,
            $data['phone'] ?? null,
            $data['role'] ?? 'cashier',
            $data['role'] === 'admin' ? false : true
        ]);
        
        $userId = $pdo->lastInsertId();
        
        return ['success' => true, 'user_id' => $userId];
        
    } catch (PDOException $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

function getUserByUsername(string $username): ?array {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND status = 'active'");
    $stmt->execute([$username]);
    return $stmt->fetch();
}

function updateUserPassword(int $userId, string $newPassword): bool {
    $pdo = getDBConnection();
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password = ?, is_first_login = FALSE WHERE id = ?");
    return $stmt->execute([$hashedPassword, $userId]);
}

// ======================================================
// ORDER FUNCTIONS
// ======================================================
function createOrder(array $data): array {
    $pdo = getDBConnection();
    
    $pdo->beginTransaction();
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO orders (
                order_number, cashier_id, order_type, table_number, 
                customer_name, subtotal, tax, takeout_fee, discount, 
                total, payment_method, payment_amount, change_amount, status
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed'
            )
        ");
        
        $stmt->execute([
            $data['order_number'],
            $data['cashier_id'],
            $data['order_type'],
            $data['table_number'] ?? null,
            $data['customer_name'] ?? null,
            $data['subtotal'],
            $data['tax'] ?? 0,
            $data['takeout_fee'] ?? 0,
            $data['discount'] ?? 0,
            $data['total'],
            $data['payment_method'],
            $data['payment_amount'],
            $data['change_amount']
        ]);
        
        $orderId = (int)$pdo->lastInsertId();
        
        foreach ($data['items'] as $item) {
            $stmt = $pdo->prepare("
                INSERT INTO order_items (order_id, menu_item_id, quantity, price, subtotal)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $orderId,
                $item['menu_item_id'],
                $item['quantity'],
                $item['price'],
                $item['subtotal']
            ]);
            
            updateStock((int)$item['menu_item_id'], (int)$item['quantity']);
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO payments (order_id, amount, payment_method)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$orderId, $data['payment_amount'], $data['payment_method']]);
        
        $stmt = $pdo->prepare("
            INSERT INTO activity_logs (user_id, action, details)
            VALUES (?, 'order_completed', ?)
        ");
        $stmt->execute([
            $data['cashier_id'],
            "Order #{$data['order_number']} - Total: " . formatCurrency((float)$data['total'])
        ]);
        
        $pdo->commit();
        return ['success' => true, 'order_id' => $orderId, 'order_number' => $data['order_number']];
        
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

function getOrdersByDate(string $date): array {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT o.*, u.full_name as cashier_name
        FROM orders o
        LEFT JOIN users u ON o.cashier_id = u.id
        WHERE DATE(o.created_at) = ?
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$date]);
    return $stmt->fetchAll();
}

function getOrderDetails(int $orderId): ?array {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT o.*, u.full_name as cashier_name
        FROM orders o
        LEFT JOIN users u ON o.cashier_id = u.id
        WHERE o.id = ?
    ");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch();
    
    if ($order) {
        $stmt = $pdo->prepare("
            SELECT oi.*, m.name as item_name
            FROM order_items oi
            JOIN menu_items m ON oi.menu_item_id = m.id
            WHERE oi.order_id = ?
        ");
        $stmt->execute([$orderId]);
        $order['items'] = $stmt->fetchAll();
    }
    
    return $order;
}

function getDashboardStats(): array {
    $pdo = getDBConnection();
    
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_orders,
            COALESCE(SUM(total), 0) as total_sales
        FROM orders 
        WHERE DATE(created_at) = CURDATE() AND status = 'completed'
    ");
    $stmt->execute();
    $today = $stmt->fetch();
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM menu_items WHERE status != 'out_of_stock'");
    $menuCount = $stmt->fetch();
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM menu_items WHERE status = 'out_of_stock'");
    $outOfStock = $stmt->fetch();
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM menu_items WHERE status = 'low_stock'");
    $lowStock = $stmt->fetch();
    
    $stmt = $pdo->prepare("
        SELECT 
            m.id,
            m.name,
            SUM(oi.quantity) as total_quantity
        FROM order_items oi
        JOIN menu_items m ON oi.menu_item_id = m.id
        JOIN orders o ON oi.order_id = o.id
        WHERE DATE(o.created_at) = CURDATE() AND o.status = 'completed'
        GROUP BY m.id, m.name
        ORDER BY total_quantity DESC
        LIMIT 5
    ");
    $stmt->execute();
    $bestSelling = $stmt->fetchAll();
    
    return [
        'today_orders' => (int)($today['total_orders'] ?? 0),
        'today_sales' => (float)($today['total_sales'] ?? 0),
        'total_menu_items' => (int)($menuCount['total'] ?? 0),
        'out_of_stock' => (int)($outOfStock['total'] ?? 0),
        'low_stock' => (int)($lowStock['total'] ?? 0),
        'best_selling' => $bestSelling
    ];
}

function getDailySalesReport(string $date): array {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_orders,
            COALESCE(SUM(total), 0) as total_sales,
            COALESCE(SUM(CASE WHEN order_type = 'dine_in' THEN total ELSE 0 END), 0) as dine_in_sales,
            COALESCE(SUM(CASE WHEN order_type = 'take_out' THEN total ELSE 0 END), 0) as takeout_sales,
            COUNT(CASE WHEN order_type = 'dine_in' THEN 1 END) as dine_in_orders,
            COUNT(CASE WHEN order_type = 'take_out' THEN 1 END) as takeout_orders
        FROM orders
        WHERE DATE(created_at) = ? AND status = 'completed'
    ");
    $stmt->execute([$date]);
    $result = $stmt->fetch();
    
    return [
        'total_orders' => (int)($result['total_orders'] ?? 0),
        'total_sales' => (float)($result['total_sales'] ?? 0),
        'dine_in_sales' => (float)($result['dine_in_sales'] ?? 0),
        'takeout_sales' => (float)($result['takeout_sales'] ?? 0),
        'dine_in_orders' => (int)($result['dine_in_orders'] ?? 0),
        'takeout_orders' => (int)($result['takeout_orders'] ?? 0)
    ];
}

// ======================================================
// RANGE SALES REPORT (used for weekly / monthly reports)
// $startDate and $endDate are inclusive, format 'Y-m-d'
// ======================================================
function getRangeSalesReport(string $startDate, string $endDate): array {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_orders,
            COALESCE(SUM(total), 0) as total_sales,
            COALESCE(SUM(CASE WHEN order_type = 'dine_in' THEN total ELSE 0 END), 0) as dine_in_sales,
            COALESCE(SUM(CASE WHEN order_type = 'take_out' THEN total ELSE 0 END), 0) as takeout_sales,
            COUNT(CASE WHEN order_type = 'dine_in' THEN 1 END) as dine_in_orders,
            COUNT(CASE WHEN order_type = 'take_out' THEN 1 END) as takeout_orders
        FROM orders
        WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed'
    ");
    $stmt->execute([$startDate, $endDate]);
    $result = $stmt->fetch();

    return [
        'total_orders' => (int)($result['total_orders'] ?? 0),
        'total_sales' => (float)($result['total_sales'] ?? 0),
        'dine_in_sales' => (float)($result['dine_in_sales'] ?? 0),
        'takeout_sales' => (float)($result['takeout_sales'] ?? 0),
        'dine_in_orders' => (int)($result['dine_in_orders'] ?? 0),
        'takeout_orders' => (int)($result['takeout_orders'] ?? 0)
    ];
}

// ======================================================
// DAILY SALES BREAKDOWN over a date range - used to draw
// the bar chart on the weekly/monthly reports and the
// line chart for best-seller trends.
// Returns every day in the range, including zero-sales days.
// ======================================================
function getDailyBreakdown(string $startDate, string $endDate): array {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT DATE(created_at) as day, COUNT(*) as orders, COALESCE(SUM(total), 0) as sales
        FROM orders
        WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed'
        GROUP BY DATE(created_at)
    ");
    $stmt->execute([$startDate, $endDate]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $byDay = [];
    foreach ($rows as $row) {
        $byDay[$row['day']] = ['orders' => (int)$row['orders'], 'sales' => (float)$row['sales']];
    }

    $breakdown = [];
    $cursor = new DateTime($startDate);
    $end = new DateTime($endDate);
    while ($cursor <= $end) {
        $key = $cursor->format('Y-m-d');
        $breakdown[] = [
            'date' => $key,
            'label' => $cursor->format('M j'),
            'orders' => $byDay[$key]['orders'] ?? 0,
            'sales' => $byDay[$key]['sales'] ?? 0,
        ];
        $cursor->modify('+1 day');
    }

    return $breakdown;
}

// ======================================================
// HOURLY BREAKDOWN for a single day (used by the "Today"
// view of the Sales Trend chart).
// ======================================================
function getHourlyBreakdown(string $date): array {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT HOUR(created_at) as hr, COUNT(*) as orders, COALESCE(SUM(total), 0) as sales
        FROM orders
        WHERE DATE(created_at) = ? AND status = 'completed'
        GROUP BY HOUR(created_at)
    ");
    $stmt->execute([$date]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $byHour = [];
    foreach ($rows as $row) {
        $byHour[(int)$row['hr']] = ['orders' => (int)$row['orders'], 'sales' => (float)$row['sales']];
    }

    $breakdown = [];
    for ($h = 0; $h < 24; $h++) {
        $label = date('g A', mktime($h, 0, 0));
        $breakdown[] = [
            'date' => $date . ' ' . sprintf('%02d:00', $h),
            'label' => $label,
            'orders' => $byHour[$h]['orders'] ?? 0,
            'sales' => $byHour[$h]['sales'] ?? 0,
        ];
    }

    return $breakdown;
}

// ======================================================
// BEST SELLING ITEMS over a date range
// ======================================================
function getBestSellingRange(string $startDate, string $endDate, int $limit = 10): array {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT m.id, m.name, c.name as category_name, SUM(oi.quantity) as total_quantity, SUM(oi.subtotal) as total_sales
        FROM order_items oi
        JOIN menu_items m ON oi.menu_item_id = m.id
        JOIN categories c ON m.category_id = c.id
        JOIN orders o ON oi.order_id = o.id
        WHERE DATE(o.created_at) BETWEEN ? AND ? AND o.status = 'completed'
        GROUP BY m.id, m.name, c.name
        ORDER BY total_quantity DESC
        LIMIT $limit
    ");
    $stmt->execute([$startDate, $endDate]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>