<?php
// ======================================================
// HEADER FILE - WITH PROFILE PICTURE & LOGO
// ======================================================

// Get site settings
$settings = getSiteSettings();
$siteLogo = getSiteLogo();
$siteName = $settings['site_name'] ?? 'Arjaymay Sutukil';
$favicon = getSiteFavicon();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $siteName; ?></title>
    <?php if ($favicon): ?>
    <link rel="icon" href="<?php echo $favicon; ?>">
    <?php endif; ?>
    
    <!-- Fonts & Icons -->
    <?php include __DIR__ . '/asset_links.php'; ?>
    
    <!-- No jQuery, no CDN scripts of any kind. Every interactive
         feature in this system (sidebar, notifications, receipts,
         charts) is plain JavaScript, so nothing here ever depends
         on an internet connection to work. -->
    <script>var SITE_URL = <?php echo json_encode(SITE_URL); ?>;</script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
    
    <style>
    .nav-brand img {
        height: 35px;
        object-fit: contain;
    }
    .nav-profile-pic {
        width: 35px;
        height: 35px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid rgba(255,255,255,0.3);
        background: #f0f2f5;
    }
    .nav-profile-pic-placeholder {
        width: 35px;
        height: 35px;
        border-radius: 50%;
        background: #3d8b40;
        color: #fff;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 0.9rem;
        border: 2px solid rgba(255,255,255,0.3);
    }
    .user-info {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .user-info .user-details {
        display: flex;
        flex-direction: column;
        line-height: 1.2;
    }
    .user-info .user-details .name {
        font-weight: 500;
        font-size: 0.9rem;
    }
    .user-info .user-details .role {
        font-size: 0.65rem;
        opacity: 0.8;
    }
    .nav-profile-link {
        color: white;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border-radius: 8px;
        transition: background 0.3s;
    }
    .nav-profile-link:hover {
        background: rgba(255,255,255,0.15);
    }
    .nav-profile-link-wrap {
        text-decoration: none;
        color: inherit;
        padding: 4px 10px;
        border-radius: 8px;
        transition: background 0.3s;
        cursor: pointer;
    }
    .nav-profile-link-wrap:hover {
        background: rgba(255,255,255,0.15);
    }
    .nav-logout-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 36px;
        height: 36px;
        border-radius: 50%;
        color: #fff;
        background: rgba(255,255,255,0.12);
        text-decoration: none;
        font-size: 0.95rem;
        transition: background 0.3s;
        margin-left: 4px;
    }
    .nav-logout-btn:hover {
        background: #e74c3c;
    }
    </style>
</head>
<body>
    <?php if (isLoggedIn()): ?>
    <?php $currentPage = basename($_SERVER['PHP_SELF']); ?>

    <!-- Sidebar toggle (mobile) -->
    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Menu">
        <i class="fas fa-bars"></i>
    </button>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar Navigation -->
    <aside class="app-sidebar" id="appSidebar">
        <div class="sidebar-brand">
            <?php if ($siteLogo): ?>
                <img src="<?php echo $siteLogo; ?>" alt="<?php echo $siteName; ?>">
            <?php else: ?>
                <i class="fas fa-utensils"></i>
            <?php endif; ?>
            <span><?php echo $siteName; ?></span>
        </div>

        <nav class="sidebar-nav">
            <?php if (isAdmin()): ?>
                <a href="<?php echo SITE_URL; ?>modules/admin/dashboard.php" class="sidebar-link <?php echo $currentPage == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/admin/sales_report.php" class="sidebar-link <?php echo $currentPage == 'sales_report.php' ? 'active' : ''; ?>">
                    <i class="fas fa-chart-bar"></i> <span>Sales Reports</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/admin/menu_management.php" class="sidebar-link <?php echo $currentPage == 'menu_management.php' ? 'active' : ''; ?>">
                    <i class="fas fa-utensils"></i> <span>Menu</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/admin/category_management.php" class="sidebar-link <?php echo $currentPage == 'category_management.php' ? 'active' : ''; ?>">
                    <i class="fas fa-tags"></i> <span>Categories</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/admin/view_stocks.php" class="sidebar-link <?php echo $currentPage == 'view_stocks.php' ? 'active' : ''; ?>">
                    <i class="fas fa-warehouse"></i> <span>Stocks</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/admin/transaction_history.php" class="sidebar-link <?php echo $currentPage == 'transaction_history.php' ? 'active' : ''; ?>">
                    <i class="fas fa-history"></i> <span>Transactions</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/admin/discounts.php" class="sidebar-link <?php echo $currentPage == 'discounts.php' ? 'active' : ''; ?>">
                    <i class="fas fa-id-card"></i> <span>Senior/PWD Discounts</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/admin/cashier_management.php" class="sidebar-link <?php echo $currentPage == 'cashier_management.php' ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i> <span>Cashiers</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/admin/admin_management.php" class="sidebar-link <?php echo $currentPage == 'admin_management.php' ? 'active' : ''; ?>">
                    <i class="fas fa-user-shield"></i> <span>Admins</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/admin/backup_restore.php" class="sidebar-link <?php echo $currentPage == 'backup_restore.php' ? 'active' : ''; ?>">
                    <i class="fas fa-database"></i> <span>Backup</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/admin/settings.php" class="sidebar-link <?php echo $currentPage == 'settings.php' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i> <span>Settings</span>
                </a>
            <?php endif; ?>
            <?php if (isCashier()): ?>
                <a href="<?php echo SITE_URL; ?>modules/cashier/dashboard.php" class="sidebar-link <?php echo $currentPage == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/cashier/new_order.php?type=dine_in" class="sidebar-link <?php echo $currentPage == 'new_order.php' ? 'active' : ''; ?>">
                    <i class="fas fa-cash-register"></i> <span>POS</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/cashier/kitchen_display.php" class="sidebar-link <?php echo $currentPage == 'kitchen_display.php' ? 'active' : ''; ?>">
                    <i class="fas fa-kitchen-set"></i> <span>Kitchen Display</span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/cashier/search_transaction.php" class="sidebar-link <?php echo $currentPage == 'search_transaction.php' ? 'active' : ''; ?>">
                    <i class="fas fa-search"></i> <span>Search</span>
                </a>
            <?php endif; ?>
        </nav>
    </aside>

    <!-- Top Bar -->
    <nav class="top-nav">
        <div class="nav-container">
            <div class="nav-center">
                <span class="nav-date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('F d, Y'); ?>
                </span>
                <span class="nav-time">
                    <i class="far fa-clock"></i>
                    <?php echo date('h:i A'); ?>
                </span>
            </div>
            
            <div class="nav-right">
                <?php if (isAdmin()): ?>
                <div class="notif-bell-wrap">
                    <button class="notif-bell" id="notifBell" aria-label="Notifications">
                        <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                        <span class="notif-badge" id="notifBadge" style="display:none;">0</span>
                    </button>
                    <div class="notif-dropdown" id="notifDropdown">
                        <div class="notif-dropdown-header">Notifications</div>
                        <div class="notif-dropdown-body" id="notifDropdownBody">
                            <div class="notif-empty">Loading...</div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <a href="<?php echo SITE_URL; ?>modules/profile/profile.php" class="user-info nav-profile-link-wrap" title="View profile">
                    <?php
                    $profilePic = '';
                    $fullName = $_SESSION['full_name'] ?? 'User';
                    if (isset($_SESSION['user_id'])) {
                        try {
                            $pdo = getDBConnection();
                            $stmt = $pdo->prepare("SELECT profile_picture FROM users WHERE id = ?");
                            $stmt->execute([$_SESSION['user_id']]);
                            $userData = $stmt->fetch();
                            if ($userData && !empty($userData['profile_picture'])) {
                                $profilePic = $userData['profile_picture'];
                            }
                        } catch (Exception $e) {
                            // Silent fail
                        }
                    }
                    ?>
                    <?php if (!empty($profilePic) && file_exists(__DIR__ . '/../assets/uploads/profiles/' . $profilePic)): ?>
                        <img src="<?php echo SITE_URL; ?>assets/uploads/profiles/<?php echo $profilePic; ?>" 
                             alt="Profile" 
                             class="nav-profile-pic">
                    <?php else: ?>
                        <span class="nav-profile-pic-placeholder">
                            <?php echo strtoupper(substr($fullName, 0, 1)); ?>
                        </span>
                    <?php endif; ?>
                    <span class="user-details">
                        <span class="name"><?php echo sanitize($fullName); ?></span>
                        <span class="role"><?php echo ucfirst($_SESSION['role'] ?? ''); ?></span>
                    </span>
                </a>
                <a href="<?php echo SITE_URL; ?>modules/auth/logout.php" class="nav-logout-btn" title="Logout" onclick="event.preventDefault(); openLogoutConfirm(this.href);">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>
    </nav>

    <!-- Custom Logout Confirmation Modal -->
    <div class="logout-confirm-overlay" id="logoutConfirmOverlay">
        <div class="logout-confirm-box">
            <div class="logout-confirm-icon">
                <i class="fas fa-sign-out-alt"></i>
            </div>
            <h3>Log out?</h3>
            <p>Are you sure you want to log out of your account?</p>
            <div class="logout-confirm-actions">
                <button type="button" class="logout-confirm-cancel" onclick="closeLogoutConfirm()">Cancel</button>
                <button type="button" class="logout-confirm-ok" id="logoutConfirmOkBtn">Yes, Log Out</button>
            </div>
        </div>
    </div>

    <style>
    .logout-confirm-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(20, 30, 25, 0.55);
        backdrop-filter: blur(2px);
        z-index: 5000;
        align-items: center;
        justify-content: center;
    }
    .logout-confirm-overlay.show {
        display: flex;
    }
    .logout-confirm-box {
        background: #fff;
        border-radius: 18px;
        padding: 32px 30px 26px;
        width: 90%;
        max-width: 340px;
        text-align: center;
        box-shadow: 0 20px 50px rgba(0,0,0,0.3);
        animation: logoutPopIn 0.25s ease;
    }
    @keyframes logoutPopIn {
        0% { transform: scale(0.85); opacity: 0; }
        100% { transform: scale(1); opacity: 1; }
    }
    .logout-confirm-icon {
        width: 66px;
        height: 66px;
        margin: 0 auto 16px;
        border-radius: 50%;
        background: #fdecea;
        color: #e74c3c;
        font-size: 1.6rem;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .logout-confirm-box h3 {
        margin: 0 0 8px;
        font-size: 1.2rem;
        color: var(--text-dark, #2d3436);
    }
    .logout-confirm-box p {
        margin: 0 0 22px;
        font-size: 0.88rem;
        color: #777;
    }
    .logout-confirm-actions {
        display: flex;
        gap: 10px;
    }
    .logout-confirm-actions button {
        flex: 1;
        padding: 11px 0;
        border-radius: 10px;
        border: none;
        font-size: 0.88rem;
        font-weight: 600;
        cursor: pointer;
        transition: transform 0.15s, background 0.2s;
    }
    .logout-confirm-cancel {
        background: #f1f2f6;
        color: #444;
    }
    .logout-confirm-cancel:hover {
        background: #e4e6ea;
    }
    .logout-confirm-ok {
        background: #e74c3c;
        color: #fff;
    }
    .logout-confirm-ok:hover {
        background: #c0392b;
        transform: translateY(-1px);
    }
    </style>

    <script>
    function openLogoutConfirm(logoutUrl) {
        var overlay = document.getElementById('logoutConfirmOverlay');
        document.getElementById('logoutConfirmOkBtn').onclick = function() {
            window.location.href = logoutUrl;
        };
        overlay.classList.add('show');
    }
    function closeLogoutConfirm() {
        document.getElementById('logoutConfirmOverlay').classList.remove('show');
    }
    document.addEventListener('DOMContentLoaded', function() {
        var overlay = document.getElementById('logoutConfirmOverlay');
        if (overlay) {
            overlay.addEventListener('click', function(e) {
                if (e.target === this) closeLogoutConfirm();
            });
        }
    });
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeLogoutConfirm();
    });
    </script>
    <?php endif; ?>
    
    <main class="main-content">