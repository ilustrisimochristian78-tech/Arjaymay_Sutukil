<?php
// ======================================================
// GET RECEIPT DATA (API)
// ======================================================
require_once '../../config/database.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

$orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if ($orderId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid order ID']);
    exit;
}

$order = getOrderDetails($orderId);

if (!$order) {
    echo json_encode(['success' => false, 'error' => 'Order not found']);
    exit;
}

$receiptData = [
    'success' => true,
    'order_number' => $order['order_number'],
    'cashier_name' => $order['cashier_name'],
    'date' => date('m/d/Y', strtotime($order['created_at'])),
    'time' => date('h:i A', strtotime($order['created_at'])),
    'order_type' => $order['order_type'],
    'subtotal' => $order['subtotal'],
    'takeout_fee' => $order['takeout_fee'],
    'total' => $order['total'],
    'payment_amount' => $order['payment_amount'],
    'change_amount' => $order['change_amount'],
    'items' => []
];

foreach ($order['items'] as $item) {
    $receiptData['items'][] = [
        'name' => $item['item_name'],
        'quantity' => $item['quantity'],
        'price' => $item['price'],
        'subtotal' => $item['subtotal']
    ];
}

echo json_encode($receiptData);
?>