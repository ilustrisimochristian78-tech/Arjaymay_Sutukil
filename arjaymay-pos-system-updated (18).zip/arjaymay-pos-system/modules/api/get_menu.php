<?php
require_once '../../config/database.php';

header('Content-Type: application/json');

$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : 0;

$pdo = getDBConnection();

try {
    if ($category_id > 0) {
        $stmt = $pdo->prepare("SELECT id, name, price, stock FROM menu_items WHERE category_id = ? AND status != 'out_of_stock' ORDER BY name");
        $stmt->execute([$category_id]);
    } else {
        $stmt = $pdo->query("SELECT id, name, price, stock FROM menu_items WHERE status != 'out_of_stock' ORDER BY name");
    }
    $items = $stmt->fetchAll();
    echo json_encode(['success' => true, 'items' => $items]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>