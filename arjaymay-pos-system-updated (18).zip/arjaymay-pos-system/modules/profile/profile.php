<?php
// ======================================================
// PROFILE PAGE - Upload Profile Picture (FIXED)
// ======================================================
require_once '../../config/database.php';
requireLogin();

$pdo = getDBConnection();
$error = '';
$success = '';

// Get user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: ../auth/logout.php');
    exit;
}

// Handle profile picture upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_profile') {
        $full_name = sanitize($_POST['full_name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        
        if (empty($full_name)) {
            $error = 'Full name is required.';
        } elseif (!empty($email) && strpos($email, '@') === false) {
            $error = 'Email must contain the @ symbol.';
        } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            try {
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?");
                $stmt->execute([$full_name, $email, $phone, $_SESSION['user_id']]);
                $_SESSION['full_name'] = $full_name;
                $success = 'Profile updated successfully!';
                
                // Refresh user data
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $user = $stmt->fetch();
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
    
    if ($_POST['action'] === 'upload_picture') {
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['profile_picture'];
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $maxSize = 2 * 1024 * 1024; // 2MB
            
            // Validate file type - FIXED: Use getimagesize or mime_content_type instead of finfo
            $mimeType = mime_content_type($file['tmp_name']);
            
            if (!in_array($mimeType, $allowedTypes)) {
                $error = 'Only JPG, PNG, GIF, and WEBP images are allowed.';
            } elseif ($file['size'] > $maxSize) {
                $error = 'Image size must be less than 2MB.';
            } else {
                // Create upload directory
                $uploadDir = '../../assets/uploads/profiles/';
                if (!file_exists($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                // Generate unique filename
                $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                $filename = 'user_' . $_SESSION['user_id'] . '_' . time() . '.' . $extension;
                $filepath = $uploadDir . $filename;
                
                // Delete old profile picture if exists
                if (!empty($user['profile_picture'])) {
                    $oldFile = $uploadDir . $user['profile_picture'];
                    if (file_exists($oldFile)) {
                        unlink($oldFile);
                    }
                }
                
                // Upload new file
                if (move_uploaded_file($file['tmp_name'], $filepath)) {
                    // Update database
                    $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
                    $stmt->execute([$filename, $_SESSION['user_id']]);
                    $success = 'Profile picture uploaded successfully!';
                    
                    // Refresh user data
                    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                    $stmt->execute([$_SESSION['user_id']]);
                    $user = $stmt->fetch();
                } else {
                    $error = 'Failed to upload image. Please try again.';
                }
            }
        } else {
            $error = 'Please select an image to upload.';
        }
    }
    
    if ($_POST['action'] === 'remove_picture') {
        if (!empty($user['profile_picture'])) {
            $uploadDir = '../../assets/uploads/profiles/';
            $oldFile = $uploadDir . $user['profile_picture'];
            if (file_exists($oldFile)) {
                unlink($oldFile);
            }
            $stmt = $pdo->prepare("UPDATE users SET profile_picture = NULL WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $success = 'Profile picture removed successfully!';
            
            // Refresh user data
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
        }
    }
}

$isAdmin = isAdmin();
$isCashier = isCashier();
$dashboardLink = $isAdmin ? '../admin/dashboard.php' : '../cashier/dashboard.php';

include '../../includes/header.php';
?>

<style>
.profile-container {
    max-width: 800px;
    margin: 0 auto;
}
.profile-card {
    background: #fff;
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    overflow: hidden;
    margin-bottom: 24px;
}
.profile-header {
    background: var(--primary);
    color: #fff;
    padding: 30px 30px 80px;
    text-align: center;
    position: relative;
}
.profile-header h2 {
    color: #fff;
    margin: 0;
}
.profile-header p {
    color: rgba(255,255,255,0.8);
    margin: 5px 0 0;
}
.profile-avatar-wrapper {
    position: relative;
    margin-top: -60px;
    text-align: center;
    z-index: 1;
}
.profile-avatar {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 4px solid #fff;
    background: #f0f2f5;
    object-fit: cover;
    display: inline-block;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}
.profile-avatar-placeholder {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 4px solid #fff;
    background: #2c5f2d;
    color: #fff;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    font-weight: 600;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}
.profile-avatar-upload {
    margin-top: 10px;
    text-align: center;
}
.profile-avatar-upload .btn-upload {
    background: var(--primary);
    color: #fff;
    padding: 8px 20px;
    border: none;
    border-radius: 20px;
    font-family: 'Poppins', sans-serif;
    font-size: 0.85rem;
    cursor: pointer;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}
.profile-avatar-upload .btn-upload:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
}
.profile-avatar-upload .btn-remove {
    background: #e74c3c;
    color: #fff;
    padding: 8px 20px;
    border: none;
    border-radius: 20px;
    font-family: 'Poppins', sans-serif;
    font-size: 0.85rem;
    cursor: pointer;
    transition: all 0.3s;
    margin-left: 8px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}
.profile-avatar-upload .btn-remove:hover {
    background: #c0392b;
    transform: translateY(-2px);
}
.profile-body {
    padding: 24px 30px 30px;
}
.profile-body .form-group {
    margin-bottom: 16px;
}
.profile-body .form-group label {
    display: block;
    font-weight: 500;
    font-size: 0.85rem;
    color: var(--text-dark);
    margin-bottom: 4px;
}
.profile-body .form-group input {
    width: 100%;
    padding: 10px 14px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-size: 0.95rem;
    transition: all 0.3s;
}
.profile-body .form-group input:focus {
    border-color: var(--primary);
    outline: none;
    box-shadow: 0 0 0 3px rgba(44,95,45,0.1);
}
.profile-body .form-group input:disabled {
    background: #f8f9fa;
    cursor: not-allowed;
}
.profile-body .btn-save {
    background: var(--primary);
    color: #fff;
    padding: 10px 30px;
    border: none;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}
.profile-body .btn-save:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
}
.role-badge {
    display: inline-block;
    padding: 4px 16px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
}
.role-badge.admin { background: #e74c3c; color: #fff; }
.role-badge.cashier { background: #2c5f2d; color: #fff; }
.upload-hidden {
    display: none;
}
.profile-info-row {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px solid #f0f0f0;
}
.profile-info-row .label {
    color: var(--text-light);
    font-size: 0.85rem;
}
.profile-info-row .value {
    font-weight: 500;
    font-size: 0.9rem;
}
.profile-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 16px;
}
.image-preview-container {
    position: relative;
    display: inline-block;
    cursor: pointer;
}
.image-preview-container .preview-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0,0,0,0.6);
    color: #fff;
    font-size: 0.7rem;
    padding: 4px;
    text-align: center;
    border-radius: 0 0 50% 50%;
    opacity: 0;
    transition: opacity 0.3s;
}
.image-preview-container:hover .preview-overlay {
    opacity: 1;
}
</style>

<div class="profile-container">
    <div class="page-header">
        <h2><i class="fas fa-user-circle"></i> My Profile</h2>
        <p>Manage your profile information and picture</p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
    <?php endif; ?>

    <div class="profile-card">
        <!-- Profile Header -->
        <div class="profile-header">
            <h2><?php echo sanitize($user['full_name']); ?></h2>
            <p>
                <span class="role-badge <?php echo $user['role']; ?>">
                    <?php echo ucfirst($user['role']); ?>
                </span>
            </p>
        </div>

        <!-- Profile Avatar -->
        <div class="profile-avatar-wrapper">
            <div class="image-preview-container">
                <?php 
                $profilePicPath = '../../assets/uploads/profiles/' . ($user['profile_picture'] ?? '');
                if (!empty($user['profile_picture']) && file_exists($profilePicPath)): 
                ?>
                    <img src="<?php echo SITE_URL; ?>assets/uploads/profiles/<?php echo $user['profile_picture']; ?>" 
                         alt="Profile Picture" 
                         class="profile-avatar" 
                         id="profileAvatar">
                    <div class="preview-overlay">Click to change</div>
                <?php else: ?>
                    <div class="profile-avatar-placeholder" id="profileAvatarPlaceholder">
                        <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Upload Form -->
        <div class="profile-avatar-upload">
            <form method="POST" action="" enctype="multipart/form-data" id="uploadForm" style="display: inline;">
                <input type="hidden" name="action" value="upload_picture">
                <input type="file" name="profile_picture" id="profilePictureInput" class="upload-hidden" accept="image/*">
                <button type="button" class="btn-upload" onclick="document.getElementById('profilePictureInput').click()">
                    <i class="fas fa-camera"></i> Upload Photo
                </button>
            </form>
            <?php if (!empty($user['profile_picture'])): ?>
            <form method="POST" action="" style="display: inline;" onsubmit="return confirm('Remove your profile picture?')">
                <input type="hidden" name="action" value="remove_picture">
                <button type="submit" class="btn-remove">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </form>
            <?php endif; ?>
            <div style="font-size: 0.7rem; color: var(--text-light); margin-top: 8px;">
                <i class="fas fa-info-circle"></i> Max size: 2MB. Allowed: JPG, PNG, GIF, WEBP
            </div>
        </div>

        <!-- Profile Body -->
        <div class="profile-body">
            <form method="POST" action="">
                <input type="hidden" name="action" value="update_profile">
                
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" value="<?php echo sanitize($user['username']); ?>" disabled>
                    <small style="color: var(--text-light);">Username cannot be changed</small>
                </div>
                
                <div class="form-group">
                    <label>Full Name <span style="color: #e74c3c;">*</span></label>
                    <input type="text" name="full_name" value="<?php echo sanitize($user['full_name']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Email <span style="color: #e74c3c;">*</span></label>
                    <input type="email" name="email" value="<?php echo sanitize($user['email'] ?? ''); ?>" placeholder="Enter email address">
                    <small style="color: var(--text-light);">Must contain @ symbol</small>
                </div>
                
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" value="<?php echo sanitize($user['phone'] ?? ''); ?>" placeholder="Enter phone number">
                </div>
                
                <div class="form-group">
                    <label>Role</label>
                    <input type="text" value="<?php echo ucfirst($user['role']); ?>" disabled>
                </div>
                
                <div class="form-group">
                    <label>Account Status</label>
                    <input type="text" value="<?php echo ucfirst($user['status']); ?>" disabled>
                </div>
                
                <div class="form-group">
                    <label>Joined</label>
                    <input type="text" value="<?php echo date('F d, Y h:i A', strtotime($user['created_at'])); ?>" disabled>
                </div>
                
                <button type="submit" class="btn-save"><i class="fas fa-save"></i> Update Profile</button>
                
                <div class="profile-actions">
                    <a href="<?php echo $dashboardLink; ?>" class="btn btn-primary" style="text-decoration: none;">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                    <?php if ($isAdmin): ?>
                    <a href="<?php echo SITE_URL; ?>modules/admin/dashboard.php" class="btn btn-secondary" style="text-decoration: none;">
                        <i class="fas fa-tachometer-alt"></i> Admin Dashboard
                    </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// ======================================================
// FIXED JAVASCRIPT - No errors
// ======================================================

document.addEventListener('DOMContentLoaded', function() {
    // Get elements
    const fileInput = document.getElementById('profilePictureInput');
    const uploadForm = document.getElementById('uploadForm');
    const previewContainer = document.querySelector('.image-preview-container');
    
    // Auto-submit form when file is selected
    if (fileInput) {
        fileInput.addEventListener('change', function(e) {
            const file = this.files[0];
            if (file) {
                // Check file size (2MB max)
                if (file.size > 2 * 1024 * 1024) {
                    alert('Image size must be less than 2MB!');
                    this.value = '';
                    return;
                }
                
                // Check file type
                const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                if (!allowedTypes.includes(file.type)) {
                    alert('Only JPG, PNG, GIF, and WEBP images are allowed!');
                    this.value = '';
                    return;
                }
                
                // Preview image
                const reader = new FileReader();
                reader.onload = function(e) {
                    const avatar = document.querySelector('.profile-avatar');
                    const placeholder = document.getElementById('profileAvatarPlaceholder');
                    if (avatar) {
                        avatar.src = e.target.result;
                    } else if (placeholder) {
                        // Replace placeholder with image
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.className = 'profile-avatar';
                        img.id = 'profileAvatar';
                        img.alt = 'Profile Picture';
                        placeholder.parentNode.replaceChild(img, placeholder);
                    }
                };
                reader.readAsDataURL(file);
                
                // Submit form
                if (uploadForm) {
                    uploadForm.submit();
                }
            }
        });
    }
    
    // Click on avatar to upload
    if (previewContainer) {
        previewContainer.addEventListener('click', function() {
            if (fileInput) {
                fileInput.click();
            }
        });
    }
});

// Also handle the upload button click
function triggerFileUpload() {
    document.getElementById('profilePictureInput').click();
}
</script>

<?php include '../../includes/footer.php'; ?>