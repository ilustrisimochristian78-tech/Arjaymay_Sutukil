<?php
// ======================================================
// ADMIN LOGIN - WITH LOGO & BACKGROUND
// ======================================================
require_once '../../config/database.php';

if (isLoggedIn() && isAdmin()) {
    header('Location: ../admin/dashboard.php');
    exit;
}

$error = '';
$success = '';

$pdo = getDBConnection();

// Get site settings
$settings = getSiteSettings();
$siteLogo = getSiteLogo();
$siteName = $settings['site_name'] ?? 'Arjaymay Sutukil';
$favicon = getSiteFavicon();
$backgroundImage = getBackgroundImage();

// Check if is_first_login column exists
$columnExists = false;
try {
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'is_first_login'");
    $columnExists = $stmt->rowCount() > 0;
} catch (PDOException $e) {
    $columnExists = false;
}

// Check if admin exists
$stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
$adminExists = $stmt->fetch()['count'] > 0;

// Password strength validation function
function isStrongPassword(string $password): array {
    if (strlen($password) < 8) {
        return ['valid' => false, 'message' => 'Password must be at least 8 characters long.'];
    }
    if (!preg_match('/[A-Z]/', $password)) {
        return ['valid' => false, 'message' => 'Password must contain at least one uppercase letter.'];
    }
    if (!preg_match('/[a-z]/', $password)) {
        return ['valid' => false, 'message' => 'Password must contain at least one lowercase letter.'];
    }
    if (!preg_match('/[0-9]/', $password)) {
        return ['valid' => false, 'message' => 'Password must contain at least one number.'];
    }
    if (!preg_match('/[^A-Za-z0-9]/', $password)) {
        return ['valid' => false, 'message' => 'Password must contain at least one special character (!@#$%^&* etc.).'];
    }
    return ['valid' => true, 'message' => ''];
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'login';
    
    if ($action === 'login') {
        $username = sanitize($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $error = 'Please enter both username and password.';
        } else {
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role = 'admin' AND status = 'active'");
                $stmt->execute([$username]);
                $user = $stmt->fetch();
                
                if (!$user) {
                    $error = 'Invalid username or password. Please try again.';
                } else {
                    if (password_verify($password, $user['password'])) {
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['full_name'] = $user['full_name'];
                        $_SESSION['role'] = $user['role'];
                        $_SESSION['is_first_login'] = $columnExists ? ($user['is_first_login'] ?? false) : false;
                        
                        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'admin_login', ?)");
                        $stmt->execute([$user['id'], "Admin {$user['full_name']} logged in"]);
                        
                        header('Location: ../admin/dashboard.php');
                        exit;
                    } else {
                        $error = 'Invalid username or password. Please try again.';
                    }
                }
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
    
    if ($action === 'register') {
        $username = sanitize($_POST['username'] ?? '');
        $full_name = sanitize($_POST['full_name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
        $adminExistsCheck = $stmt->fetch()['count'] > 0;
        
        if ($adminExistsCheck) {
            $error = 'An administrator account already exists. Please login.';
        } elseif (empty($username) || empty($full_name) || empty($password)) {
            $error = 'Username, full name, and password are required.';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match.';
        } elseif (!empty($email) && strpos($email, '@') === false) {
            $error = 'Email must contain the @ symbol (e.g., user@example.com).';
        } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address (e.g., user@example.com).';
        } else {
            $passwordCheck = isStrongPassword($password);
            if (!$passwordCheck['valid']) {
                $error = $passwordCheck['message'];
            } else {
                try {
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
                    $stmt->execute([$username]);
                    if ($stmt->fetch()) {
                        $error = 'Username already exists.';
                    } else {
                        if (!empty($email)) {
                            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                            $stmt->execute([$email]);
                            if ($stmt->fetch()) {
                                $error = 'Email already exists.';
                            }
                        }
                        
                        if (empty($error)) {
                            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                            
                            if ($columnExists) {
                                $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, email, phone, role, is_first_login) VALUES (?, ?, ?, ?, ?, 'admin', FALSE)");
                                $result = $stmt->execute([$username, $hashedPassword, $full_name, $email, $phone]);
                            } else {
                                $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, email, phone, role) VALUES (?, ?, ?, ?, ?, 'admin')");
                                $result = $stmt->execute([$username, $hashedPassword, $full_name, $email, $phone]);
                            }
                            
                            if ($result) {
                                $success = 'Admin account created successfully! Please login.';
                                
                                $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (NULL, 'admin_registration', ?)");
                                $stmt->execute(["New admin account created: $username"]);
                                
                                $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
                                $adminExists = $stmt->fetch()['count'] > 0;
                            } else {
                                $error = 'Failed to create admin account. Please try again.';
                            }
                        }
                    }
                } catch (PDOException $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            }
        }
    }
}

// Final admin exists check
$stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
$adminExists = $stmt->fetch()['count'] > 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $siteName; ?> - Admin Login</title>
    <?php if ($favicon): ?>
    <link rel="icon" href="<?php echo $favicon; ?>">
    <?php endif; ?>
    <?php include __DIR__ . '/../../includes/asset_links.php'; ?>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: linear-gradient(135deg, #1a3d1b, #2c5f2d);
            background-size: cover;
            background-position: center;
            position: relative;
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.4);
            z-index: 0;
        }
        <?php if ($backgroundImage): ?>
        body {
            background-image: url('<?php echo $backgroundImage; ?>');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        <?php endif; ?>
        .login-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 480px;
            padding: 40px 36px;
            position: relative;
            z-index: 1;
        }
        .login-header { text-align: center; margin-bottom: 28px; }
        .login-header .logo-icon { margin-bottom: 12px; }
        .login-header .logo-icon img { max-height: 80px; max-width: 200px; object-fit: contain; }
        .login-header .logo-icon i { font-size: 2.5rem; color: #e74c3c; }
        .login-header h1 { font-size: 1.3rem; color: #2d3436; margin-bottom: 4px; }
        .login-header p { color: #636e72; font-size: 0.9rem; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.85rem; font-weight: 500; color: #2d3436; margin-bottom: 4px; }
        .form-group label .required { color: #e74c3c; }
        .form-group input {
            width: 100%; padding: 10px 14px; border: 2px solid #e0e0e0; border-radius: 8px;
            font-family: 'Poppins', sans-serif; font-size: 0.95rem; transition: all 0.3s ease;
        }
        .form-group input:focus {
            border-color: #2c5f2d; outline: none; box-shadow: 0 0 0 3px rgba(44,95,45,0.1);
        }
        .password-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }
        .password-wrapper input {
            padding-right: 45px;
            width: 100%;
        }
        .password-toggle {
            position: absolute;
            right: 12px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1.1rem;
            color: #636e72;
            padding: 4px 8px;
            transition: color 0.3s ease;
        }
        .password-toggle:hover { color: #2c5f2d; }
        .password-toggle .fa-eye-slash { display: none; }
        .password-toggle.show .fa-eye { display: none; }
        .password-toggle.show .fa-eye-slash { display: inline; }
        .btn-primary {
            width: 100%; padding: 12px; background: #2c5f2d; color: #fff; border: none;
            border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer;
            transition: all 0.3s ease; font-family: 'Poppins', sans-serif;
        }
        .btn-primary:hover { background: #1a3d1b; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(44,95,45,0.3); }
        .alert-error {
            background: #f8d7da; color: #721c24; padding: 10px 14px; border-radius: 8px;
            font-size: 0.85rem; margin-bottom: 16px; border: 1px solid #f5c6cb;
        }
        .alert-success {
            background: #d4edda; color: #155724; padding: 10px 14px; border-radius: 8px;
            font-size: 0.85rem; margin-bottom: 16px; border: 1px solid #c3e6cb;
        }
        .login-footer-links { text-align: center; margin-top: 16px; }
        .back-link {
            color: #636e72; text-decoration: none; font-size: 0.85rem; transition: all 0.3s ease;
            display: inline-block; margin-top: 8px;
        }
        .back-link:hover { color: #2c5f2d; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        @media (max-width: 480px) { .form-row { grid-template-columns: 1fr; } }
        .toggle-container { display: flex; gap: 8px; justify-content: center; margin-bottom: 16px; }
        .toggle-tab {
            padding: 8px 24px; border: 2px solid #e0e0e0; border-radius: 20px;
            background: #f8f9fa; cursor: pointer; font-family: 'Poppins', sans-serif;
            font-size: 0.85rem; font-weight: 500; transition: all 0.3s ease;
        }
        .toggle-tab.active {
            border-color: #2c5f2d; background: #2c5f2d; color: #fff;
        }
        .toggle-tab:hover:not(.active) { border-color: #2c5f2d; }
        .toggle-tab.disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .toggle-tab.disabled:hover { border-color: #e0e0e0; }
        .form-panel { display: none; }
        .form-panel.active { display: block; }
        .admin-exists-notice {
            background: #fff3cd;
            color: #856404;
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 0.85rem;
            margin-bottom: 16px;
            border: 1px solid #ffc107;
            text-align: center;
        }
        .no-admin-notice {
            background: #d1ecf1;
            color: #0c5460;
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 0.85rem;
            margin-bottom: 16px;
            border: 1px solid #bee5eb;
            text-align: center;
        }
        .no-admin-notice i { margin-right: 6px; }
        .password-requirements {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 10px 14px;
            margin-top: 6px;
            font-size: 0.75rem;
            display: none;
        }
        .password-requirements.show { display: block; }
        .password-requirements .req-item { padding: 2px 0; color: #636e72; transition: color 0.3s ease; }
        .password-requirements .req-item.met { color: #2c5f2d; }
        .password-requirements .req-item i { margin-right: 6px; width: 16px; }
        .password-requirements .req-item.met i { color: #2c5f2d; }
        .password-requirements .req-item:not(.met) i { color: #e74c3c; }
        .strength-indicator {
            height: 4px;
            border-radius: 2px;
            margin-top: 6px;
            background: #e0e0e0;
            transition: all 0.3s ease;
            overflow: hidden;
        }
        .strength-indicator .strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s ease;
            border-radius: 2px;
        }
        .strength-indicator .strength-bar.weak { width: 25%; background: #e74c3c; }
        .strength-indicator .strength-bar.medium { width: 50%; background: #f39c12; }
        .strength-indicator .strength-bar.strong { width: 75%; background: #2ecc71; }
        .strength-indicator .strength-bar.very-strong { width: 100%; background: #27ae60; }
        .strength-text { font-size: 0.7rem; margin-top: 2px; text-align: right; }
        .strength-text.weak { color: #e74c3c; }
        .strength-text.medium { color: #f39c12; }
        .strength-text.strong { color: #2ecc71; }
        .strength-text.very-strong { color: #27ae60; }
        .email-hint { color: #636e72; font-size: 0.75rem; margin-top: 2px; }
        .email-hint i { color: #2c5f2d; margin-right: 4px; }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo-icon">
                <?php if ($siteLogo): ?>
                    <img src="<?php echo $siteLogo; ?>" alt="<?php echo $siteName; ?>">
                <?php else: ?>
                    <i class="fas fa-user-shield"></i>
                <?php endif; ?>
            </div>
            <h1><?php echo $siteName; ?></h1>
            <p>Administrator Access</p>
        </div>
        
        <?php if ($error): ?>
        <div class="alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
        <div class="alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (!$adminExists && !$success): ?>
        <div class="no-admin-notice">
            <i class="fas fa-info-circle"></i> No admin account found. Please create one using the "Create Admin" tab.
        </div>
        <?php endif; ?>
        
        <?php if ($adminExists && !$success): ?>
        <div class="admin-exists-notice">
            <i class="fas fa-info-circle"></i> Admin account already exists. Please login.
        </div>
        <?php endif; ?>
        
        <div class="toggle-container">

            <button class="toggle-tab <?php echo !$adminExists ? 'active' : 'disabled'; ?>" data-form="register" <?php echo $adminExists ? 'disabled' : ''; ?>>
                Create Admin
            </button>
        </div>
        
        <!-- Login Form -->
        <div class="form-panel <?php echo $adminExists ? 'active' : ''; ?>" id="loginForm">
            <form method="POST" action="">
                <input type="hidden" name="action" value="login">
                <div class="form-group">
                    <label for="login_username"><i class="fas fa-user"></i> Username</label>
                    <input type="text" id="login_username" name="username" placeholder="Enter admin username" required autofocus>
                </div>
                <div class="form-group">
                    <label for="login_password"><i class="fas fa-lock"></i> Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="login_password" name="password" placeholder="Enter password" required>
                        <button type="button" class="password-toggle" onclick="togglePassword('login_password', this)">
                            <i class="fas fa-eye"></i>
                            <i class="fas fa-eye-slash"></i>
                        </button>
                    </div>
                </div>
                <button type="submit" class="btn-primary"><i class="fas fa-sign-in-alt"></i> Login as Admin</button>
            </form>
        </div>
        
        <!-- Register Form -->
        <div class="form-panel <?php echo !$adminExists ? 'active' : ''; ?>" id="registerForm">
            <?php if (!$adminExists): ?>
            <form method="POST" action="" id="registerForm">
                <input type="hidden" name="action" value="register">
                <div class="form-row">
                    <div class="form-group">
                        <label>Username <span class="required">*</span></label>
                        <input type="text" name="username" placeholder="Enter username" required>
                    </div>
                    <div class="form-group">
                        <label>Full Name <span class="required">*</span></label>
                        <input type="text" name="full_name" placeholder="Enter full name" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Email <span class="required">*</span></label>
                        <input type="email" name="email" placeholder="Enter email address (must contain @)" required>
                        <div class="email-hint"><i class="fas fa-info-circle"></i> Email must contain the @ symbol</div>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" placeholder="Enter phone number">
                    </div>
                </div>
                <div class="form-group">
                    <label>Password <span class="required">*</span></label>
                    <div class="password-wrapper">
                        <input type="password" id="reg_password" name="password" placeholder="Enter password" required oninput="checkPasswordStrength(this.value)">
                        <button type="button" class="password-toggle" onclick="togglePassword('reg_password', this)">
                            <i class="fas fa-eye"></i>
                            <i class="fas fa-eye-slash"></i>
                        </button>
                    </div>
                    <div class="strength-indicator">
                        <div class="strength-bar" id="strengthBar"></div>
                    </div>
                    <div class="strength-text" id="strengthText"></div>
                    <div class="password-requirements show" id="passwordRequirements">
                        <div class="req-item" id="reqLength"><i class="fas fa-circle"></i> At least 8 characters</div>
                        <div class="req-item" id="reqUppercase"><i class="fas fa-circle"></i> At least one uppercase letter (A-Z)</div>
                        <div class="req-item" id="reqLowercase"><i class="fas fa-circle"></i> At least one lowercase letter (a-z)</div>
                        <div class="req-item" id="reqNumber"><i class="fas fa-circle"></i> At least one number (0-9)</div>
                        <div class="req-item" id="reqSpecial"><i class="fas fa-circle"></i> At least one special character (!@#$%^&*)</div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Confirm Password <span class="required">*</span></label>
                    <div class="password-wrapper">
                        <input type="password" id="reg_confirm_password" name="confirm_password" placeholder="Confirm password" required oninput="checkPasswordMatch()">
                        <button type="button" class="password-toggle" onclick="togglePassword('reg_confirm_password', this)">
                            <i class="fas fa-eye"></i>
                            <i class="fas fa-eye-slash"></i>
                        </button>
                    </div>
                    <div id="confirmMessage" style="font-size:0.75rem; margin-top:4px;"></div>
                </div>
                <button type="submit" class="btn-primary" id="registerBtn"><i class="fas fa-user-plus"></i> Create Admin Account</button>
            </form>
            <?php else: ?>
            <div class="admin-exists-notice">
                <i class="fas fa-lock"></i> Admin account already exists. Registration is disabled.
            </div>
            <?php endif; ?>
        </div>
        
        <div class="login-footer-links">
            <a href="../../index.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Role Selection</a>
        </div>
    </div>
    
    <script>
        function togglePassword(inputId, button) {
            const input = document.getElementById(inputId);
            if (input.type === 'password') {
                input.type = 'text';
                button.classList.add('show');
            } else {
                input.type = 'password';
                button.classList.remove('show');
            }
        }
        
        document.querySelectorAll('.toggle-tab:not(.disabled)').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.toggle-tab').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                
                const formId = this.dataset.form;
                document.querySelectorAll('.form-panel').forEach(p => p.classList.remove('active'));
                document.getElementById(formId + 'Form').classList.add('active');
            });
        });
        
        function checkPasswordStrength(password) {
            const requirements = {
                length: password.length >= 8,
                uppercase: /[A-Z]/.test(password),
                lowercase: /[a-z]/.test(password),
                number: /[0-9]/.test(password),
                special: /[^A-Za-z0-9]/.test(password)
            };
            
            document.getElementById('reqLength').className = 'req-item' + (requirements.length ? ' met' : '');
            document.getElementById('reqUppercase').className = 'req-item' + (requirements.uppercase ? ' met' : '');
            document.getElementById('reqLowercase').className = 'req-item' + (requirements.lowercase ? ' met' : '');
            document.getElementById('reqNumber').className = 'req-item' + (requirements.number ? ' met' : '');
            document.getElementById('reqSpecial').className = 'req-item' + (requirements.special ? ' met' : '');
            
            const metCount = Object.values(requirements).filter(Boolean).length;
            const strengthBar = document.getElementById('strengthBar');
            const strengthText = document.getElementById('strengthText');
            
            if (password.length === 0) {
                strengthBar.className = 'strength-bar';
                strengthText.textContent = '';
                strengthText.className = 'strength-text';
                return;
            }
            
            let strengthClass, text;
            if (metCount <= 1) { strengthClass = 'weak'; text = 'Weak'; }
            else if (metCount <= 3) { strengthClass = 'medium'; text = 'Medium'; }
            else if (metCount <= 4) { strengthClass = 'strong'; text = 'Strong'; }
            else { strengthClass = 'very-strong'; text = 'Very Strong'; }
            
            strengthBar.className = 'strength-bar ' + strengthClass;
            strengthText.textContent = text;
            strengthText.className = 'strength-text ' + strengthClass;
            
            const allMet = Object.values(requirements).every(Boolean);
            document.getElementById('registerBtn').disabled = !allMet;
            checkPasswordMatch();
        }
        
        function checkPasswordMatch() {
            const password = document.getElementById('reg_password').value;
            const confirm = document.getElementById('reg_confirm_password').value;
            const message = document.getElementById('confirmMessage');
            const btn = document.getElementById('registerBtn');
            
            const requirements = {
                length: password.length >= 8,
                uppercase: /[A-Z]/.test(password),
                lowercase: /[a-z]/.test(password),
                number: /[0-9]/.test(password),
                special: /[^A-Za-z0-9]/.test(password)
            };
            const allMet = Object.values(requirements).every(Boolean);
            
            if (confirm.length === 0) {
                message.textContent = '';
                message.style.color = '';
                if (!allMet) btn.disabled = true;
                return;
            }
            
            if (password === confirm) {
                message.innerHTML = '<i class="fas fa-check-circle" style="color:#2c5f2d;"></i> Passwords match!';
                message.style.color = '#2c5f2d';
                btn.disabled = !allMet;
            } else {
                message.innerHTML = '<i class="fas fa-exclamation-circle" style="color:#e74c3c;"></i> Passwords do not match!';
                message.style.color = '#e74c3c';
                btn.disabled = true;
            }
        }
    </script>
</body>
</html>