<?php
// ======================================================
// RECEIPT - COMPLETE FIXED VERSION WITH LOGO
// ======================================================
require_once '../../config/database.php';
requireCashier();

$orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if ($orderId <= 0) {
    die('Invalid order ID');
}

// Get order details
$order = getOrderDetails($orderId);

if (!$order) {
    die('Order not found');
}

// Get site settings
$settings = getSiteSettings();
$siteLogo = getSiteLogo();
$siteName = $settings['site_name'] ?? 'Arjaymay Sutukil';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt - <?php echo $order['order_number']; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Courier New', monospace; 
            margin: 0; 
            padding: 20px; 
            background: #f5f5f5; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            min-height: 100vh; 
        }
        .receipt { 
            background: #fffef7; 
            width: 350px; 
            padding: 20px; 
            border: 2px solid #333; 
            border-radius: 8px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.1); 
        }
        .receipt-header { 
            text-align: center; 
            border-bottom: 2px dashed #ccc; 
            padding-bottom: 12px; 
            margin-bottom: 12px; 
        }
        .receipt-header .receipt-logo { 
            max-height: 50px; 
            max-width: 150px; 
            object-fit: contain; 
            margin-bottom: 6px; 
            display: block; 
            margin-left: auto; 
            margin-right: auto; 
        }
        .receipt-header h3 { 
            margin: 0; 
            color: #2c5f2d; 
            font-size: 1.1rem; 
        }
        .receipt-header p { 
            margin: 4px 0 0; 
            font-size: 0.8rem; 
            color: #666; 
        }
        .receipt-divider { 
            border-top: 1px dashed #ccc; 
            margin: 8px 0; 
        }
        .receipt-row { 
            display: flex; 
            justify-content: space-between; 
            font-size: 0.85rem; 
            padding: 2px 0; 
        }
        .receipt-row.total { 
            font-weight: 700; 
            font-size: 1rem; 
            border-top: 2px solid #333; 
            padding-top: 8px; 
            margin-top: 8px; 
        }
        .receipt-row .item-name { 
            flex: 1; 
        }
        .receipt-row .item-qty { 
            margin: 0 8px; 
            color: #666; 
        }
        .receipt-row .item-amount { 
            font-weight: 500; 
        }
        .receipt-footer { 
            text-align: center; 
            margin-top: 16px; 
            padding-top: 12px; 
            border-top: 2px dashed #ccc; 
            font-size: 0.8rem; 
            color: #666; 
        }
        .receipt-footer strong { 
            color: #2c5f2d; 
        }
        .receipt-footer .footer-logo { 
            max-height: 30px; 
            max-width: 100px; 
            object-fit: contain; 
            margin-bottom: 4px; 
        }
        @media print { 
            body { 
                background: white; 
                padding: 0; 
            } 
            .receipt { 
                box-shadow: none; 
                border: 1px solid #ccc; 
            } 
        }
    </style>
</head>
<body>
    <div class="receipt" id="receipt">
        <div class="receipt-header">
            <?php if ($siteLogo): ?>
                <img src="<?php echo $siteLogo; ?>" alt="<?php echo $siteName; ?>" class="receipt-logo">
            <?php endif; ?>
            <h3><?php echo $siteName; ?></h3>
            <p>OFFICIAL RECEIPT</p>
        </div>
        
        <div class="receipt-row">
            <span><strong>Trans #</strong> <?php echo $order['order_number']; ?></span>
            <span><strong>Cashier</strong> <?php echo sanitize($order['cashier_name']); ?></span>
        </div>
        <div class="receipt-row">
            <span><strong>Date</strong> <?php echo date('m/d/Y', strtotime($order['created_at'])); ?></span>
            <span><strong>Time</strong> <?php echo date('h:i A', strtotime($order['created_at'])); ?></span>
        </div>
        <div class="receipt-row">
            <span><strong>Type</strong> <?php echo strtoupper(str_replace('_', ' ', $order['order_type'])); ?></span>
        </div>
        
        <div class="receipt-divider"></div>
        
        <div style="font-weight: 600; font-size: 0.8rem; padding: 4px 0;">
            <span>Item</span>
            <span style="float: right;">Qty Amount</span>
        </div>
        
        <?php foreach ($order['items'] as $item): ?>
        <div class="receipt-row">
            <span class="item-name"><?php echo sanitize($item['item_name']); ?></span>
            <span class="item-qty">x<?php echo $item['quantity']; ?></span>
            <span class="item-amount">₱<?php echo number_format($item['subtotal'], 2); ?></span>
        </div>
        <?php endforeach; ?>
        
        <div class="receipt-divider"></div>
        
        <div class="receipt-row">
            <span>Subtotal</span>
            <span>₱<?php echo number_format($order['subtotal'], 2); ?></span>
        </div>

        <?php if (!empty($order['discount_type']) && $order['discount_type'] !== 'none' && (float)$order['discount'] > 0): ?>
        <?php $appliedPct = ((float)$order['subtotal'] > 0) ? round(((float)$order['discount'] / (float)$order['subtotal']) * 100, 2) : 0; ?>
        <div class="receipt-row">
            <span><?php echo ($order['discount_type'] === 'senior' ? 'Senior Citizen Discount' : 'PWD Discount') . ' (' . rtrim(rtrim(number_format($appliedPct, 2), '0'), '.') . '%)'; ?></span>
            <span>-₱<?php echo number_format($order['discount'], 2); ?></span>
        </div>
        <div class="receipt-row">
            <span>ID Number</span>
            <span><?php echo sanitize((string)($order['discount_id_number'] ?? '')); ?></span>
        </div>
        <?php endif; ?>
        
        <div class="receipt-row total">
            <span>TOTAL</span>
            <span>₱<?php echo number_format($order['total'], 2); ?></span>
        </div>

        <div class="receipt-row">
            <span>Payment Method</span>
            <span><?php echo strtoupper($order['payment_method'] ?? 'CASH'); ?></span>
        </div>
        
        <?php if (($order['payment_method'] ?? 'cash') === 'gcash'): ?>
        <div class="receipt-row">
            <span>Amount Paid</span>
            <span>₱<?php echo number_format($order['payment_amount'], 2); ?></span>
        </div>
        <?php else: ?>
        <div class="receipt-row">
            <span>Cash</span>
            <span>₱<?php echo number_format($order['payment_amount'], 2); ?></span>
        </div>
        <div class="receipt-row">
            <span>Change</span>
            <span>₱<?php echo number_format($order['change_amount'], 2); ?></span>
        </div>
        <?php endif; ?>
        
        <div class="receipt-footer">
            <?php if ($siteLogo): ?>
                <img src="<?php echo $siteLogo; ?>" alt="<?php echo $siteName; ?>" class="footer-logo">
            <?php endif; ?>
            <strong>THANK YOU! PLEASE COME AGAIN!</strong><br>
            <small><?php echo $siteName; ?> POS System v1.0</small>
        </div>
    </div>
    
    <script>
        window.onload = function() {
            setTimeout(function() {
                if (confirm('Print this receipt?')) {
                    window.print();
                    setTimeout(function() {
                        window.close();
                    }, 2500);
                }
            }, 300);
        }
    </script>
</body>
</html>