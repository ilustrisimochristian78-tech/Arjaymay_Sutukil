<?php
// ======================================================
// VIEW STOCKS (Admin Only)
// ======================================================
require_once '../../config/database.php';
requireAdmin();

$pdo = getDBConnection();

$stmt = $pdo->query("SELECT m.*, c.name as category_name FROM menu_items m LEFT JOIN categories c ON m.category_id = c.id ORDER BY c.sort_order, m.name");
$items = $stmt->fetchAll();
$categories = getAllCategories();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_stock') {
    $item_id = (int)($_POST['item_id'] ?? 0);
    $new_stock = (int)($_POST['stock'] ?? 0);
    if ($item_id > 0 && $new_stock >= 0) {
        try {
            $stmt = $pdo->prepare("UPDATE menu_items SET stock = ?, status = CASE WHEN ? <= 0 THEN 'out_of_stock' WHEN ? <= 10 THEN 'low_stock' ELSE 'available' END WHERE id = ?");
            $stmt->execute([$new_stock, $new_stock, $new_stock, $item_id]);
            $message = 'Stock updated successfully!';
            $stmt = $pdo->prepare("SELECT m.*, c.name as category_name FROM menu_items m LEFT JOIN categories c ON m.category_id = c.id ORDER BY c.sort_order, m.name");
            $stmt->execute();
            $items = $stmt->fetchAll();
        } catch (PDOException $e) {
            $error = 'Error: ' . $e->getMessage();
        }
    }
}

include '../../includes/header.php';
?>

<div class="page-header">
    <h2><i class="fas fa-warehouse"></i> Stock Management</h2>
    <p>View and update inventory levels</p>
</div>

<?php if (isset($message)): ?>
<div class="alert alert-success"><?php echo $message; ?></div>
<?php endif; ?>
<?php if (isset($error)): ?>
<div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="dashboard-stats" style="margin-bottom: 24px;">
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-boxes"></i></div>
        <div class="stat-info"><h3><?php $count=0; foreach($items as $item){if($item['stock']>10)$count++;} echo $count; ?></h3><p>Available Items</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fas fa-exclamation-triangle"></i></div>
        <div class="stat-info"><h3><?php $count=0; foreach($items as $item){if($item['stock']<=10&&$item['stock']>0)$count++;} echo $count; ?></h3><p>Low Stock Items</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red"><i class="fas fa-times-circle"></i></div>
        <div class="stat-info"><h3><?php $count=0; foreach($items as $item){if($item['stock']<=0)$count++;} echo $count; ?></h3><p>Out of Stock</p></div>
    </div>
</div>

<div style="margin-bottom: 16px; display: flex; flex-wrap: wrap; gap: 8px;">
    <button class="btn btn-primary btn-sm" onclick="filterStock('all')">All Items</button>
    <?php foreach ($categories as $cat): ?>
    <button class="btn btn-secondary btn-sm" onclick="filterStock(<?php echo $cat['id']; ?>)"><?php echo sanitize($cat['name']); ?></button>
    <?php endforeach; ?>
</div>

<div class="table-container">
    <div class="table-header">
        <h3><i class="fas fa-list"></i> Inventory List</h3>
        <span class="badge badge-primary"><?php echo count($items); ?> items</span>
    </div>
    <table id="stockTable">
        <thead><tr><th>ID</th><th>Category</th><th>Item Name</th><th>Price</th><th>Stock</th><th>Status</th></tr></thead>
        <tbody>
            <?php if (empty($items)): ?>
            <tr><td colspan="6" style="text-align: center; padding: 30px;">No items found.</td></tr>
            <?php else: ?>
            <?php foreach ($items as $item): ?>
            <tr data-category="<?php echo $item['category_id']; ?>">
                <td>#<?php echo $item['id']; ?></td>
                <td><span class="badge badge-primary"><?php echo sanitize($item['category_name']); ?></span></td>
                <td><strong><?php echo sanitize($item['name']); ?></strong></td>
                <td><?php echo formatCurrency($item['price']); ?></td>
                <td>
                    <form method="POST" action="" style="display: inline-flex; gap: 4px; align-items: center;">
                        <input type="hidden" name="action" value="update_stock">
                        <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                        <input type="number" name="stock" value="<?php echo $item['stock']; ?>" min="0" style="width: 60px; padding: 4px 6px; border: 1px solid #ddd; border-radius: 4px;">
                        <button type="submit" class="btn btn-primary btn-sm">Update</button>
                    </form>
                </td>
                <td>
                    <?php
                    $statusClass = 'badge-success'; $statusText = 'Available';
                    if ($item['stock'] <= 0) { $statusClass = 'badge-danger'; $statusText = 'Out of Stock'; }
                    elseif ($item['stock'] <= 10) { $statusClass = 'badge-warning'; $statusText = 'Low Stock'; }
                    ?>
                    <span class="badge <?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
function filterStock(categoryId) {
    const rows = document.querySelectorAll('#stockTable tbody tr');
    rows.forEach(row => {
        if (categoryId === 'all') { row.style.display = ''; }
        else { const cat = parseInt(row.dataset.category); row.style.display = cat === categoryId ? '' : 'none'; }
    });
}
</script>

<?php include '../../includes/footer.php'; ?>