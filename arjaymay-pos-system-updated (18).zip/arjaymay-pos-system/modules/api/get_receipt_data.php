<?php
// ======================================================
// GET RECEIPT DATA (API) - COMPLETE FIX
// ======================================================
require_once '../../config/database.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

$orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if ($orderId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid order ID']);
    exit;
}

try {
    $pdo = getDBConnection();
    
    // Get order details
    $stmt = $pdo->prepare("
        SELECT 
            o.*, 
            u.full_name as cashier_name
        FROM orders o
        LEFT JOIN users u ON o.cashier_id = u.id
        WHERE o.id = ?
    ");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo json_encode(['success' => false, 'error' => 'Order not found']);
        exit;
    }
    
    // Get order items
    $stmt = $pdo->prepare("
        SELECT 
            oi.*, 
            m.name as item_name
        FROM order_items oi
        LEFT JOIN menu_items m ON oi.menu_item_id = m.id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format items
    $formattedItems = [];
    foreach ($items as $item) {
        $formattedItems[] = [
            'name' => $item['item_name'] ?? 'Unknown Item',
            'quantity' => (int)$item['quantity'],
            'price' => (float)$item['price'],
            'subtotal' => (float)$item['subtotal']
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'order_number' => $order['order_number'],
        'cashier_name' => $order['cashier_name'] ?? 'Unknown',
        'date' => date('M d, Y', strtotime($order['created_at'])),
        'time' => date('h:i A', strtotime($order['created_at'])),
        'order_type' => $order['order_type'] ?? 'dine_in',
        'subtotal' => (float)($order['subtotal'] ?? 0),
        'takeout_fee' => (float)($order['takeout_fee'] ?? 0),
        'total' => (float)($order['total'] ?? 0),
        'payment_amount' => (float)($order['payment_amount'] ?? 0),
        'change_amount' => (float)($order['change_amount'] ?? 0),
        'items' => $formattedItems,
        'status' => $order['status'] ?? 'completed'
    ];
    
    echo json_encode($response);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>