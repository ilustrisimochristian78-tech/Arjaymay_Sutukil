<?php
// ======================================================
// SEARCH TRANSACTION BY CASHIER (Cashier Only)
// ======================================================
require_once '../../config/database.php';
requireCashier();

$pdo = getDBConnection();
$error = '';
$results = [];
$search_id = '';
$cashier_found = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $search_id = sanitize($_POST['cashier_id'] ?? '');
    if (empty($search_id)) {
        $error = 'Please enter a Cashier ID or Username.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE (id = ? OR username = ?) AND role = 'cashier'");
        $stmt->execute([$search_id, $search_id]);
        $cashier_found = $stmt->fetch();
        if (!$cashier_found) {
            $error = 'Cashier not found.';
        } else {
            $stmt = $pdo->prepare("SELECT o.*, u.full_name as cashier_name FROM orders o LEFT JOIN users u ON o.cashier_id = u.id WHERE o.cashier_id = ? AND o.status = 'completed' ORDER BY o.created_at DESC LIMIT 100");
            $stmt->execute([$cashier_found['id']]);
            $results = $stmt->fetchAll();
            if (empty($results)) { $error = 'No transactions found for this cashier.'; }
        }
    }
}

include '../../includes/header.php';
?>

<div class="page-header">
    <h2><i class="fas fa-search"></i> Search Transactions</h2>
    <p>Search transactions by Cashier ID or Username</p>
</div>

<div class="table-container">
    <div class="table-header"><h3><i class="fas fa-search"></i> Search Cashier</h3></div>
    <div style="padding: 20px;">
        <form method="POST" action="" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 200px;">
                <input type="text" id="cashier_id" name="cashier_id" placeholder="Enter Cashier ID or Username" value="<?php echo htmlspecialchars($search_id); ?>" style="width: 100%; padding: 10px 14px; border: 2px solid #ddd; border-radius: 8px; font-family: 'Poppins', sans-serif;">
            </div>
            <button type="submit" name="search" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
            <a href="search_transaction.php" class="btn btn-secondary"><i class="fas fa-sync"></i> Reset</a>
        </form>
        <small style="color: var(--text-light); display: block; margin-top: 8px;">Enter a cashier ID number (e.g., 1, 2, 3) or username.</small>
    </div>
</div>

<?php if ($error): ?>
<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<?php if ($cashier_found && !empty($results)): ?>
<div class="alert alert-info" style="display: flex; justify-content: space-between; align-items: center;">
    <div><strong><i class="fas fa-user"></i> Cashier:</strong> <?php echo sanitize($cashier_found['full_name']); ?> (ID: <?php echo $cashier_found['id']; ?>)</div>
    <span class="badge badge-primary"><?php echo count($results); ?> transactions</span>
</div>

<div class="table-container">
    <div class="table-header"><h3><i class="fas fa-list"></i> Transactions</h3><span class="badge badge-primary"><?php echo count($results); ?> records</span></div>
    <div style="overflow-x: auto;">
        <table>
            <thead><tr><th>Order #</th><th>Cashier</th><th>Type</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th>Date/Time</th><th>Actions</th></tr></thead>
            <tbody>
                <?php foreach ($results as $t): ?>
                <tr>
                    <td><strong><?php echo $t['order_number']; ?></strong></td>
                    <td><?php echo sanitize($t['cashier_name']); ?></td>
                    <td><span class="badge <?php echo $t['order_type'] == 'dine_in' ? 'badge-primary' : 'badge-warning'; ?>"><?php echo ucfirst(str_replace('_', ' ', $t['order_type'])); ?></span></td>
                    <td><?php $stmt2 = $pdo->prepare("SELECT SUM(quantity) as total_qty FROM order_items WHERE order_id = ?"); $stmt2->execute([$t['id']]); $items = $stmt2->fetch(); echo $items['total_qty'] . ' items'; ?></td>
                    <td><?php echo formatCurrency($t['total']); ?></td>
                    <td><span class="badge badge-success"><?php echo ucfirst($t['payment_method']); ?></span></td>
                    <td><span class="badge badge-success"><?php echo ucfirst($t['status']); ?></span></td>
                    <td><?php echo date('M d, Y', strtotime($t['created_at'])); ?><br><small><?php echo date('h:i A', strtotime($t['created_at'])); ?></small></td>
                    <td><button class="btn btn-primary btn-sm" onclick="window.open('receipt.php?order_id=<?php echo $t['id']; ?>', '_blank')"><i class="fas fa-receipt"></i></button></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="dashboard-stats" style="margin-top: 20px;">
    <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-receipt"></i></div><div class="stat-info"><h3><?php echo count($results); ?></h3><p>Total Transactions</p></div></div>
    <div class="stat-card"><div class="stat-icon green"><i class="fas fa-money-bill-wave"></i></div><div class="stat-info"><h3><?php $total=0; foreach($results as $t){$total+=$t['total'];} echo formatCurrency($total); ?></h3><p>Total Sales</p></div></div>
    <div class="stat-card"><div class="stat-icon orange"><i class="fas fa-chair"></i></div><div class="stat-info"><h3><?php $count=0; foreach($results as $t){if($t['order_type']=='dine_in')$count++;} echo $count; ?></h3><p>Dine In Orders</p></div></div>
    <div class="stat-card"><div class="stat-icon purple"><i class="fas fa-shopping-bag"></i></div><div class="stat-info"><h3><?php $count=0; foreach($results as $t){if($t['order_type']=='take_out')$count++;} echo $count; ?></h3><p>Take Out Orders</p></div></div>
</div>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>