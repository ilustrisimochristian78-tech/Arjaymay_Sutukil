<?php
require_once '../../config/database.php';
requireCashier();

header('Content-Type: application/json');

// Set a shorter timeout for this script
set_time_limit(30);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

// Get and validate input
$orderType = $_POST['order_type'] ?? 'dine_in';
$items = isset($_POST['items']) ? json_decode($_POST['items'], true) : [];
$subtotal = (float)($_POST['subtotal'] ?? 0);
$takeoutFee = (float)($_POST['takeout_fee'] ?? 0);
$paymentAmount = (float)($_POST['payment_amount'] ?? 0);
$changeAmount = (float)($_POST['change_amount'] ?? 0);

// Discount: Senior Citizen / PWD (20%). Recomputed server-side so it can't be tampered with.
$discountType = $_POST['discount_type'] ?? 'none';
if (!in_array($discountType, ['none', 'senior', 'pwd'])) {
    $discountType = 'none';
}
$discountIdNumber = isset($_POST['discount_id_number']) ? trim(sanitize((string)$_POST['discount_id_number'])) : '';

// Senior/PWD ID photo captured via the cashier's camera (base64 data URL from canvas.toDataURL)
$discountIdImageData = isset($_POST['discount_id_image']) ? $_POST['discount_id_image'] : '';

// A senior/PWD discount requires an ID number before the order can proceed to payment
if ($discountType !== 'none' && $discountIdNumber === '') {
    echo json_encode(['success' => false, 'error' => 'Senior Citizen / PWD ID number is required to apply this discount.']);
    exit;
}
if ($discountType === 'none') {
    $discountIdNumber = null;
}

// Payment method: cash or gcash (third-party)
$paymentMethod = $_POST['payment_method'] ?? 'cash';
if (!in_array($paymentMethod, ['cash', 'gcash'])) {
    $paymentMethod = 'cash';
}
$referenceNumber = isset($_POST['reference_number']) ? trim(sanitize((string)$_POST['reference_number'])) : '';
if ($paymentMethod === 'gcash' && $referenceNumber === '') {
    echo json_encode(['success' => false, 'error' => 'GCash reference number is required.']);
    exit;
}
if ($referenceNumber === '') {
    $referenceNumber = null;
}

// Validate items
if (empty($items)) {
    echo json_encode(['success' => false, 'error' => 'No items in order']);
    exit;
}

foreach ($items as $item) {
    if (!isset($item['id']) || !isset($item['quantity']) || !isset($item['price'])) {
        echo json_encode(['success' => false, 'error' => 'Invalid item data']);
        exit;
    }
}

// Recompute subtotal from items server-side, then apply discount and total
$computedSubtotal = 0;
foreach ($items as $item) {
    $computedSubtotal += (float)$item['price'] * (int)$item['quantity'];
}
if ($computedSubtotal > 0) {
    $subtotal = $computedSubtotal;
}

// Look up the admin-configured Senior/PWD discount rates (default 20% each
// if not yet set, matching the legally mandated rate under RA 9994 / RA 10754).
$pdo = getDBConnection();
$discountRate = 0.20;
if ($discountType !== 'none') {
    $rateColumn = $discountType === 'senior' ? 'senior_discount_rate' : 'pwd_discount_rate';
    try {
        $stmt = $pdo->query("SELECT $rateColumn FROM settings WHERE id = 1");
        $rateRow = $stmt->fetch();
        if ($rateRow && $rateRow[$rateColumn] !== null && $rateRow[$rateColumn] !== '') {
            $discountRate = ((float)$rateRow[$rateColumn]) / 100;
        }
    } catch (PDOException $e) {
        // Column may not exist yet on an un-migrated database - fall back to 20%
    }
}

$discountAmount = ($discountType !== 'none') ? round($subtotal * $discountRate, 2) : 0;
$total = $subtotal - $discountAmount + $takeoutFee;
if ($total < 0) {
    $total = 0;
}

// For GCash, the full total is considered paid with no change
if ($paymentMethod === 'gcash') {
    $paymentAmount = $total;
    $changeAmount = 0;
} elseif ($paymentAmount < $total) {
    echo json_encode(['success' => false, 'error' => 'Insufficient payment amount.']);
    exit;
}

// Save the captured Senior/PWD ID photo (if any) to disk before we touch the DB,
// so a failed save doesn't roll back an otherwise-valid order.
$discountIdImageFilename = null;
if ($discountType !== 'none' && !empty($discountIdImageData) && strpos($discountIdImageData, 'data:image') === 0) {
    if (preg_match('/^data:image\/(png|jpe?g|webp);base64,(.+)$/', $discountIdImageData, $matches)) {
        $ext = $matches[1] === 'jpg' ? 'jpeg' : $matches[1];
        $binary = base64_decode($matches[2]);
        if ($binary !== false && strlen($binary) <= 5 * 1024 * 1024) { // 5MB safety cap
            $uploadDir = '../../assets/uploads/discount_ids/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            $discountIdImageFilename = 'id_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            file_put_contents($uploadDir . $discountIdImageFilename, $binary);
        }
    }
}

try {
    // Start transaction with a shorter timeout
    $pdo->exec("SET SESSION innodb_lock_wait_timeout = 5");
    $pdo->beginTransaction();

    // Generate order number
    $orderNumber = generateOrderNumber();

    // Table number is optional but captured when provided (dine-in orders)
    $tableNumber = isset($_POST['table_number']) && trim($_POST['table_number']) !== ''
        ? trim($_POST['table_number'])
        : null;

    // Insert order. Orders start as 'pending' with kitchen_status 'pending' so they
    // actually flow through the kitchen queue instead of being marked done on arrival.
    // The order is only closed out as 'completed' once the kitchen marks it 'served'
    // (see modules/api/update_order_status.php).
    $stmt = $pdo->prepare("
        INSERT INTO orders (
            order_number, cashier_id, order_type, table_number, 
            customer_name, subtotal, tax, takeout_fee, discount, 
            discount_type, discount_id_number, discount_id_image,
            total, payment_method, payment_amount, change_amount, status, kitchen_status
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'pending'
        )
    ");
    
    $stmt->execute([
        $orderNumber,
        $_SESSION['user_id'],
        $orderType,
        $tableNumber,
        null,
        $subtotal,
        0,
        $takeoutFee,
        $discountAmount,
        $discountType,
        $discountIdNumber,
        $discountIdImageFilename,
        $total,
        $paymentMethod,
        $paymentAmount,
        $changeAmount
    ]);
    
    $orderId = (int)$pdo->lastInsertId();

    // Insert order items and update stock
    foreach ($items as $item) {
        // Insert order item
        $stmt = $pdo->prepare("
            INSERT INTO order_items (order_id, menu_item_id, quantity, price, subtotal)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $orderId,
            $item['id'],
            $item['quantity'],
            $item['price'],
            $item['price'] * $item['quantity']
        ]);
        
        // Update stock with lock
        $stmt = $pdo->prepare("
            UPDATE menu_items 
            SET stock = stock - ?,
                status = CASE 
                    WHEN stock - ? <= 0 THEN 'out_of_stock'
                    WHEN stock - ? <= 10 THEN 'low_stock'
                    ELSE 'available'
                END
            WHERE id = ? AND stock >= ?
        ");
        $stmt->execute([
            $item['quantity'], 
            $item['quantity'], 
            $item['quantity'], 
            $item['id'],
            $item['quantity']
        ]);
        
        // Check if stock was updated
        if ($stmt->rowCount() == 0) {
            throw new Exception("Not enough stock for item ID: {$item['id']}");
        }
    }

    // Insert payment
    $stmt = $pdo->prepare("
        INSERT INTO payments (order_id, amount, payment_method, reference_number, status)
        VALUES (?, ?, ?, ?, 'completed')
    ");
    $stmt->execute([$orderId, $paymentAmount, $paymentMethod, $referenceNumber]);

    // Log activity
    $stmt = $pdo->prepare("
        INSERT INTO activity_logs (user_id, action, details)
        VALUES (?, 'order_completed', ?)
    ");
    $logDetails = "Order #$orderNumber - Total: " . formatCurrency($total) . " - Payment: " . strtoupper($paymentMethod);
    if ($discountType !== 'none') {
        $logDetails .= " - Discount: " . strtoupper($discountType) . " (ID: $discountIdNumber)";
    }
    $stmt->execute([
        $_SESSION['user_id'],
        $logDetails
    ]);

    // Commit transaction
    $pdo->commit();

    // Clear session cart
    $_SESSION['pos_cart'] = [];

    echo json_encode([
        'success' => true,
        'order_id' => $orderId,
        'order_number' => $orderNumber
    ]);

} catch (PDOException $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    if ($discountIdImageFilename && file_exists('../../assets/uploads/discount_ids/' . $discountIdImageFilename)) {
        unlink('../../assets/uploads/discount_ids/' . $discountIdImageFilename);
    }
    
    // Check if it's a lock timeout error
    if (strpos($e->getMessage(), 'Lock wait timeout') !== false) {
        echo json_encode([
            'success' => false, 
            'error' => 'Database is busy. Please try again in a moment.'
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'error' => 'Database error: ' . $e->getMessage()
        ]);
    }
} catch (Exception $e) {
    // Rollback on any other error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    if ($discountIdImageFilename && file_exists('../../assets/uploads/discount_ids/' . $discountIdImageFilename)) {
        unlink('../../assets/uploads/discount_ids/' . $discountIdImageFilename);
    }
    echo json_encode([
        'success' => false, 
        'error' => $e->getMessage()
    ]);
}
?>