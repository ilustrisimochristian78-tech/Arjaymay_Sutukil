<?php
// ======================================================
// LOGIN - Redirect to Role Selection
// ======================================================
require_once '../../config/database.php';

if (isLoggedIn()) {
    if (isAdmin()) {
        header('Location: ../admin/dashboard.php');
    } elseif (isCashier()) {
        header('Location: ../cashier/dashboard.php');
    }
    exit;
}

header('Location: ../../index.php');
exit;
?>