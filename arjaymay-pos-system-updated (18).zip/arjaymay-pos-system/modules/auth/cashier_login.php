<?php
// ======================================================
// CASHIER LOGIN - WITH LOGO & BACKGROUND
// ======================================================
require_once '../../config/database.php';

if (isLoggedIn() && isCashier()) {
    header('Location: ../cashier/dashboard.php');
    exit;
}

$error = '';

// Get site settings
$settings = getSiteSettings();
$siteLogo = getSiteLogo();
$siteName = $settings['site_name'] ?? 'Arjaymay Sutukil';
$favicon = getSiteFavicon();
$backgroundImage = getBackgroundImage();

// Check if is_first_login column exists
$pdo = getDBConnection();
$columnExists = false;
try {
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'is_first_login'");
    $columnExists = $stmt->rowCount() > 0;
} catch (PDOException $e) {
    $columnExists = false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        try {
            if ($columnExists) {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role = 'cashier' AND status = 'active'");
            } else {
                $stmt = $pdo->prepare("SELECT id, username, password, full_name, role FROM users WHERE username = ? AND role = 'cashier' AND status = 'active'");
            }
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['is_first_login'] = $columnExists ? ($user['is_first_login'] ?? false) : false;
                
                $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'cashier_login', ?)");
                $stmt->execute([$user['id'], "Cashier {$user['full_name']} logged in"]);
                
                header('Location: ../cashier/dashboard.php');
                exit;
            } else {
                $error = 'Invalid username or password. Please try again.';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $siteName; ?> - Cashier Login</title>
    <?php if ($favicon): ?>
    <link rel="icon" href="<?php echo $favicon; ?>">
    <?php endif; ?>
    <?php include __DIR__ . '/../../includes/asset_links.php'; ?>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: linear-gradient(135deg, #1a3d1b, #2c5f2d);
            background-size: cover;
            background-position: center;
            position: relative;
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.4);
            z-index: 0;
        }
        <?php if ($backgroundImage): ?>
        body {
            background-image: url('<?php echo $backgroundImage; ?>');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        <?php endif; ?>
        .login-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            padding: 40px 36px;
            position: relative;
            z-index: 1;
        }
        .login-header { text-align: center; margin-bottom: 28px; }
        .login-header .logo-icon { margin-bottom: 12px; }
        .login-header .logo-icon img { max-height: 80px; max-width: 200px; object-fit: contain; }
        .login-header .logo-icon i { font-size: 2.5rem; color: #2c5f2d; }
        .login-header h1 { font-size: 1.3rem; color: #2d3436; margin-bottom: 4px; }
        .login-header p { color: #636e72; font-size: 0.9rem; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.85rem; font-weight: 500; color: #2d3436; margin-bottom: 4px; }
        .form-group input {
            width: 100%; padding: 10px 14px; border: 2px solid #e0e0e0; border-radius: 8px;
            font-family: 'Poppins', sans-serif; font-size: 0.95rem; transition: all 0.3s ease;
        }
        .form-group input:focus {
            border-color: #2c5f2d; outline: none; box-shadow: 0 0 0 3px rgba(44,95,45,0.1);
        }
        
        .password-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }
        .password-wrapper input {
            padding-right: 45px;
            width: 100%;
        }
        .password-toggle {
            position: absolute;
            right: 12px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1.1rem;
            color: #636e72;
            padding: 4px 8px;
            transition: color 0.3s ease;
        }
        .password-toggle:hover {
            color: #2c5f2d;
        }
        .password-toggle .fa-eye-slash {
            display: none;
        }
        .password-toggle.show .fa-eye {
            display: none;
        }
        .password-toggle.show .fa-eye-slash {
            display: inline;
        }
        
        .btn-primary {
            width: 100%; padding: 12px; background: #2c5f2d; color: #fff; border: none;
            border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer;
            transition: all 0.3s ease; font-family: 'Poppins', sans-serif;
        }
        .btn-primary:hover { background: #1a3d1b; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(44,95,45,0.3); }
        .alert-error {
            background: #f8d7da; color: #721c24; padding: 10px 14px; border-radius: 8px;
            font-size: 0.85rem; margin-bottom: 16px; border: 1px solid #f5c6cb;
        }
        .login-footer-links { text-align: center; margin-top: 16px; }
        .back-link {
            color: #636e72; text-decoration: none; font-size: 0.85rem; transition: all 0.3s ease;
            display: inline-block;
        }
        .back-link:hover { color: #2c5f2d; }
        .info-box {
            background: #d1ecf1; color: #0c5460; padding: 10px 14px; border-radius: 8px;
            font-size: 0.8rem; margin-top: 12px; border: 1px solid #bee5eb;
        }
        .info-box i { margin-right: 6px; }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo-icon">
                <?php if ($siteLogo): ?>
                    <img src="<?php echo $siteLogo; ?>" alt="<?php echo $siteName; ?>">
                <?php else: ?>
                    <i class="fas fa-user-tie"></i>
                <?php endif; ?>
            </div>
            <h1>Cashier Login</h1>
            <p>Enter your cashier credentials to continue</p>
        </div>
        
        <?php if ($error): ?>
        <div class="alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username"><i class="fas fa-user"></i> Username</label>
                <input type="text" id="username" name="username" placeholder="Enter cashier username" required autofocus>
            </div>
            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Password</label>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password" placeholder="Enter password" required>
                    <button type="button" class="password-toggle" onclick="togglePassword('password', this)">
                        <i class="fas fa-eye"></i>
                        <i class="fas fa-eye-slash"></i>
                    </button>
                </div>
            </div>
            <button type="submit" class="btn-primary"><i class="fas fa-sign-in-alt"></i> Login as Cashier</button>
        </form>
        
        <div class="info-box">
            <i class="fas fa-info-circle"></i> Cashier accounts must be created by an administrator.
        </div>
        
        <div class="login-footer-links">
            <a href="../../index.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Role Selection</a>
        </div>
    </div>
    
    <script>
        function togglePassword(inputId, button) {
            const input = document.getElementById(inputId);
            if (input.type === 'password') {
                input.type = 'text';
                button.classList.add('show');
            } else {
                input.type = 'password';
                button.classList.remove('show');
            }
        }
    </script>
</body>
</html>