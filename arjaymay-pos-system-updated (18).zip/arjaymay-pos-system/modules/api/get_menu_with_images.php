<?php
// ======================================================
// GET MENU (API) - WITH IMAGES
// ======================================================
require_once '../../config/database.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

$categoryId = isset($_GET['category_id']) ? (int)$_GET['category_id'] : 0;

try {
    $pdo = getDBConnection();

    if ($categoryId > 0) {
        $stmt = $pdo->prepare("
            SELECT id, name, price, stock, image, status
            FROM menu_items
            WHERE category_id = ?
            ORDER BY name
        ");
        $stmt->execute([$categoryId]);
    } else {
        $stmt = $pdo->query("
            SELECT id, name, price, stock, image, status
            FROM menu_items
            ORDER BY name
        ");
    }

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $items = [];
    foreach ($rows as $row) {
        $items[] = [
            'id' => (int)$row['id'],
            'name' => $row['name'],
            'price' => (float)$row['price'],
            'stock' => (int)$row['stock'],
            'image' => $row['image'] ?? '',
        ];
    }

    echo json_encode(['success' => true, 'items' => $items]);

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>
