// ======================================================
// ARJAYMAY SUTUKIL POS - Custom JavaScript
// Pure vanilla JS - no jQuery, no CDN, no external
// dependency of any kind. Everything here works with
// zero internet connection, all the time.
// ======================================================

// ------------------------------------------------------
// Small inline-SVG icon set (used instead of Font Awesome
// glyphs for anything drawn dynamically here) so nothing
// in this file ever depends on a webfont finishing a
// network download.
// ------------------------------------------------------
var POS_ICONS = {
    receipt: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2h12v19l-3-2-3 2-3-2-3 2V2z"></path><line x1="9" y1="7" x2="15" y2="7"></line><line x1="9" y1="11" x2="15" y2="11"></line></svg>',
    warning: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
    check: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>'
};

// Auto-hide alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        document.querySelectorAll('.alert').forEach(function(el) {
            el.style.transition = 'opacity 0.4s ease';
            el.style.opacity = '0';
            setTimeout(function() { el.style.display = 'none'; }, 400);
        });
    }, 5000);
});

// Handle enter key for forms (submits the closest form when
// Enter is pressed inside a text input)
document.addEventListener('keypress', function(e) {
    if (e.key === 'Enter' && e.target.tagName === 'INPUT') {
        var form = e.target.closest('form');
        if (form) form.submit();
    }
});

// Confirm delete actions
function confirmDelete(message) {
    return confirm(message || 'Are you sure you want to delete this item?');
}

// Format currency
function formatCurrency(amount) {
    return '\u20b1' + parseFloat(amount || 0).toFixed(2);
}

// Get current date for reports
function getToday() {
    return new Date().toISOString().split('T')[0];
}

// Print receipt - always confirm first
function printReceipt(orderId) {
    if (!confirm('Print this receipt?')) {
        return;
    }
    window.open(SITE_URL + 'modules/cashier/receipt.php?order_id=' + orderId, '_blank');
}

// Check if mobile
function isMobile() {
    return window.innerWidth <= 768;
}

// Toggle sidebar on mobile
function toggleSidebar() {
    var sidebar = document.getElementById('appSidebar');
    var overlay = document.getElementById('sidebarOverlay');
    if (sidebar) sidebar.classList.toggle('show');
    if (overlay) overlay.classList.toggle('show');
}

// ======================================================
// TOAST NOTIFICATIONS (offline-safe, no library)
// ======================================================
function showPosToast(message, type) {
    type = type || 'info';
    var container = document.getElementById('posToastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'posToastContainer';
        container.className = 'pos-toast-container';
        document.body.appendChild(container);
    }
    var toast = document.createElement('div');
    toast.className = 'pos-toast pos-toast-' + type;
    toast.innerHTML = '<span class="pos-toast-icon">' + POS_ICONS.check + '</span><span class="pos-toast-msg"></span>';
    toast.querySelector('.pos-toast-msg').textContent = message;
    container.appendChild(toast);
    requestAnimationFrame(function() { toast.classList.add('show'); });
    setTimeout(function() {
        toast.classList.remove('show');
        setTimeout(function() { toast.remove(); }, 300);
    }, 4500);
}

// A tiny, dependency-free "ding" sound generated on the fly
// with the Web Audio API - works fully offline (no mp3 file
// to fetch), degrades silently on old browsers.
function playNotifSound() {
    try {
        var Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return;
        var ctx = new Ctx();
        var osc = ctx.createOscillator();
        var gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.setValueAtTime(1180, ctx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
    } catch (e) { /* silent fail - sound is a nice-to-have */ }
}

// ======================================================
// NOTIFICATION BELL (admin only - element only exists on
// admin pages, so these just no-op elsewhere).
// Pure fetch() + vanilla DOM - no jQuery, no CDN icon font
// required to render or function. Same-origin request only,
// so this always works as long as the local server/XAMPP is
// running, with or without actual internet access.
// ======================================================
var posSeenOrderIds = null; // null = not initialized yet (first load, don't alert)

function loadNotifications() {
    var badge = document.getElementById('notifBadge');
    var body = document.getElementById('notifDropdownBody');
    if (!badge) return;

    fetch(SITE_URL + 'modules/api/get_notifications.php', { credentials: 'same-origin' })
        .then(function(res) {
            if (!res.ok) throw new Error('bad response');
            return res.json();
        })
        .then(function(data) {
            if (!data.success) throw new Error('not successful');

            // ---- detect brand-new orders since the last check ----
            var currentIds = data.pending_orders.map(function(o) { return o.id; });
            if (posSeenOrderIds !== null) {
                var newOnes = data.pending_orders.filter(function(o) {
                    return posSeenOrderIds.indexOf(o.id) === -1;
                });
                if (newOnes.length > 0) {
                    playNotifSound();
                    newOnes.forEach(function(o) {
                        showPosToast('New order #' + o.order_number + ' just came in (\u20b1' + parseFloat(o.total).toFixed(2) + ')', 'new-order');
                    });
                    var bellWrap = document.querySelector('.notif-bell-wrap');
                    if (bellWrap) {
                        bellWrap.classList.add('notif-bell-shake');
                        setTimeout(function() { bellWrap.classList.remove('notif-bell-shake'); }, 800);
                    }
                }
            }
            posSeenOrderIds = currentIds;

            if (data.total_count > 0) {
                badge.textContent = data.total_count > 99 ? '99+' : data.total_count;
                badge.style.display = '';
            } else {
                badge.style.display = 'none';
            }

            var html = '';
            if (data.pending_count > 0) {
                html += '<div class="notif-section-label">New Orders (' + data.pending_count + ')</div>';
                data.pending_orders.forEach(function(o) {
                    html += '<a class="notif-item" href="' + SITE_URL + 'modules/cashier/kitchen_display.php">' +
                        '<span class="notif-ico" style="color:#3498db;">' + POS_ICONS.receipt + '</span>' +
                        '<div><div class="notif-title">Order #' + o.order_number + '</div>' +
                        '<div class="notif-sub">' + o.order_type.replace('_', ' ') + ' &middot; \u20b1' + parseFloat(o.total).toFixed(2) + '</div></div></a>';
                });
            }
            if (data.low_stock_count > 0) {
                html += '<div class="notif-section-label">Low / Out of Stock (' + data.low_stock_count + ')</div>';
                data.low_stock.forEach(function(item) {
                    var isOut = item.stock <= 0;
                    html += '<a class="notif-item" href="' + SITE_URL + 'modules/admin/view_stocks.php">' +
                        '<span class="notif-ico" style="color:' + (isOut ? '#e74c3c' : '#f5a623') + ';">' + POS_ICONS.warning + '</span>' +
                        '<div><div class="notif-title">' + item.name + '</div>' +
                        '<div class="notif-sub">' + (isOut ? 'Out of stock' : 'Low stock: ' + item.stock + ' left') + '</div></div></a>';
                });
            }
            if (html === '') {
                html = '<div class="notif-empty"><span style="display:block; margin:0 auto 6px; width:24px;">' + POS_ICONS.check + '</span>All caught up</div>';
            }
            body.innerHTML = html;
        })
        .catch(function() {
            body.innerHTML = '<div class="notif-empty">Could not load notifications</div>';
        });
}

// ======================================================
// INITIALIZATION
// ======================================================
document.addEventListener('DOMContentLoaded', function() {
    // Tooltips (native title attribute, no plugin needed)
    document.querySelectorAll('[data-tooltip]').forEach(function(el) {
        el.setAttribute('title', el.getAttribute('data-tooltip'));
    });

    // Close modals with ESC key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.show').forEach(function(el) {
                el.classList.remove('show');
            });
        }
    });

    // Sidebar toggle (mobile)
    var sidebarToggle = document.getElementById('sidebarToggle');
    var sidebarOverlay = document.getElementById('sidebarOverlay');
    if (sidebarToggle) sidebarToggle.addEventListener('click', toggleSidebar);
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', toggleSidebar);

    // Notification bell
    var notifBell = document.getElementById('notifBell');
    var notifDropdown = document.getElementById('notifDropdown');
    if (notifBell && notifDropdown) {
        notifBell.addEventListener('click', function(e) {
            e.stopPropagation();
            notifDropdown.classList.toggle('show');
        });
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.notif-bell-wrap')) {
                notifDropdown.classList.remove('show');
            }
        });
    }
    if (document.getElementById('notifBadge')) {
        loadNotifications();
        setInterval(loadNotifications, 15000); // refresh every 15s
    }
});

// ======================================================
// SITE_URL DEFINITION
// ======================================================
if (typeof SITE_URL === 'undefined') {
    var SITE_URL = 'http://localhost/arjaymay-pos-system/';
}
