<?php
// ======================================================
// BACKUP & RESTORE SYSTEM (Admin Only)
// ======================================================
require_once '../../config/database.php';
requireAdmin();

$pdo = getDBConnection();
$message = '';
$error = '';
$backupFiles = [];

// Get all backup files
$backupDir = '../../assets/backups/';
if (!file_exists($backupDir)) {
    mkdir($backupDir, 0777, true);
}

// Scan backup directory
$files = scandir($backupDir);
foreach ($files as $file) {
    if ($file !== '.' && $file !== '..' && pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
        $filePath = $backupDir . $file;
        $backupFiles[] = [
            'name' => $file,
            'size' => filesize($filePath),
            'modified' => filemtime($filePath),
            'path' => $filePath
        ];
    }
}

// Sort by modified date (newest first)
usort($backupFiles, function($a, $b) {
    return $b['modified'] - $a['modified'];
});

// Handle Create Backup
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'create_backup') {
        $backupName = sanitize($_POST['backup_name'] ?? '');
        if (empty($backupName)) {
            $backupName = 'backup_' . date('Y-m-d_H-i-s');
        }
        
        // Sanitize filename
        $backupName = preg_replace('/[^a-zA-Z0-9_-]/', '', $backupName);
        $filename = $backupName . '.sql';
        $filepath = $backupDir . $filename;
        
        try {
            // Get all tables
            $stmt = $pdo->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $sql = "-- ======================================================\n";
            $sql .= "-- ARJAYMAY SUTUKIL POS - Database Backup\n";
            $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
            $sql .= "-- ======================================================\n\n";
            
            // Add database creation
            $sql .= "CREATE DATABASE IF NOT EXISTS `arjaymay_pos`;\n";
            $sql .= "USE `arjaymay_pos`;\n\n";
            
            foreach ($tables as $table) {
                // Get create table statement
                $stmt = $pdo->prepare("SHOW CREATE TABLE `$table`");
                $stmt->execute();
                $row = $stmt->fetch();
                $createTable = $row['Create Table'];
                
                $sql .= "-- ======================================================\n";
                $sql .= "-- Table: `$table`\n";
                $sql .= "-- ======================================================\n";
                $sql .= "DROP TABLE IF EXISTS `$table`;\n";
                $sql .= $createTable . ";\n\n";
                
                // Get data
                $stmt = $pdo->query("SELECT * FROM `$table`");
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (!empty($rows)) {
                    $columns = array_keys($rows[0]);
                    $columnList = '`' . implode('`, `', $columns) . '`';
                    $placeholders = implode(',', array_fill(0, count($columns), '?'));
                    
                    $sql .= "-- Data for `$table`\n";
                    $sql .= "INSERT INTO `$table` ($columnList) VALUES\n";
                    
                    $values = [];
                    foreach ($rows as $index => $row) {
                        $rowValues = array_map(function($value) use ($pdo) {
                            if ($value === null) {
                                return 'NULL';
                            }
                            return $pdo->quote($value);
                        }, array_values($row));
                        
                        $values[] = "(" . implode(", ", $rowValues) . ")";
                    }
                    $sql .= implode(",\n", $values) . ";\n\n";
                }
            }
            
            // Write to file
            if (file_put_contents($filepath, $sql)) {
                $message = "Backup created successfully: " . $filename;
                // Log activity
                $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'backup_created', ?)");
                $stmt->execute([$_SESSION['user_id'], "Created backup: $filename"]);
            } else {
                $error = "Failed to create backup file.";
            }
            
            // Refresh backup list
            $files = scandir($backupDir);
            $backupFiles = [];
            foreach ($files as $file) {
                if ($file !== '.' && $file !== '..' && pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
                    $filePath = $backupDir . $file;
                    $backupFiles[] = [
                        'name' => $file,
                        'size' => filesize($filePath),
                        'modified' => filemtime($filePath),
                        'path' => $filePath
                    ];
                }
            }
            usort($backupFiles, function($a, $b) {
                return $b['modified'] - $a['modified'];
            });
            
        } catch (Exception $e) {
            $error = "Backup failed: " . $e->getMessage();
        }
    }
    
    // Handle Download Backup
    if ($_POST['action'] === 'download_backup' && isset($_POST['filename'])) {
        $filename = sanitize($_POST['filename']);
        $filepath = $backupDir . $filename;
        
        if (file_exists($filepath)) {
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);
            exit;
        } else {
            $error = "Backup file not found.";
        }
    }
    
    // Handle Delete Backup
    if ($_POST['action'] === 'delete_backup' && isset($_POST['filename'])) {
        $filename = sanitize($_POST['filename']);
        $filepath = $backupDir . $filename;
        
        if (file_exists($filepath) && unlink($filepath)) {
            $message = "Backup deleted successfully: " . $filename;
            // Refresh backup list
            $files = scandir($backupDir);
            $backupFiles = [];
            foreach ($files as $file) {
                if ($file !== '.' && $file !== '..' && pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
                    $filePath = $backupDir . $file;
                    $backupFiles[] = [
                        'name' => $file,
                        'size' => filesize($filePath),
                        'modified' => filemtime($filePath),
                        'path' => $filePath
                    ];
                }
            }
            usort($backupFiles, function($a, $b) {
                return $b['modified'] - $a['modified'];
            });
        } else {
            $error = "Failed to delete backup file.";
        }
    }
    
    // Handle Restore Backup
    if ($_POST['action'] === 'restore_backup' && isset($_POST['filename'])) {
        $filename = sanitize($_POST['filename']);
        $filepath = $backupDir . $filename;
        
        if (!file_exists($filepath)) {
            $error = "Backup file not found.";
        } else {
            try {
                $sql = file_get_contents($filepath);
                
                // Split SQL by semicolon
                $queries = explode(";\n", $sql);
                
                $pdo->beginTransaction();
                $queryCount = 0;
                
                foreach ($queries as $query) {
                    $query = trim($query);
                    if (!empty($query) && !str_starts_with($query, '--')) {
                        $pdo->exec($query);
                        $queryCount++;
                    }
                }
                
                $pdo->commit();
                $message = "Backup restored successfully! $queryCount queries executed.";
                
                // Log activity
                $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'backup_restored', ?)");
                $stmt->execute([$_SESSION['user_id'], "Restored backup: $filename"]);
                
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Restore failed: " . $e->getMessage();
            }
        }
    }
}

// Format file size
function formatFileSize(int|float $bytes): string {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' B';
    }
}

include '../../includes/header.php';
?>

<style>
.backup-container {
    max-width: 1000px;
    margin: 0 auto;
}
.backup-actions {
    display: flex;
    gap: 12px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}
.backup-actions .btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
}
.btn-success {
    background: #27ae60;
    color: #fff;
}
.btn-success:hover {
    background: #1e8449;
}
.btn-info {
    background: #3498db;
    color: #fff;
}
.btn-info:hover {
    background: #2980b9;
}
.btn-danger {
    background: #e74c3c;
    color: #fff;
}
.btn-danger:hover {
    background: #c0392b;
}
.backup-table {
    width: 100%;
    border-collapse: collapse;
}
.backup-table th {
    background: #f8f9fa;
    padding: 10px 12px;
    text-align: left;
    font-weight: 600;
    border-bottom: 2px solid #e0e0e0;
}
.backup-table td {
    padding: 10px 12px;
    border-bottom: 1px solid #f0f0f0;
}
.backup-table tr:hover {
    background: #f8f9fa;
}
.backup-table .file-size {
    font-size: 0.85rem;
    color: var(--text-light);
}
.backup-table .file-date {
    font-size: 0.85rem;
    color: var(--text-light);
}
.backup-table .actions {
    display: flex;
    gap: 6px;
}
.btn-sm {
    padding: 4px 12px;
    font-size: 0.75rem;
}
.empty-backups {
    text-align: center;
    padding: 40px;
    color: var(--text-light);
}
.empty-backups i {
    font-size: 2.5rem;
    display: block;
    margin-bottom: 10px;
    color: #ddd;
}
.alert-warning {
    background: #fff3cd;
    color: #856404;
    padding: 12px 18px;
    border-radius: 8px;
    border: 1px solid #ffc107;
    margin-bottom: 16px;
}
.alert-warning i {
    margin-right: 8px;
}
</style>

<div class="backup-container">
    <div class="page-header">
        <h2><i class="fas fa-database"></i> Backup & Restore</h2>
        <p>Create, download, and restore database backups</p>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
    <?php endif; ?>

    <div class="alert-warning">
        <i class="fas fa-exclamation-triangle"></i>
        <strong>Important:</strong> Restoring a backup will overwrite all current data. Please make sure you have a recent backup before restoring.
    </div>

    <!-- Backup Actions -->
    <div class="backup-actions">
        <form method="POST" action="" style="display: inline;">
            <input type="hidden" name="action" value="create_backup">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-plus-circle"></i> Create Backup
            </button>
        </form>
        <form method="POST" action="" style="display: inline;">
            <input type="hidden" name="action" value="create_backup">
            <input type="hidden" name="backup_name" value="auto_backup_<?php echo date('Y-m-d_H-i-s'); ?>">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-clock"></i> Auto Backup (with timestamp)
            </button>
        </form>
    </div>

    <!-- Backup List -->
    <div class="table-container">
        <div class="table-header">
            <h3><i class="fas fa-list"></i> Available Backups</h3>
            <span class="badge badge-primary"><?php echo count($backupFiles); ?> files</span>
        </div>
        <?php if (empty($backupFiles)): ?>
        <div class="empty-backups">
            <i class="fas fa-database"></i>
            <p>No backups found. Create your first backup!</p>
        </div>
        <?php else: ?>
        <table class="backup-table">
            <thead>
                <tr>
                    <th>Filename</th>
                    <th>Size</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($backupFiles as $backup): ?>
                <tr>
                    <td><strong><?php echo sanitize($backup['name']); ?></strong></td>
                    <td class="file-size"><?php echo formatFileSize($backup['size']); ?></td>
                    <td class="file-date"><?php echo date('M d, Y h:i A', $backup['modified']); ?></td>
                    <td class="actions">
                        <!-- Download -->
                        <form method="POST" action="" style="display: inline;">
                            <input type="hidden" name="action" value="download_backup">
                            <input type="hidden" name="filename" value="<?php echo sanitize($backup['name']); ?>">
                            <button type="submit" class="btn btn-info btn-sm" title="Download">
                                <i class="fas fa-download"></i>
                            </button>
                        </form>
                        <!-- Restore -->
                        <form method="POST" action="" style="display: inline;" onsubmit="return confirm('⚠️ WARNING: This will overwrite all current data!\nAre you sure you want to restore this backup?')">
                            <input type="hidden" name="action" value="restore_backup">
                            <input type="hidden" name="filename" value="<?php echo sanitize($backup['name']); ?>">
                            <button type="submit" class="btn btn-warning btn-sm" title="Restore">
                                <i class="fas fa-undo"></i>
                            </button>
                        </form>
                        <!-- Delete -->
                        <form method="POST" action="" style="display: inline;" onsubmit="return confirm('Delete this backup file?')">
                            <input type="hidden" name="action" value="delete_backup">
                            <input type="hidden" name="filename" value="<?php echo sanitize($backup['name']); ?>">
                            <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>