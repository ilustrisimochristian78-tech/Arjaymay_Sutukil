<?php
// ======================================================
// TRANSACTION HISTORY (Admin Only) - FIXED RECEIPT LAYOUT
// ======================================================
require_once '../../config/database.php';
requireAdmin();

$pdo = getDBConnection();

$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-d', strtotime('-7 days'));
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : getCurrentDate();
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

$query = "SELECT o.*, u.full_name as cashier_name FROM orders o LEFT JOIN users u ON o.cashier_id = u.id WHERE DATE(o.created_at) BETWEEN ? AND ?";
$params = [$date_from, $date_to];

if (!empty($search)) {
    $query .= " AND (o.order_number LIKE ? OR u.full_name LIKE ? OR o.customer_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$query .= " ORDER BY o.created_at DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$transactions = $stmt->fetchAll();

$totalSales = 0; $totalOrders = 0; $dineInTotal = 0; $takeOutTotal = 0;
foreach ($transactions as $t) {
    $totalSales += $t['total'];
    $totalOrders++;
    if ($t['order_type'] == 'dine_in') { $dineInTotal += $t['total']; } 
    else { $takeOutTotal += $t['total']; }
}

include '../../includes/header.php';
?>

<style>
.receipt-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.6);
    z-index: 99999;
    align-items: center;
    justify-content: center;
}
.receipt-modal.show {
    display: flex;
}
.pos-spinner {
    width: 34px; height: 34px; margin: 0 auto 10px;
    border: 3px solid #e3e8e4; border-top-color: var(--primary, #2c5f2d);
    border-radius: 50%;
    animation: pos-spin 0.8s linear infinite;
}
@keyframes pos-spin { to { transform: rotate(360deg); } }
.receipt-modal-content {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    max-width: 400px;
    width: 95%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    animation: modalSlideIn 0.3s ease;
}
.receipt-modal-content .receipt-header {
    text-align: center;
    border-bottom: 2px dashed #ccc;
    padding-bottom: 12px;
    margin-bottom: 12px;
}
.receipt-modal-content .receipt-header .receipt-logo {
    max-height: 50px;
    max-width: 150px;
    object-fit: contain;
    margin-bottom: 6px;
    display: block;
    margin-left: auto;
    margin-right: auto;
}
.receipt-modal-content .receipt-header h3 {
    color: #2c5f2d;
    font-size: 1rem;
    margin: 0;
}
.receipt-modal-content .receipt-header p {
    font-size: 0.75rem;
    color: #666;
    margin: 2px 0 0;
}
.receipt-modal-content .receipt-row {
    display: flex;
    justify-content: space-between;
    font-size: 0.8rem;
    padding: 2px 0;
}
.receipt-modal-content .receipt-row.total {
    font-weight: 700;
    font-size: 0.95rem;
    border-top: 2px solid #333;
    padding-top: 6px;
    margin-top: 6px;
}
.receipt-modal-content .receipt-divider {
    border-top: 1px dashed #ccc;
    margin: 6px 0;
}
.receipt-modal-content .receipt-footer {
    text-align: center;
    margin-top: 12px;
    padding-top: 10px;
    border-top: 2px dashed #ccc;
    font-size: 0.75rem;
    color: #666;
}
.receipt-modal-content .receipt-footer strong {
    color: #2c5f2d;
}
.receipt-modal-content .item-row {
    display: flex;
    justify-content: space-between;
    font-size: 0.78rem;
    padding: 2px 0;
}
.receipt-modal-content .item-row .item-name {
    flex: 1;
}
.receipt-modal-content .item-row .item-qty {
    margin: 0 8px;
    color: #666;
}
.receipt-modal-content .item-row .item-amount {
    font-weight: 500;
}
.receipt-modal-close {
    float: right;
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #999;
}
.receipt-modal-close:hover {
    color: #333;
}
.receipt-modal-actions {
    display: flex;
    gap: 10px;
    margin-top: 12px;
    justify-content: center;
}
.receipt-modal-actions .btn {
    padding: 6px 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-family: 'Poppins', sans-serif;
    font-size: 0.8rem;
    font-weight: 500;
    transition: all 0.3s;
}
.receipt-modal-actions .btn-print {
    background: #2c5f2d;
    color: #fff;
}
.receipt-modal-actions .btn-print:hover {
    background: #1a3d1b;
}
.receipt-modal-actions .btn-close-modal {
    background: #e0e0e0;
    color: #333;
}
.receipt-modal-actions .btn-close-modal:hover {
    background: #d0d0d0;
}
@keyframes modalSlideIn {
    from { transform: translateY(-30px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
</style>

<div class="page-header">
    <h2><i class="fas fa-history"></i> Transaction History</h2>
    <p>View, search, and print all transactions</p>
</div>

<div style="display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; align-items: center;">
    <form method="GET" action="" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
        <div><label for="date_from">From:</label><input type="date" id="date_from" name="date_from" value="<?php echo $date_from; ?>"></div>
        <div><label for="date_to">To:</label><input type="date" id="date_to" name="date_to" value="<?php echo $date_to; ?>"></div>
        <div><input type="text" name="search" placeholder="Search orders..." value="<?php echo $search; ?>" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px;"></div>
        <button type="submit" class="btn btn-primary">Filter</button>
        <a href="transaction_history.php" class="btn btn-secondary">Reset</a>
    </form>
</div>

<div class="dashboard-stats" style="margin-bottom: 24px;">
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-receipt"></i></div>
        <div class="stat-info"><h3><?php echo $totalOrders; ?></h3><p>Total Transactions</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-money-bill-wave"></i></div>
        <div class="stat-info"><h3><?php echo formatCurrency($totalSales); ?></h3><p>Total Sales</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fas fa-chair"></i></div>
        <div class="stat-info"><h3><?php echo formatCurrency($dineInTotal); ?></h3><p>Dine In Sales</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon purple"><i class="fas fa-shopping-bag"></i></div>
        <div class="stat-info"><h3><?php echo formatCurrency($takeOutTotal); ?></h3><p>Take Out Sales</p></div>
    </div>
</div>

<div class="table-container">
    <div class="table-header">
        <h3><i class="fas fa-list"></i> Transactions</h3>
        <span class="badge badge-primary"><?php echo count($transactions); ?> records</span>
    </div>
    <div style="overflow-x: auto;">
        <table>
            <thead><tr>
                <th>Order #</th>
                <th>Cashier</th>
                <th>Type</th>
                <th>Items</th>
                <th>Total</th>
                <th>Payment</th>
                <th>Status</th>
                <th>Date/Time</th>
                <th>Actions</th>
            </tr></thead>
            <tbody>
                <?php if (empty($transactions)): ?>
                <tr><td colspan="9" style="text-align: center; padding: 30px;">No transactions found.</td></tr>
                <?php else: ?>
                <?php foreach ($transactions as $t): ?>
                <tr>
                    <td><strong><?php echo $t['order_number']; ?></strong></td>
                    <td><?php echo sanitize($t['cashier_name']); ?></td>
                    <td><span class="badge <?php echo $t['order_type'] == 'dine_in' ? 'badge-primary' : 'badge-warning'; ?>"><?php echo ucfirst(str_replace('_', ' ', $t['order_type'])); ?></span></td>
                    <td><?php $stmt2 = $pdo->prepare("SELECT SUM(quantity) as total_qty FROM order_items WHERE order_id = ?"); $stmt2->execute([$t['id']]); $items = $stmt2->fetch(); echo $items['total_qty'] . ' items'; ?></td>
                    <td><?php echo formatCurrency($t['total']); ?></td>
                    <td><span class="badge badge-success"><?php echo ucfirst($t['payment_method']); ?></span></td>
                    <td><span class="badge <?php echo $t['status'] == 'completed' ? 'badge-success' : 'badge-warning'; ?>"><?php echo ucfirst($t['status']); ?></span></td>
                    <td><?php echo date('M d, Y', strtotime($t['created_at'])); ?><br><small><?php echo date('h:i A', strtotime($t['created_at'])); ?></small></td>
                    <td>
                        <button class="btn btn-info btn-sm" onclick="viewReceipt(<?php echo $t['id']; ?>, '<?php echo $t['order_number']; ?>')" title="View Receipt">
                            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        </button>
                        <button class="btn btn-primary btn-sm" onclick="printReceipt(<?php echo $t['id']; ?>)" title="Print Receipt">
                            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Receipt Modal -->
<div class="receipt-modal" id="receiptModal" onclick="if(event.target===this) closeReceiptModal()">
    <div class="receipt-modal-content" id="receiptModalContent">
        <button class="receipt-modal-close" onclick="closeReceiptModal()">&times;</button>
        <div id="receiptContent">
            <div style="text-align:center; padding:20px; color:#999;">
                <div class="pos-spinner"></div>
                <p>Loading receipt...</p>
            </div>
        </div>
        <div class="receipt-modal-actions">
            <button class="btn btn-print" onclick="printModalReceipt()">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg> Print
            </button>
            <button class="btn btn-close-modal" onclick="closeReceiptModal()">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg> Close
            </button>
        </div>
    </div>
</div>

<script>
// ======================================================
// VIEW RECEIPT IN MODAL - WITH LOGO ONLY AT TOP
// ======================================================
function viewReceipt(orderId, orderNumber) {
    var modal = document.getElementById('receiptModal');
    var content = document.getElementById('receiptContent');
    
    content.innerHTML = `
        <div style="text-align:center; padding:20px; color:#999;">
            <div class="pos-spinner"></div>
            <p>Loading receipt...</p>
        </div>
    `;
    
    modal.classList.add('show');
    
    fetch('../../modules/cashier/get_receipt_data.php?order_id=' + encodeURIComponent(orderId), { credentials: 'same-origin' })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.success) {
                generateReceiptHTML(data);
            } else {
                content.innerHTML = `
                    <div style="text-align:center; padding:20px; color:#e74c3c;">
                        <p>${data.error || 'Failed to load receipt'}</p>
                    </div>
                `;
            }
        })
        .catch(function(error) {
            content.innerHTML = `
                <div style="text-align:center; padding:20px; color:#e74c3c;">
                    <p>Failed to load receipt: ${error}</p>
                </div>
            `;
        });
}

// ======================================================
// GENERATE RECEIPT HTML - LOGO ONLY AT TOP
// ======================================================
function generateReceiptHTML(data) {
    var itemsHTML = '';
    data.items.forEach(function(item) {
        itemsHTML += `
            <div class="item-row">
                <span class="item-name">${item.name}</span>
                <span class="item-qty">x${item.quantity}</span>
                <span class="item-amount">₱${parseFloat(item.subtotal).toFixed(2)}</span>
            </div>
        `;
    });
    
    var logoHTML = '';
    if (data.logo_url) {
        logoHTML = `<img src="${data.logo_url}" alt="${data.restaurant_name}" class="receipt-logo">`;
    }
    
    var html = `
        <div class="receipt-header">
            ${logoHTML}
            <h3>${data.restaurant_name || 'Arjaymay Sutukil'}</h3>
            <p>OFFICIAL RECEIPT</p>
        </div>
        <div class="receipt-row">
            <span><strong>Trans #</strong> ${data.order_number}</span>
            <span><strong>Cashier</strong> ${data.cashier_name}</span>
        </div>
        <div class="receipt-row">
            <span><strong>Date</strong> ${data.date}</span>
            <span><strong>Time</strong> ${data.time}</span>
        </div>
        <div class="receipt-row">
            <span><strong>Type</strong> ${data.order_type.toUpperCase()}</span>
        </div>
        <div class="receipt-divider"></div>
        <div style="font-weight:600; font-size:0.75rem; padding:4px 0;">
            <span>Item</span>
            <span style="float:right;">Qty Amount</span>
        </div>
        ${itemsHTML}
        <div class="receipt-divider"></div>
        <div class="receipt-row"><span>Subtotal</span><span>₱${parseFloat(data.subtotal).toFixed(2)}</span></div>
        ${(data.discount_type && data.discount_type !== 'none' && parseFloat(data.discount) > 0) ? `
        <div class="receipt-row"><span>${data.discount_type === 'senior' ? 'Senior Citizen Discount' : 'PWD Discount'} (${(parseFloat(data.subtotal) > 0 ? Math.round((parseFloat(data.discount) / parseFloat(data.subtotal)) * 10000) / 100 : 0)}%)</span><span>-₱${parseFloat(data.discount).toFixed(2)}</span></div>
        <div class="receipt-row"><span>ID Number</span><span>${data.discount_id_number || ''}</span></div>
        ${data.discount_id_image_url ? `
        <div style="text-align:center; margin: 8px 0;">
            <img src="${data.discount_id_image_url}" alt="Scanned ID" style="max-width:140px; max-height:90px; border-radius:6px; border:1px solid #ddd; cursor:pointer; object-fit:cover;" onclick="window.open('${data.discount_id_image_url}', '_blank')">
            <div style="font-size:0.65rem; color:#888;">Scanned ID (click to enlarge)</div>
        </div>
        ` : `
        <div style="font-size:0.7rem; color:#c62828; text-align:center; margin: 6px 0;">No ID photo on file</div>
        `}
        ` : ''}
        <div class="receipt-row total"><span>TOTAL</span><span>₱${parseFloat(data.total).toFixed(2)}</span></div>
        <div class="receipt-row"><span>Payment Method</span><span>${(data.payment_method || 'cash').toUpperCase()}</span></div>
        ${data.payment_method === 'gcash' ? `
        <div class="receipt-row"><span>Amount Paid</span><span>₱${parseFloat(data.payment_amount).toFixed(2)}</span></div>
        ` : `
        <div class="receipt-row"><span>Cash</span><span>₱${parseFloat(data.payment_amount).toFixed(2)}</span></div>
        <div class="receipt-row"><span>Change</span><span>₱${parseFloat(data.change_amount).toFixed(2)}</span></div>
        `}
        <div class="receipt-footer">
            <strong>THANK YOU! PLEASE COME AGAIN!</strong><br>
            <small>${data.restaurant_name} POS System v1.0</small>
        </div>
    `;
    
    document.getElementById('receiptContent').innerHTML = html;
}

// ======================================================
// CLOSE RECEIPT MODAL
// ======================================================
function closeReceiptModal() {
    document.getElementById('receiptModal').classList.remove('show');
}

// ======================================================
// PRINT RECEIPT FROM MODAL - LOGO ONLY AT TOP
// ======================================================
function printModalReceipt() {
    var content = document.getElementById('receiptContent').innerHTML;
    var printWindow = window.open('', '_blank', 'width=400,height=600');
    
    if (!printWindow) {
        alert('Please allow popups to print the receipt.');
        return;
    }
    
    var html = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Receipt</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: 'Courier New', monospace; padding: 20px; background: white; display: flex; justify-content: center; }
                .receipt-content { max-width: 350px; width: 100%; }
                .receipt-header { text-align: center; border-bottom: 2px dashed #ccc; padding-bottom: 12px; margin-bottom: 12px; }
                .receipt-header .receipt-logo { max-height: 50px; max-width: 150px; object-fit: contain; margin-bottom: 6px; display: block; margin-left: auto; margin-right: auto; }
                .receipt-header h3 { color: #2c5f2d; font-size: 1rem; margin: 0; }
                .receipt-header p { font-size: 0.75rem; color: #666; margin: 2px 0 0; }
                .receipt-row { display: flex; justify-content: space-between; font-size: 0.8rem; padding: 2px 0; }
                .receipt-row.total { font-weight: 700; font-size: 0.95rem; border-top: 2px solid #333; padding-top: 6px; margin-top: 6px; }
                .receipt-divider { border-top: 1px dashed #ccc; margin: 6px 0; }
                .receipt-footer { text-align: center; margin-top: 12px; padding-top: 10px; border-top: 2px dashed #ccc; font-size: 0.75rem; color: #666; }
                .receipt-footer strong { color: #2c5f2d; }
                .item-row { display: flex; justify-content: space-between; font-size: 0.78rem; padding: 2px 0; }
                .item-row .item-name { flex: 1; }
                .item-row .item-qty { margin: 0 8px; color: #666; }
                .item-row .item-amount { font-weight: 500; }
                @media print { body { padding: 0; } }
            </style>
        </head>
        <body>
            <div class="receipt-content">
                ${content}
            </div>
            <script>
                window.onload = function() {
                    setTimeout(function() { window.print(); }, 500);
                    setTimeout(function() { window.close(); }, 3000);
                };
            <\/script>
        </body>
        </html>
    `;
    
    printWindow.document.write(html);
    printWindow.document.close();
}

// ======================================================
// PRINT RECEIPT DIRECTLY - LOGO ONLY AT TOP
// ======================================================
function printReceipt(orderId) {
    var printWindow = window.open('../../modules/cashier/receipt.php?order_id=' + orderId, '_blank', 'width=400,height=600');
    
    if (!printWindow) {
        alert('Please allow popups to print the receipt.');
    }
}

// Close modal with ESC key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeReceiptModal();
    }
});
</script>

<?php include '../../includes/footer.php'; ?>