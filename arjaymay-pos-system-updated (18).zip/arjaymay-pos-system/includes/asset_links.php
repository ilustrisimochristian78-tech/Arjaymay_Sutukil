<?php
// ======================================================
// Self-hosted fonts & icons so the system works without
// internet. Run setup_offline_assets.php once (with this
// computer briefly online) to install the local copies.
// Automatically falls back to the CDN if they aren't
// installed yet - same pattern already used for jQuery.
// ======================================================
$vendorDir  = __DIR__ . '/../assets/js/vendor';
$localFonts = $vendorDir . '/fonts/poppins.css';
$localFA    = $vendorDir . '/fontawesome/css/all.min.css';
?>
<?php if (file_exists($localFonts)): ?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/js/vendor/fonts/poppins.css">
<?php else: ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<?php endif; ?>
<?php if (file_exists($localFA)): ?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/js/vendor/fontawesome/css/all.min.css">
<?php else: ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<?php endif; ?>
