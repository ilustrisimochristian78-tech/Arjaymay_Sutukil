<?php
// ======================================================
// CATEGORY MANAGEMENT (Admin Only)
// ======================================================
require_once '../../config/database.php';
requireAdmin();

$pdo = getDBConnection();
$message = '';
$error = '';

// Make sure the categories table has an "image" column. Older
// installs won't have this yet, so add it automatically the
// first time this page runs (same self-healing pattern used
// elsewhere in this app for is_first_login).
try {
    $colCheck = $pdo->query("SHOW COLUMNS FROM categories LIKE 'image'");
    if ($colCheck->rowCount() === 0) {
        $pdo->exec("ALTER TABLE categories ADD COLUMN image VARCHAR(255) NULL AFTER description");
    }
} catch (PDOException $e) {
    // If this fails, image upload below will simply be skipped for this request.
}

$categoryUploadDir = __DIR__ . '/../../assets/uploads/categories';
if (!is_dir($categoryUploadDir)) {
    mkdir($categoryUploadDir, 0755, true);
}

function handleCategoryImageUpload(string $uploadDir, ?string &$uploadError): ?string {
    if (empty($_FILES['image']['name']) || $_FILES['image']['error'] === UPLOAD_ERR_NO_FILE) {
        return null; // no file chosen - not an error, just nothing to do
    }
    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        $uploadError = 'Image upload failed. Please try again.';
        return null;
    }
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $mime = mime_content_type($_FILES['image']['tmp_name']);
    if (!isset($allowed[$mime])) {
        $uploadError = 'Please upload a JPG, PNG, WEBP, or GIF image.';
        return null;
    }
    if ($_FILES['image']['size'] > 3 * 1024 * 1024) {
        $uploadError = 'Image must be smaller than 3MB.';
        return null;
    }
    $filename = 'cat_' . uniqid() . '.' . $allowed[$mime];
    if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . '/' . $filename)) {
        $uploadError = 'Could not save the uploaded image.';
        return null;
    }
    return $filename;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        $name = sanitize($_POST['name'] ?? '');
        $description = sanitize($_POST['description'] ?? '');
        $sort_order = (int)($_POST['sort_order'] ?? 0);
        if (empty($name)) {
            $error = 'Category name is required.';
        } else {
            $uploadError = null;
            $imageFile = handleCategoryImageUpload($categoryUploadDir, $uploadError);
            if ($uploadError) {
                $error = $uploadError;
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO categories (name, description, sort_order, image) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$name, $description, $sort_order, $imageFile]);
                    $message = 'Category added successfully!';
                    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'add_category', ?)");
                    $stmt->execute([$_SESSION['user_id'], "Added category: $name"]);
                } catch (PDOException $e) {
                    $error = 'Error: ' . $e->getMessage();
                }
            }
        }
    }
    
    if ($_POST['action'] === 'edit') {
        $id = (int)($_POST['category_id'] ?? 0);
        $name = sanitize($_POST['name'] ?? '');
        $description = sanitize($_POST['description'] ?? '');
        $sort_order = (int)($_POST['sort_order'] ?? 0);
        $status = sanitize($_POST['status'] ?? 'active');
        if ($id > 0 && !empty($name)) {
            $uploadError = null;
            $imageFile = handleCategoryImageUpload($categoryUploadDir, $uploadError);
            if ($uploadError) {
                $error = $uploadError;
            } else {
                try {
                    if ($imageFile !== null) {
                        // A new image was uploaded - remove the old one and use the new filename.
                        $stmt = $pdo->prepare("SELECT image FROM categories WHERE id = ?");
                        $stmt->execute([$id]);
                        $oldImage = $stmt->fetchColumn();
                        if (!empty($oldImage) && file_exists($categoryUploadDir . '/' . $oldImage)) {
                            @unlink($categoryUploadDir . '/' . $oldImage);
                        }
                        $stmt = $pdo->prepare("UPDATE categories SET name = ?, description = ?, sort_order = ?, status = ?, image = ? WHERE id = ?");
                        $stmt->execute([$name, $description, $sort_order, $status, $imageFile, $id]);
                    } else {
                        // No new image chosen - keep whatever image (if any) is already saved.
                        $stmt = $pdo->prepare("UPDATE categories SET name = ?, description = ?, sort_order = ?, status = ? WHERE id = ?");
                        $stmt->execute([$name, $description, $sort_order, $status, $id]);
                    }
                    $message = 'Category updated successfully!';
                    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'edit_category', ?)");
                    $stmt->execute([$_SESSION['user_id'], "Updated category: $name"]);
                } catch (PDOException $e) {
                    $error = 'Error: ' . $e->getMessage();
                }
            }
        }
    }
    
    if ($_POST['action'] === 'delete') {
        $id = (int)($_POST['category_id'] ?? 0);
        if ($id > 0) {
            try {
                $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM menu_items WHERE category_id = ?");
                $stmt->execute([$id]);
                $count = $stmt->fetch()['count'];
                if ($count > 0) {
                    $error = 'Cannot delete category with existing menu items.';
                } else {
                    $stmt = $pdo->prepare("SELECT image FROM categories WHERE id = ?");
                    $stmt->execute([$id]);
                    $imgToDelete = $stmt->fetchColumn();
                    $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
                    $stmt->execute([$id]);
                    if (!empty($imgToDelete) && file_exists($categoryUploadDir . '/' . $imgToDelete)) {
                        @unlink($categoryUploadDir . '/' . $imgToDelete);
                    }
                    $message = 'Category deleted successfully!';
                }
            } catch (PDOException $e) {
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }
}

$categories = getAllCategories();
include '../../includes/header.php';
?>

<div class="page-header">
    <h2><i class="fas fa-tags"></i> Category Management</h2>
    <p>Manage food categories</p>
</div>

<?php if ($message): ?>
<div class="alert alert-success"><?php echo $message; ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 24px;">
    <div class="table-container">
        <div class="table-header"><h3><i class="fas fa-plus-circle"></i> Add Category</h3></div>
        <div style="padding: 20px;">
            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add">
                <div class="form-group">
                    <label for="name">Category Name *</label>
                    <input type="text" id="name" name="name" placeholder="Enter category name" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="2" placeholder="Enter description"></textarea>
                </div>
                <div class="form-group">
                    <label for="image">Category Picture</label>
                    <input type="file" id="image" name="image" accept="image/*">
                    <small>Shown as the category's icon/tile for cashiers. JPG, PNG, WEBP or GIF, max 3MB.</small>
                </div>
                <div class="form-group">
                    <label for="sort_order">Sort Order</label>
                    <input type="number" id="sort_order" name="sort_order" value="0" min="0">
                    <small>Lower numbers appear first</small>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;"><i class="fas fa-plus"></i> Add Category</button>
            </form>
        </div>
    </div>
    
    <div class="table-container">
        <div class="table-header">
            <h3><i class="fas fa-list"></i> Categories</h3>
            <span class="badge badge-primary"><?php echo count($categories); ?> categories</span>
        </div>
        <table>
            <thead><tr><th>Picture</th><th>ID</th><th>Name</th><th>Sort</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
                <?php if (empty($categories)): ?>
                <tr><td colspan="6" style="text-align: center; padding: 30px;">No categories found.</td></tr>
                <?php else: ?>
                <?php foreach ($categories as $cat): ?>
                <tr>
                    <td>
                        <?php if (!empty($cat['image']) && file_exists($categoryUploadDir . '/' . $cat['image'])): ?>
                            <img src="<?php echo SITE_URL; ?>assets/uploads/categories/<?php echo htmlspecialchars($cat['image']); ?>" alt="" style="width:40px;height:40px;object-fit:cover;border-radius:10px;">
                        <?php else: ?>
                            <span style="width:40px;height:40px;border-radius:10px;background:#f0f2f5;color:#bbb;display:inline-flex;align-items:center;justify-content:center;"><i class="fas fa-image"></i></span>
                        <?php endif; ?>
                    </td>
                    <td>#<?php echo $cat['id']; ?></td>
                    <td><strong><?php echo sanitize($cat['name']); ?></strong></td>
                    <td><?php echo $cat['sort_order']; ?></td>
                    <td><span class="badge <?php echo $cat['status'] == 'active' ? 'badge-success' : 'badge-danger'; ?>"><?php echo ucfirst($cat['status']); ?></span></td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="editCategory(<?php echo htmlspecialchars(json_encode($cat)); ?>)"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-danger btn-sm" onclick="deleteCategory(<?php echo $cat['id']; ?>, '<?php echo addslashes($cat['name']); ?>')"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-edit"></i> Edit Category</h3>
            <button class="modal-close" onclick="hideEditModal()">&times;</button>
        </div>
        <form method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="category_id" id="edit_category_id">
            <div class="form-group"><label for="edit_name">Category Name *</label><input type="text" id="edit_name" name="name" required></div>
            <div class="form-group"><label for="edit_description">Description</label><textarea id="edit_description" name="description" rows="2"></textarea></div>
            <div class="form-group">
                <label>Current Picture</label>
                <div id="edit_current_image_wrap" style="margin-bottom:8px;">
                    <img id="edit_current_image" src="" alt="" style="width:60px;height:60px;object-fit:cover;border-radius:10px;display:none;">
                    <span id="edit_no_image" style="color:var(--text-light); font-size:0.85rem;">No picture set yet</span>
                </div>
                <label for="edit_image">Replace Picture</label>
                <input type="file" id="edit_image" name="image" accept="image/*">
                <small>Leave empty to keep the current picture.</small>
            </div>
            <div class="form-group"><label for="edit_sort_order">Sort Order</label><input type="number" id="edit_sort_order" name="sort_order" min="0"></div>
            <div class="form-group"><label for="edit_status">Status</label><select id="edit_status" name="status"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
            <div style="display: flex; gap: 12px; margin-top: 16px;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">Update Category</button>
                <button type="button" class="btn btn-secondary" onclick="hideEditModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal-overlay" id="deleteModal">
    <div class="modal" style="max-width: 400px;">
        <div class="modal-header">
            <h3 style="color: var(--accent);"><i class="fas fa-exclamation-triangle"></i> Delete Category</h3>
            <button class="modal-close" onclick="hideDeleteModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="category_id" id="delete_category_id">
            <p>Delete category <strong id="delete_category_name"></strong>?</p>
            <p style="color: var(--text-light); font-size: 0.85rem;">This cannot be undone.</p>
            <div style="display: flex; gap: 12px; margin-top: 16px;">
                <button type="submit" class="btn btn-danger" style="flex: 1;">Delete</button>
                <button type="button" class="btn btn-secondary" onclick="hideDeleteModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function editCategory(cat) {
    document.getElementById('edit_category_id').value = cat.id;
    document.getElementById('edit_name').value = cat.name;
    document.getElementById('edit_description').value = cat.description || '';
    document.getElementById('edit_sort_order').value = cat.sort_order;
    document.getElementById('edit_status').value = cat.status;
    document.getElementById('edit_image').value = '';

    var imgEl = document.getElementById('edit_current_image');
    var noImgEl = document.getElementById('edit_no_image');
    if (cat.image) {
        imgEl.src = '<?php echo SITE_URL; ?>assets/uploads/categories/' + cat.image;
        imgEl.style.display = 'inline-block';
        noImgEl.style.display = 'none';
    } else {
        imgEl.style.display = 'none';
        noImgEl.style.display = 'inline';
    }

    document.getElementById('editModal').classList.add('show');
}
function hideEditModal() { document.getElementById('editModal').classList.remove('show'); }
function deleteCategory(id, name) {
    document.getElementById('delete_category_id').value = id;
    document.getElementById('delete_category_name').textContent = name;
    document.getElementById('deleteModal').classList.add('show');
}
function hideDeleteModal() { document.getElementById('deleteModal').classList.remove('show'); }
document.getElementById('editModal').addEventListener('click', function(e) { if (e.target === this) hideEditModal(); });
document.getElementById('deleteModal').addEventListener('click', function(e) { if (e.target === this) hideDeleteModal(); });
</script>

<?php include '../../includes/footer.php'; ?>