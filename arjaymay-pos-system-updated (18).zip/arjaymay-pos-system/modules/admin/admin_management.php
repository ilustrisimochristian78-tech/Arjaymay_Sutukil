<?php
// ======================================================
// ADMIN MANAGEMENT (Admin Only)
// Lets an existing admin create additional admin accounts.
// Accounts are stored in the database like any other user -
// there is no fixed/hardcoded limit on how many can exist.
// A few safety rules are enforced so the shop can never get
// locked out: an admin cannot delete or deactivate themselves,
// and the last remaining active admin cannot be deleted or
// deactivated either.
// ======================================================
require_once '../../config/database.php';
requireAdmin();

$pdo = getDBConnection();
$message = '';
$error = '';

function countActiveAdmins(PDO $pdo): int {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin' AND status = 'active'");
    return (int)$stmt->fetch()['count'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        $username = sanitize($_POST['username'] ?? '');
        $full_name = sanitize($_POST['full_name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($username) || empty($full_name) || empty($password)) {
            $error = 'Username, full name, and password are required.';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match.';
        } elseif (strlen($password) < 4) {
            $error = 'Password must be at least 4 characters.';
        } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address (e.g., user@example.com).';
        } else {
            $result = createUser([
                'username' => $username,
                'password' => $password,
                'full_name' => $full_name,
                'email' => $email,
                'phone' => $phone,
                'role' => 'admin'
            ]);

            if ($result['success']) {
                $message = 'Admin account created successfully!';
                $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'add_admin', ?)");
                $stmt->execute([$_SESSION['user_id'], "Added admin: $username - $full_name"]);

                header('Location: ' . $_SERVER['PHP_SELF']);
                exit;
            } else {
                $error = $result['error'];
            }
        }
    }

    if ($_POST['action'] === 'delete') {
        $admin_id = (int)($_POST['admin_id'] ?? 0);
        if ($admin_id > 0) {
            if ($admin_id == $_SESSION['user_id']) {
                $error = 'You cannot delete your own account!';
            } else {
                $stmt = $pdo->prepare("SELECT username, full_name, status FROM users WHERE id = ? AND role = 'admin'");
                $stmt->execute([$admin_id]);
                $admin = $stmt->fetch();
                if ($admin) {
                    if ($admin['status'] === 'active' && countActiveAdmins($pdo) <= 1) {
                        $error = 'You cannot delete the last remaining active admin account.';
                    } else {
                        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'admin'");
                        if ($stmt->execute([$admin_id])) {
                            $message = 'Admin account deleted successfully!';
                            $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'delete_admin', ?)");
                            $stmt->execute([$_SESSION['user_id'], "Deleted admin: {$admin['username']} - {$admin['full_name']}"]);

                            header('Location: ' . $_SERVER['PHP_SELF']);
                            exit;
                        } else {
                            $error = 'Failed to delete admin account.';
                        }
                    }
                } else {
                    $error = 'Admin not found.';
                }
            }
        }
    }

    if ($_POST['action'] === 'toggle') {
        $admin_id = (int)($_POST['admin_id'] ?? 0);
        $status = $_POST['status'] ?? 'active';
        if ($admin_id > 0 && in_array($status, ['active', 'inactive'])) {
            if ($admin_id == $_SESSION['user_id']) {
                $error = 'You cannot change your own status!';
            } elseif ($status === 'inactive' && countActiveAdmins($pdo) <= 1) {
                $error = 'You cannot deactivate the last remaining active admin account.';
            } else {
                $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'admin'");
                if ($stmt->execute([$status, $admin_id])) {
                    $message = 'Admin status updated successfully!';
                    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'toggle_admin', ?)");
                    $stmt->execute([$_SESSION['user_id'], "Admin #$admin_id status: $status"]);

                    header('Location: ' . $_SERVER['PHP_SELF']);
                    exit;
                } else {
                    $error = 'Failed to update admin status.';
                }
            }
        }
    }
}

$stmt = $pdo->query("SELECT * FROM users WHERE role = 'admin' ORDER BY created_at DESC");
$admins = $stmt->fetchAll();

include '../../includes/header.php';
?>

<style>
.quick-action-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 12px;
    padding: 20px;
}
.quick-action-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 16px;
    border: 2px solid #e0e0e0;
    border-radius: 12px;
    text-decoration: none;
    color: var(--text-dark);
    transition: all 0.3s ease;
    background: #f8f9fa;
}
.quick-action-card:hover {
    border-color: var(--primary);
    transform: translateY(-2px);
    box-shadow: var(--shadow);
    background: #fff;
}
.quick-action-card i {
    font-size: 1.8rem;
    margin-bottom: 8px;
    color: var(--primary);
}
.quick-action-card span {
    font-size: 0.85rem;
    font-weight: 500;
    text-align: center;
}
</style>

<div class="page-header">
    <h2><i class="fas fa-user-shield"></i> Admin Management</h2>
    <p>Create and manage administrator accounts</p>
</div>

<?php if ($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<!-- Admin Info -->
<div class="alert alert-info" style="display: flex; align-items: center; gap: 12px;">
    <i class="fas fa-shield-alt" style="font-size: 1.5rem;"></i>
    <div>
        <strong>Administrator Access</strong>
        <p style="margin: 0; font-size: 0.85rem;">You are logged in as <?php echo sanitize($_SESSION['full_name']); ?>. There's no limit on how many admin accounts can exist - the system just always keeps at least one active admin so the shop can never get locked out.</p>
    </div>
</div>

<!-- Quick Actions -->
<div class="table-container">
    <div class="table-header"><h3><i class="fas fa-bolt"></i> Quick Actions</h3></div>
    <div class="quick-action-grid">
        <a href="#addAdmin" class="quick-action-card" onclick="document.getElementById('addAdmin').scrollIntoView({behavior:'smooth'})">
            <i class="fas fa-user-plus"></i>
            <span>Add Admin</span>
        </a>
        <a href="cashier_management.php" class="quick-action-card">
            <i class="fas fa-users"></i>
            <span>Cashier Management</span>
        </a>
        <a href="dashboard.php" class="quick-action-card">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </div>
</div>

<!-- Add Admin Form -->
<div class="table-container" id="addAdmin">
    <div class="table-header"><h3><i class="fas fa-plus-circle"></i> Add New Admin</h3></div>
    <div style="padding: 20px;">
        <form method="POST" action="" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;" id="adminForm">
            <input type="hidden" name="action" value="add">
            <div class="form-group">
                <label for="username">Username <span style="color: #e74c3c;">*</span></label>
                <input type="text" id="username" name="username" placeholder="Enter username" required>
            </div>
            <div class="form-group">
                <label for="full_name">Full Name <span style="color: #e74c3c;">*</span></label>
                <input type="text" id="full_name" name="full_name" placeholder="Enter full name" required>
            </div>
            <div class="form-group">
                <label for="email">Email <span style="color: #e74c3c;">*</span></label>
                <input type="email" id="email" name="email" placeholder="Enter email (must contain @)" required>
                <small style="color: var(--text-light);">Email must contain the @ symbol</small>
            </div>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="text" id="phone" name="phone" placeholder="Enter phone number">
            </div>
            <div class="form-group">
                <label for="password">Password <span style="color: #e74c3c;">*</span></label>
                <div style="position: relative; display: flex; align-items: center;">
                    <input type="password" id="password" name="password" placeholder="Min 4 chars" required style="padding-right: 45px; width: 100%;">
                    <button type="button" onclick="togglePassword('password', this)" style="position: absolute; right: 12px; background: none; border: none; cursor: pointer; font-size: 1.1rem; color: #636e72; padding: 4px 8px;">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                <small style="color: var(--text-light);">Min 4 characters</small>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password <span style="color: #e74c3c;">*</span></label>
                <div style="position: relative; display: flex; align-items: center;">
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm password" required style="padding-right: 45px; width: 100%;">
                    <button type="button" onclick="togglePassword('confirm_password', this)" style="position: absolute; right: 12px; background: none; border: none; cursor: pointer; font-size: 1.1rem; color: #636e72; padding: 4px 8px;">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                <div id="confirmMatch" style="font-size: 0.75rem; margin-top: 4px;"></div>
            </div>
            <div style="grid-column: 1 / -1;">
                <button type="submit" class="btn btn-primary" id="adminSubmitBtn"><i class="fas fa-user-plus"></i> Create Admin Account</button>
            </div>
        </form>
    </div>
</div>

<script>
function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const password = document.getElementById('password');
    const confirm = document.getElementById('confirm_password');
    const matchMsg = document.getElementById('confirmMatch');
    const submitBtn = document.getElementById('adminSubmitBtn');

    function validatePassword() {
        const pwd = password.value;
        const conf = confirm.value;

        if (conf.length === 0) {
            matchMsg.textContent = '';
            submitBtn.disabled = false;
            return;
        }

        if (pwd === conf) {
            matchMsg.innerHTML = '<i class="fas fa-check-circle" style="color:#2c5f2d;"></i> Passwords match!';
            matchMsg.style.color = '#2c5f2d';
            submitBtn.disabled = false;
        } else {
            matchMsg.innerHTML = '<i class="fas fa-exclamation-circle" style="color:#e74c3c;"></i> Passwords do not match!';
            matchMsg.style.color = '#e74c3c';
            submitBtn.disabled = true;
        }
    }

    password.addEventListener('input', validatePassword);
    confirm.addEventListener('input', validatePassword);
});
</script>

<!-- Admins List -->
<div class="table-container">
    <div class="table-header">
        <h3><i class="fas fa-list"></i> Admin Accounts</h3>
        <span class="badge badge-primary"><?php echo count($admins); ?> admins</span>
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($admins as $admin): ?>
                <tr>
                    <td>#<?php echo $admin['id']; ?></td>
                    <td><strong><?php echo sanitize($admin['username']); ?></strong></td>
                    <td><?php echo sanitize($admin['full_name']); ?></td>
                    <td><?php echo sanitize($admin['email']); ?></td>
                    <td>
                        <span class="badge <?php echo $admin['status'] == 'active' ? 'badge-success' : 'badge-danger'; ?>">
                            <?php echo ucfirst($admin['status']); ?>
                        </span>
                    </td>
                    <td><?php echo date('M d, Y', strtotime($admin['created_at'])); ?></td>
                    <td>
                        <?php if ($admin['id'] != $_SESSION['user_id']): ?>
                        <button class="btn btn-warning btn-sm" onclick="toggleStatus(<?php echo $admin['id']; ?>, '<?php echo $admin['status']; ?>')">
                            <i class="fas <?php echo $admin['status'] == 'active' ? 'fa-pause' : 'fa-play'; ?>"></i>
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="deleteAdmin(<?php echo $admin['id']; ?>, '<?php echo addslashes($admin['full_name']); ?>')">
                            <i class="fas fa-trash"></i>
                        </button>
                        <?php else: ?>
                        <span style="color: var(--text-light); font-size: 0.75rem;">(You)</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($admins)): ?>
                <tr><td colspan="7" style="text-align: center; padding: 30px;">
                    <i class="fas fa-user-shield" style="font-size: 2rem; display: block; margin-bottom: 8px; color: var(--text-light);"></i>
                    No admin accounts found.
                </td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal-overlay" id="deleteModal">
    <div class="modal" style="max-width: 400px;">
        <div class="modal-header">
            <h3 style="color: var(--accent);"><i class="fas fa-exclamation-triangle"></i> Delete Admin</h3>
            <button class="modal-close" onclick="hideDeleteModal()">&times;</button>
        </div>
        <form method="POST" action="" id="deleteForm">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="admin_id" id="deleteAdminId">
            <p>Are you sure you want to delete admin <strong id="deleteName"></strong>?</p>
            <p style="color: var(--text-light); font-size: 0.85rem;">This action cannot be undone.</p>
            <div style="display: flex; gap: 12px; margin-top: 16px;">
                <button type="submit" class="btn btn-danger" style="flex: 1;"><i class="fas fa-trash"></i> Delete</button>
                <button type="button" class="btn btn-secondary" onclick="hideDeleteModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- Toggle Modal -->
<div class="modal-overlay" id="toggleModal">
    <div class="modal" style="max-width: 400px;">
        <div class="modal-header">
            <h3><i class="fas fa-exchange-alt"></i> Toggle Status</h3>
            <button class="modal-close" onclick="hideToggleModal()">&times;</button>
        </div>
        <form method="POST" action="" id="toggleForm">
            <input type="hidden" name="action" value="toggle">
            <input type="hidden" name="admin_id" id="toggleAdminId">
            <input type="hidden" name="status" id="toggleStatus">
            <p>Change status of admin <strong id="toggleName"></strong>?</p>
            <div style="display: flex; gap: 12px; margin-top: 16px;">
                <button type="submit" class="btn btn-primary" style="flex: 1;"><i class="fas fa-check"></i> Update</button>
                <button type="button" class="btn btn-secondary" onclick="hideToggleModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function deleteAdmin(id, name) {
    document.getElementById('deleteAdminId').value = id;
    document.getElementById('deleteName').textContent = name;
    document.getElementById('deleteModal').classList.add('show');
}

function hideDeleteModal() {
    document.getElementById('deleteModal').classList.remove('show');
}

function toggleStatus(id, currentStatus) {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    document.getElementById('toggleAdminId').value = id;
    document.getElementById('toggleStatus').value = newStatus;
    document.getElementById('toggleName').textContent = '#' + id + ' to ' + newStatus;
    document.getElementById('toggleModal').classList.add('show');
}

function hideToggleModal() {
    document.getElementById('toggleModal').classList.remove('show');
}

document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) hideDeleteModal();
});

document.getElementById('toggleModal').addEventListener('click', function(e) {
    if (e.target === this) hideToggleModal();
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        hideDeleteModal();
        hideToggleModal();
    }
});
</script>

<?php include '../../includes/footer.php'; ?>
