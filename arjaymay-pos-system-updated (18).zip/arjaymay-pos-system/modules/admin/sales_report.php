<?php
// ======================================================
// SALES REPORT - Printable & Auto-Save WITH LOGO (FIXED)
// ======================================================
require_once '../../config/database.php';
requireAdmin();

$pdo = getDBConnection();

// Get site settings
$settings = getSiteSettings();
$siteLogo = getSiteLogo();
$siteName = $settings['site_name'] ?? 'Arjaymay Sutukil';
$favicon = getSiteFavicon();

$date = isset($_GET['date']) ? $_GET['date'] : getCurrentDate();
$period = isset($_GET['period']) ? $_GET['period'] : 'daily';
if (!in_array($period, ['daily', 'weekly', 'monthly'])) {
    $period = 'daily';
}

// Work out the date range for the selected period
$refDate = new DateTime($date);
if ($period === 'weekly') {
    // Monday - Sunday of the week containing $date
    $rangeStart = (clone $refDate)->modify('monday this week');
    $rangeEnd = (clone $refDate)->modify('sunday this week');
} elseif ($period === 'monthly') {
    $rangeStart = (clone $refDate)->modify('first day of this month');
    $rangeEnd = (clone $refDate)->modify('last day of this month');
} else {
    $rangeStart = clone $refDate;
    $rangeEnd = clone $refDate;
}
$startDate = $rangeStart->format('Y-m-d');
$endDate = $rangeEnd->format('Y-m-d');

$report = getDailySalesReport($date);
$rangeReport = getRangeSalesReport($startDate, $endDate);
$dailyBreakdown = getDailyBreakdown($startDate, $endDate);

// Get best selling items
$stmt = $pdo->prepare("
    SELECT m.id, m.name, c.name as category_name, SUM(oi.quantity) as total_quantity, SUM(oi.subtotal) as total_sales
    FROM order_items oi
    JOIN menu_items m ON oi.menu_item_id = m.id
    JOIN categories c ON m.category_id = c.id
    JOIN orders o ON oi.order_id = o.id
    WHERE DATE(o.created_at) = ? AND o.status = 'completed'
    GROUP BY m.id, m.name, c.name
    ORDER BY total_quantity DESC
    LIMIT 10
");
$stmt->execute([$date]);
$bestSelling = $stmt->fetchAll();
$bestSellingRange = getBestSellingRange($startDate, $endDate, 10);

// Get hourly sales
$stmt = $pdo->prepare("
    SELECT HOUR(created_at) as hour, COUNT(*) as orders, SUM(total) as sales
    FROM orders
    WHERE DATE(created_at) = ? AND status = 'completed'
    GROUP BY HOUR(created_at)
    ORDER BY hour
");
$stmt->execute([$date]);
$hourlySales = $stmt->fetchAll();

// Get all orders for the selected period
$stmt = $pdo->prepare("
    SELECT o.*, u.full_name as cashier_name
    FROM orders o
    LEFT JOIN users u ON o.cashier_id = u.id
    WHERE DATE(o.created_at) BETWEEN ? AND ? AND o.status = 'completed'
    ORDER BY o.created_at DESC
");
$stmt->execute([$startDate, $endDate]);
$orders = $stmt->fetchAll();

// Calculate totals
$totalItems = 0;
foreach ($orders as $order) {
    $stmt2 = $pdo->prepare("SELECT SUM(quantity) as total_qty FROM order_items WHERE order_id = ?");
    $stmt2->execute([$order['id']]);
    $items = $stmt2->fetch();
    $totalItems += $items['total_qty'] ?? 0;
}

// The report shown on-screen uses the range report for weekly/monthly,
// and the single-day report for daily - both have the same shape.
$displayReport = $period === 'daily' ? $report : $rangeReport;
$displayBestSelling = $period === 'daily' ? $bestSelling : $bestSellingRange;

include '../../includes/header.php';
?>

<style>
.report-container {
    max-width: 1000px;
    margin: 0 auto;
}
.report-actions {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
}
.report-actions .left {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    align-items: center;
}
.report-actions .right {
    display: flex;
    gap: 10px;
}
.btn-download {
    background: #2980b9;
    color: #fff;
    padding: 8px 20px;
    border: none;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}
.btn-download:hover {
    background: #1a5276;
    transform: translateY(-2px);
}
.btn-print {
    background: #27ae60;
    color: #fff;
    padding: 8px 20px;
    border: none;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}
.btn-print:hover {
    background: #1e8449;
    transform: translateY(-2px);
}

/* Report Print Styles */
.report-content {
    background: #fff;
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    padding: 40px;
}
.report-header {
    text-align: center;
    border-bottom: 2px solid #2c5f2d;
    padding-bottom: 20px;
    margin-bottom: 20px;
}
.report-header .report-logo {
    max-height: 60px;
    max-width: 200px;
    object-fit: contain;
    margin-bottom: 8px;
}
.report-header .restaurant-name {
    font-size: 1.8rem;
    font-weight: 700;
    color: #2c5f2d;
}
.report-header .report-title {
    font-size: 1.2rem;
    font-weight: 600;
    color: var(--text-dark);
}
.report-header .report-date {
    color: var(--text-light);
    font-size: 0.9rem;
}
.report-header .report-meta {
    display: flex;
    justify-content: center;
    gap: 30px;
    margin-top: 10px;
    font-size: 0.85rem;
    color: var(--text-light);
}
.report-header .report-meta span {
    display: flex;
    align-items: center;
    gap: 6px;
}

.report-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-bottom: 25px;
}
.summary-card {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 15px;
    text-align: center;
    border: 1px solid #e0e0e0;
}
.summary-card .number {
    font-size: 1.5rem;
    font-weight: 700;
    color: #2c5f2d;
}
.summary-card .label {
    font-size: 0.75rem;
    color: var(--text-light);
}

.report-section {
    margin-bottom: 25px;
}
.report-section h4 {
    font-size: 1rem;
    font-weight: 600;
    color: var(--text-dark);
    margin-bottom: 10px;
    padding-bottom: 8px;
    border-bottom: 2px solid #f0f0f0;
}
.report-section table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
}
.report-section table th {
    background: #f8f9fa;
    padding: 8px 12px;
    text-align: left;
    font-weight: 600;
    border-bottom: 2px solid #e0e0e0;
}
.report-section table td {
    padding: 8px 12px;
    border-bottom: 1px solid #f0f0f0;
}
.report-section table tr:hover {
    background: #f8f9fa;
}
.report-section table .text-right {
    text-align: right;
}
.report-section table .text-center {
    text-align: center;
}
.report-footer {
    text-align: center;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 2px solid #2c5f2d;
    font-size: 0.8rem;
    color: var(--text-light);
}
.report-footer .footer-logo {
    max-height: 40px;
    max-width: 150px;
    object-fit: contain;
    margin-bottom: 6px;
}
.report-footer .powered {
    color: #b2b2b2;
    font-size: 0.7rem;
}

/* Print Styles */
@media print {
    body { background: white; padding: 0; margin: 0; }
    .main-content { padding: 0; max-width: 100%; }
    .report-actions { display: none !important; }
    .top-nav { display: none !important; }
    .footer { display: none !important; }
    .report-content { box-shadow: none; border-radius: 0; padding: 20px; }
    .report-container { max-width: 100%; }
    .page-header { display: none !important; }
    .no-print { display: none !important; }
    .report-section table { font-size: 0.75rem; }
    .summary-card .number { font-size: 1.2rem; }
    .report-header .restaurant-name { font-size: 1.4rem; }
}

/* Toast notification for download */
.download-toast {
    position: fixed;
    bottom: 30px;
    right: 30px;
    padding: 15px 25px;
    border-radius: 10px;
    color: #fff;
    font-weight: 500;
    z-index: 9999;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    animation: slideInUp 0.3s ease;
    font-family: 'Poppins', sans-serif;
    font-size: 0.9rem;
    background: #27ae60;
}
@keyframes slideInUp {
    from { transform: translateY(30px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
@keyframes slideOutDown {
    from { transform: translateY(0); opacity: 1; }
    to { transform: translateY(30px); opacity: 0; }
}
</style>

<div class="report-container">
    <div class="page-header">
        <h2><i class="fas fa-chart-bar"></i> Sales Report</h2>
        <p>View, print, and download sales reports</p>
    </div>

    <!-- Report Actions -->
    <div class="report-actions no-print">
        <div class="left">
            <form method="GET" action="" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                <div class="period-tabs">
                    <a href="?period=daily&date=<?php echo $date; ?>" class="period-tab <?php echo $period == 'daily' ? 'active' : ''; ?>">Daily</a>
                    <a href="?period=weekly&date=<?php echo $date; ?>" class="period-tab <?php echo $period == 'weekly' ? 'active' : ''; ?>">Weekly</a>
                    <a href="?period=monthly&date=<?php echo $date; ?>" class="period-tab <?php echo $period == 'monthly' ? 'active' : ''; ?>">Monthly</a>
                </div>
                <input type="hidden" name="period" value="<?php echo $period; ?>" id="periodField">
                <label for="date"><i class="fas fa-calendar"></i> Date:</label>
                <input type="date" id="date" name="date" value="<?php echo $date; ?>" style="padding: 8px 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-family: 'Poppins', sans-serif;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> View</button>
                <button type="button" class="btn btn-secondary" onclick="todayReport()">Today</button>
            </form>
        </div>
        <div class="right">
            <button class="btn-download" onclick="downloadReport()">
                <i class="fas fa-download"></i> Download Report
            </button>
            <button class="btn-print" onclick="printReport()">
                <i class="fas fa-print"></i> Print
            </button>
        </div>
    </div>

    <style>
    .period-tabs {
        display: flex;
        background: #f0f2f5;
        border-radius: 8px;
        padding: 3px;
    }
    .period-tab {
        padding: 7px 16px;
        border-radius: 6px;
        font-size: 0.85rem;
        font-weight: 500;
        color: var(--text-dark);
        text-decoration: none;
        transition: var(--transition);
    }
    .period-tab.active {
        background: var(--primary);
        color: #fff;
    }
    .bar-chart-wrap, .line-chart-wrap {
        width: 100%;
        overflow-x: auto;
    }
    </style>

    <!-- Report Content -->
    <div class="report-content" id="reportContent">
        <!-- Report Header -->
        <div class="report-header">
            <?php if ($siteLogo): ?>
                <img src="<?php echo $siteLogo; ?>" alt="<?php echo $siteName; ?>" class="report-logo">
            <?php endif; ?>
            <div class="restaurant-name"><?php echo $siteName; ?></div>
            <div class="report-title">
                <?php echo $period === 'daily' ? 'DAILY' : ($period === 'weekly' ? 'WEEKLY' : 'MONTHLY'); ?> SALES REPORT
            </div>
            <div class="report-date">
                <?php if ($period === 'daily'): ?>
                    <?php echo date('F d, Y', strtotime($date)); ?>
                <?php else: ?>
                    <?php echo $rangeStart->format('F d, Y'); ?> &ndash; <?php echo $rangeEnd->format('F d, Y'); ?>
                <?php endif; ?>
            </div>
            <div class="report-meta">
                <span><i class="fas fa-clock"></i> Generated: <?php echo date('h:i A'); ?></span>
                <span><i class="fas fa-user"></i> <?php echo sanitize($_SESSION['full_name']); ?></span>
                <span><i class="fas fa-tag"></i> Report #: <?php echo 'RPT-' . date('Ymd') . '-' . rand(1000, 9999); ?></span>
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="report-summary">
            <div class="summary-card">
                <div class="number"><?php echo $displayReport['total_orders']; ?></div>
                <div class="label">Total Orders</div>
            </div>
            <div class="summary-card">
                <div class="number"><?php echo formatCurrency($displayReport['total_sales']); ?></div>
                <div class="label">Total Sales</div>
            </div>
            <div class="summary-card">
                <div class="number"><?php echo $displayReport['dine_in_orders']; ?></div>
                <div class="label">Dine In Orders</div>
            </div>
            <div class="summary-card">
                <div class="number"><?php echo $displayReport['takeout_orders']; ?></div>
                <div class="label">Take Out Orders</div>
            </div>
            <div class="summary-card">
                <div class="number"><?php echo $totalItems; ?></div>
                <div class="label">Items Sold</div>
            </div>
            <div class="summary-card">
                <div class="number"><?php echo formatCurrency($displayReport['dine_in_sales']); ?></div>
                <div class="label">Dine In Sales</div>
            </div>
        </div>

        <?php if ($period !== 'daily'): ?>
        <!-- Sales Bar Chart -->
        <div class="report-section no-print">
            <h4><i class="fas fa-chart-bar"></i> <?php echo $period === 'weekly' ? 'Daily Sales This Week' : 'Daily Sales This Month'; ?></h4>
            <div class="bar-chart-wrap">
                <canvas id="salesBarChart" height="240"></canvas>
            </div>
        </div>
        <?php endif; ?>

        <!-- Best Selling Items -->
        <div class="report-section">
            <h4><i class="fas fa-trophy" style="color: #f39c12;"></i> Best Selling Items</h4>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Item</th>
                        <th>Category</th>
                        <th class="text-right">Qty Sold</th>
                        <th class="text-right">Total Sales</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($displayBestSelling)): ?>
                    <tr><td colspan="5" style="text-align: center; padding: 20px; color: var(--text-light);">No sales data available.</td></tr>
                    <?php else: ?>
                    <?php $rank = 1; foreach ($displayBestSelling as $item): ?>
                    <tr>
                        <td><?php echo $rank <= 3 ? '🏆' : '#' . $rank; ?></td>
                        <td><strong><?php echo sanitize($item['name']); ?></strong></td>
                        <td><span class="badge badge-primary"><?php echo sanitize($item['category_name']); ?></span></td>
                        <td class="text-right"><?php echo $item['total_quantity']; ?></td>
                        <td class="text-right"><?php echo formatCurrency($item['total_sales']); ?></td>
                    </tr>
                    <?php $rank++; endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($period === 'daily'): ?>
        <!-- Hourly Sales -->
        <div class="report-section">
            <h4><i class="fas fa-clock"></i> Hourly Sales</h4>
            <table>
                <thead>
                    <tr>
                        <th>Time</th>
                        <th class="text-right">Orders</th>
                        <th class="text-right">Sales</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($hourlySales)): ?>
                    <tr><td colspan="3" style="text-align: center; padding: 20px; color: var(--text-light);">No data available.</td></tr>
                    <?php else: ?>
                    <?php foreach ($hourlySales as $hour): ?>
                    <tr>
                        <td><?php echo sprintf('%02d:00 - %02d:59', $hour['hour'], $hour['hour']); ?></td>
                        <td class="text-right"><?php echo $hour['orders']; ?></td>
                        <td class="text-right"><?php echo formatCurrency($hour['sales']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <!-- Order List -->
        <div class="report-section">
            <h4><i class="fas fa-receipt"></i> Orders</h4>
            <table>
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Cashier</th>
                        <th>Type</th>
                        <th class="text-right">Total</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($orders)): ?>
                    <tr><td colspan="5" style="text-align: center; padding: 20px; color: var(--text-light);">No orders for this date.</td></tr>
                    <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><strong><?php echo $order['order_number']; ?></strong></td>
                        <td><?php echo sanitize($order['cashier_name']); ?></td>
                        <td><span class="badge <?php echo $order['order_type'] == 'dine_in' ? 'badge-primary' : 'badge-warning'; ?>"><?php echo ucfirst(str_replace('_', ' ', $order['order_type'])); ?></span></td>
                        <td class="text-right"><?php echo formatCurrency($order['total']); ?></td>
                        <td><?php echo date('h:i A', strtotime($order['created_at'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Report Footer -->
        <div class="report-footer">
            <?php if ($siteLogo): ?>
                <img src="<?php echo $siteLogo; ?>" alt="<?php echo $siteName; ?>" class="footer-logo">
            <?php endif; ?>
            <p><strong>THANK YOU FOR YOUR BUSINESS!</strong></p>
            <p>This report is generated automatically by <?php echo $siteName; ?> POS System.</p>
            <div class="powered">Powered by <?php echo $siteName; ?> POS System v1.0</div>
        </div>
    </div>
</div>

<script>
// ======================================================
// REPORT FUNCTIONS - FIXED
// ======================================================

<?php if ($period !== 'daily'): ?>
// Daily sales breakdown data for the bar chart (no external
// chart library - keeps this working with no internet).
var chartData = <?php echo json_encode(array_map(function($d) {
    return ['label' => $d['label'], 'sales' => round($d['sales'], 2), 'orders' => $d['orders']];
}, $dailyBreakdown)); ?>;

function drawBarChart() {
    var canvas = document.getElementById('salesBarChart');
    if (!canvas) return;

    var dpr = window.devicePixelRatio || 1;
    var cssWidth = Math.max(canvas.parentElement.clientWidth, chartData.length * 50);
    var cssHeight = 240;
    canvas.style.width = cssWidth + 'px';
    canvas.style.height = cssHeight + 'px';
    canvas.width = cssWidth * dpr;
    canvas.height = cssHeight * dpr;

    var ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, cssWidth, cssHeight);

    var padding = { top: 20, right: 20, bottom: 34, left: 60 };
    var chartW = cssWidth - padding.left - padding.right;
    var chartH = cssHeight - padding.top - padding.bottom;

    var maxSales = Math.max.apply(null, chartData.map(function(d) { return d.sales; }).concat([1]));
    var niceMax = maxSales === 0 ? 100 : Math.ceil(maxSales * 1.15 / 5) * 5;

    // Gridlines + Y axis labels
    ctx.strokeStyle = '#eee';
    ctx.fillStyle = '#888';
    ctx.font = '11px Poppins, sans-serif';
    ctx.textAlign = 'right';
    var steps = 5;
    for (var i = 0; i <= steps; i++) {
        var y = padding.top + chartH - (chartH * i / steps);
        var val = niceMax * i / steps;
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(padding.left + chartW, y);
        ctx.stroke();
        ctx.fillText('\u20b1' + Math.round(val), padding.left - 8, y + 4);
    }

    // Bars
    var barSlot = chartW / chartData.length;
    var barWidth = Math.min(barSlot * 0.55, 46);
    ctx.textAlign = 'center';

    chartData.forEach(function(d, i) {
        var barHeight = niceMax > 0 ? (d.sales / niceMax) * chartH : 0;
        var x = padding.left + barSlot * i + (barSlot - barWidth) / 2;
        var y = padding.top + chartH - barHeight;

        var grad = ctx.createLinearGradient(0, y, 0, padding.top + chartH);
        grad.addColorStop(0, '#3d8b40');
        grad.addColorStop(1, '#2c5f2d');
        ctx.fillStyle = grad;
        ctx.fillRect(x, y, barWidth, barHeight);

        // Value on top of bar
        if (d.sales > 0) {
            ctx.fillStyle = '#2d3436';
            ctx.font = '10px Poppins, sans-serif';
            ctx.fillText('\u20b1' + Math.round(d.sales), x + barWidth / 2, y - 6);
        }

        // X axis label
        ctx.fillStyle = '#636e72';
        ctx.font = '10px Poppins, sans-serif';
        ctx.fillText(d.label, x + barWidth / 2, padding.top + chartH + 16);
    });
}

window.addEventListener('resize', drawBarChart);
document.addEventListener('DOMContentLoaded', drawBarChart);
<?php endif; ?>

// Print report
function printReport() {
    if (!confirm('Print this report?')) return;
    window.print();
}

// Download report as HTML
function downloadReport() {
    // Get the report content
    var reportContent = document.getElementById('reportContent');
    var reportHTML = reportContent.innerHTML;
    
    // Get current date for filename
    var today = new Date();
    var dateStr = today.toISOString().split('T')[0];
    var timeStr = today.toTimeString().slice(0, 8).replace(/:/g, '');
    var filename = 'Sales_Report_' + dateStr + '_' + timeStr + '.html';
    
    // Create full HTML document
    var fullHTML = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Report - <?php echo date('F d, Y', strtotime($date)); ?></title>
    <?php include __DIR__ . '/../../includes/asset_links.php'; ?>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: #f0f2f5;
            padding: 30px;
        }
        .report-container {
            max-width: 1000px;
            margin: 0 auto;
        }
        .report-content {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            padding: 40px;
        }
        .report-header {
            text-align: center;
            border-bottom: 2px solid #2c5f2d;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        .report-header .report-logo {
            max-height: 60px;
            max-width: 200px;
            object-fit: contain;
            margin-bottom: 8px;
        }
        .report-header .restaurant-name {
            font-size: 1.8rem;
            font-weight: 700;
            color: #2c5f2d;
        }
        .report-header .report-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #2d3436;
        }
        .report-header .report-date {
            color: #636e72;
            font-size: 0.9rem;
        }
        .report-header .report-meta {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 10px;
            font-size: 0.85rem;
            color: #636e72;
        }
        .report-header .report-meta span {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .report-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        .summary-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            border: 1px solid #e0e0e0;
        }
        .summary-card .number {
            font-size: 1.5rem;
            font-weight: 700;
            color: #2c5f2d;
        }
        .summary-card .label {
            font-size: 0.75rem;
            color: #636e72;
        }
        .report-section {
            margin-bottom: 25px;
        }
        .report-section h4 {
            font-size: 1rem;
            font-weight: 600;
            color: #2d3436;
            margin-bottom: 10px;
            padding-bottom: 8px;
            border-bottom: 2px solid #f0f0f0;
        }
        .report-section table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.85rem;
        }
        .report-section table th {
            background: #f8f9fa;
            padding: 8px 12px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #e0e0e0;
        }
        .report-section table td {
            padding: 8px 12px;
            border-bottom: 1px solid #f0f0f0;
        }
        .report-section table tr:hover {
            background: #f8f9fa;
        }
        .report-section table .text-right {
            text-align: right;
        }
        .report-section table .text-center {
            text-align: center;
        }
        .badge {
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 500;
            display: inline-block;
        }
        .badge-primary { background: #cce5ff; color: #004085; }
        .badge-warning { background: #fff3cd; color: #856404; }
        .report-footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px solid #2c5f2d;
            font-size: 0.8rem;
            color: #636e72;
        }
        .report-footer .footer-logo {
            max-height: 40px;
            max-width: 150px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .report-footer .powered {
            color: #b2b2b2;
            font-size: 0.7rem;
        }
        @media print {
            body { background: white; padding: 0; }
            .report-content { box-shadow: none; border-radius: 0; padding: 20px; }
            .report-summary { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 768px) {
            .report-summary { grid-template-columns: 1fr 1fr; }
            .report-header .report-meta { flex-direction: column; gap: 5px; }
            .report-content { padding: 20px; }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <div class="report-content">
            ` + reportHTML + `
        </div>
    </div>
    <script>
        // Auto-print when loaded
        window.onload = function() {
            setTimeout(function() {
                window.print();
            }, 500);
        };
    <\/script>
</body>
</html>
    `;
    
    // Create blob and download
    var blob = new Blob([fullHTML], { type: 'text/html' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    // Show success toast
    showToast('✅ Report downloaded successfully!');
}

// Toast notification
function showToast(message) {
    var existing = document.querySelector('.download-toast');
    if (existing) existing.remove();
    
    var toast = document.createElement('div');
    toast.className = 'download-toast';
    toast.innerHTML = message;
    document.body.appendChild(toast);
    
    setTimeout(function() {
        toast.style.animation = 'slideOutDown 0.3s ease forwards';
        setTimeout(function() { toast.remove(); }, 300);
    }, 3000);
}

// Date shortcuts - FIXED
function todayReport() {
    var today = new Date();
    var dateStr = today.getFullYear() + '-' + 
                  String(today.getMonth() + 1).padStart(2, '0') + '-' + 
                  String(today.getDate()).padStart(2, '0');
    document.getElementById('date').value = dateStr;
    document.querySelector('form').submit();
}

function yesterdayReport() {
    var yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    var dateStr = yesterday.getFullYear() + '-' + 
                  String(yesterday.getMonth() + 1).padStart(2, '0') + '-' + 
                  String(yesterday.getDate()).padStart(2, '0');
    document.getElementById('date').value = dateStr;
    document.querySelector('form').submit();
}
</script>

<?php include '../../includes/footer.php'; ?>