<?php
// ======================================================
// ADMIN DASHBOARD - PROFESSIONAL DESIGN (FIXED)
// ======================================================

// Include database configuration
require_once '../../config/database.php';
requireAdmin();

$pdo = getDBConnection();
$stats = getDashboardStats();

// Get recent orders
$stmt = $pdo->prepare("
    SELECT o.*, u.full_name as cashier_name
    FROM orders o
    LEFT JOIN users u ON o.cashier_id = u.id
    ORDER BY o.created_at DESC
    LIMIT 10
");
$stmt->execute();
$recentOrders = $stmt->fetchAll();

// Get low stock items
$stmt = $pdo->query("
    SELECT id, name, price, stock, min_stock 
    FROM menu_items 
    WHERE stock <= min_stock 
    ORDER BY stock ASC 
    LIMIT 5
");
$lowStockItems = $stmt->fetchAll();

// ======================================================
// BEST SELLERS: Today / This Week / This Month
// ======================================================
$todayStr = getCurrentDate();
$todayDate = new DateTime($todayStr);
$weekStart = (clone $todayDate)->modify('monday this week')->format('Y-m-d');
$weekEnd = (clone $todayDate)->modify('sunday this week')->format('Y-m-d');
$monthStart = (clone $todayDate)->modify('first day of this month')->format('Y-m-d');
$monthEnd = (clone $todayDate)->modify('last day of this month')->format('Y-m-d');

$bestSellersToday = getBestSellingRange($todayStr, $todayStr, 5);
$bestSellersWeek = getBestSellingRange($weekStart, $weekEnd, 5);
$bestSellersMonth = getBestSellingRange($monthStart, $monthEnd, 5);

// Sales trend for the line chart: Today (hourly) / This Week / Last 30 Days
$trendStart30 = (clone $todayDate)->modify('-29 days')->format('Y-m-d');
$salesTrendToday = getHourlyBreakdown($todayStr);
$salesTrendWeek = getDailyBreakdown($weekStart, $weekEnd);
$salesTrendMonth = getDailyBreakdown($trendStart30, $todayStr);

// Previous-period comparisons (yesterday / last week / previous 30 days),
// used for the "vs last period" badge next to the Sales Trend chart.
$yesterdayStr = (clone $todayDate)->modify('-1 day')->format('Y-m-d');
$prevWeekStart = (clone $todayDate)->modify('monday this week')->modify('-7 days')->format('Y-m-d');
$prevWeekEnd = (clone $todayDate)->modify('sunday this week')->modify('-7 days')->format('Y-m-d');
$prevMonthEnd = (clone $todayDate)->modify('-30 days')->format('Y-m-d');
$prevMonthStart = (clone $todayDate)->modify('-59 days')->format('Y-m-d');

$trendPrevToday = getDailyBreakdown($yesterdayStr, $yesterdayStr);
$trendPrevWeek = getDailyBreakdown($prevWeekStart, $prevWeekEnd);
$trendPrevMonth = getDailyBreakdown($prevMonthStart, $prevMonthEnd);

function sumSales(array $rows): float {
    return array_sum(array_column($rows, 'sales'));
}

function trendChangePct(float $current, float $previous): ?float {
    if ($previous <= 0) return null; // avoid a misleading "infinite%" when there's nothing to compare against
    return round((($current - $previous) / $previous) * 100, 1);
}

$trendTotals = [
    'today' => ['current' => sumSales($salesTrendToday), 'change' => trendChangePct(sumSales($salesTrendToday), sumSales($trendPrevToday))],
    'week'  => ['current' => sumSales($salesTrendWeek), 'change' => trendChangePct(sumSales($salesTrendWeek), sumSales($trendPrevWeek))],
    'month' => ['current' => sumSales($salesTrendMonth), 'change' => trendChangePct(sumSales($salesTrendMonth), sumSales($trendPrevMonth))],
];

// ======================================================
// SALES SUMMARY: Daily / Weekly / Monthly totals, split by
// order type, for the Sales Summary pie chart below.
// ======================================================
$salesSummary = [
    'daily'   => getDailySalesReport($todayStr),
    'weekly'  => getRangeSalesReport($weekStart, $weekEnd),
    'monthly' => getRangeSalesReport($monthStart, $monthEnd),
];

include '../../includes/header.php';
?>

<style>
/* ======================================================
   PROFESSIONAL ADMIN DASHBOARD
   ====================================================== */

:root {
    --primary: #2c5f2d;
    --primary-light: #3d8b40;
    --primary-dark: #1a3d1b;
    --secondary: #f5a623;
    --accent: #e74c3c;
    --bg-light: #f0f2f5;
    --bg-card: #ffffff;
    --text-dark: #2d3436;
    --text-light: #636e72;
    --shadow: 0 2px 12px rgba(0,0,0,0.08);
    --radius: 12px;
    --transition: all 0.3s ease;
}

.dashboard-wrapper {
    max-width: 1400px;
    margin: 0 auto;
}

/* Page Header */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
    margin-bottom: 24px;
}

.page-header h1 {
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--text-dark);
    margin: 0;
}

.page-header h1 small {
    font-size: 0.9rem;
    font-weight: 400;
    color: var(--text-light);
}

.page-header .header-actions {
    display: flex;
    gap: 10px;
}

.page-header .header-actions .btn {
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-weight: 500;
    cursor: pointer;
    transition: var(--transition);
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-primary {
    background: var(--primary);
    color: #fff;
}

.btn-primary:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(44, 95, 45, 0.3);
}

.btn-secondary {
    background: var(--bg-light);
    color: var(--text-dark);
}

.btn-secondary:hover {
    background: #e0e0e0;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    position: relative;
    background: var(--bg-card);
    border-radius: 18px;
    padding: 22px 24px;
    box-shadow: var(--shadow);
    transition: var(--transition);
    overflow: hidden;
    color: #fff;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 10px 28px rgba(0,0,0,0.18);
}

.stat-card.grad-green { background: linear-gradient(135deg, #2c5f2d, #1a3d1b); }
.stat-card.grad-teal   { background: linear-gradient(135deg, #16a085, #0e6655); }
.stat-card.grad-gold   { background: linear-gradient(135deg, #f5a623, #d68910); }
.stat-card.grad-red    { background: linear-gradient(135deg, #e74c3c, #a93226); }
.stat-card.grad-purple { background: linear-gradient(135deg, #9b59b6, #6c3483); }

.stat-card .stat-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 14px;
}

.stat-card .stat-icon {
    width: 46px;
    height: 46px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    color: #fff;
    background: rgba(255,255,255,0.2);
}

.stat-card .stat-value {
    font-size: 1.9rem;
    font-weight: 700;
    color: #fff;
}

.stat-card .stat-label {
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.85);
    margin-top: 2px;
}

.stat-card .stat-sub {
    font-size: 0.75rem;
    color: rgba(255,255,255,0.75);
    margin-top: 8px;
}

/* Old flat icon-color classes kept as fallback for any other page reusing .stat-icon */
.stat-icon.green { background: var(--primary); }
.stat-icon.blue { background: #3498db; }
.stat-icon.orange { background: var(--secondary); }
.stat-icon.red { background: var(--accent); }
.stat-icon.purple { background: #9b59b6; }

/* Sales Trend chart: hover tooltip + empty-state message */
.chart-tooltip {
    position: absolute;
    display: none;
    pointer-events: none;
    background: #1e2b1e;
    color: #fff;
    padding: 8px 12px;
    border-radius: 10px;
    font-size: 0.78rem;
    line-height: 1.4;
    box-shadow: 0 6px 18px rgba(0,0,0,0.25);
    transform: translate(-50%, -100%);
    white-space: nowrap;
    z-index: 20;
}

.chart-tooltip .tt-label {
    display: block;
    color: rgba(255,255,255,0.65);
    font-size: 0.68rem;
    margin-bottom: 2px;
}

.chart-tooltip .tt-value {
    display: block;
    font-weight: 700;
    font-size: 0.9rem;
}

.chart-empty-msg {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    color: #b7c0b8;
    pointer-events: none;
}

.chart-empty-msg i {
    font-size: 1.6rem;
    display: block;
    margin-bottom: 6px;
    opacity: 0.6;
}

.chart-empty-msg span {
    font-size: 0.82rem;
    font-weight: 500;
}

.trend-change-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 9px;
    border-radius: 20px;
    font-size: 0.72rem;
    font-weight: 700;
}
.trend-change-badge.up { background: rgba(44,95,45,0.12); color: #2c5f2d; }
.trend-change-badge.down { background: rgba(231,76,60,0.12); color: #e74c3c; }
.trend-change-badge.flat { background: #f1f2f6; color: #888; }

/* Main Grid */
.admin-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 24px;
    margin-bottom: 30px;
}

@media (max-width: 992px) {
    .admin-grid {
        grid-template-columns: 1fr;
    }
}

/* Table Container */
.table-container {
    background: var(--bg-card);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    overflow: hidden;
}

.table-header {
    padding: 16px 20px;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}

.table-header h3 {
    font-size: 1rem;
    font-weight: 600;
    color: var(--text-dark);
    margin: 0;
}

.table-header .badge {
    background: var(--primary);
    color: #fff;
    padding: 2px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
}

.table-responsive {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table thead {
    background: #f8f9fa;
}

table th {
    padding: 12px 16px;
    text-align: left;
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--text-light);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #eee;
}

table td {
    padding: 12px 16px;
    border-bottom: 1px solid #f0f0f0;
    font-size: 0.85rem;
}

table tr:hover {
    background: #f8f9fa;
}

table tr:last-child td {
    border-bottom: none;
}

/* Badges */
.badge-status {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.7rem;
    font-weight: 500;
    display: inline-block;
}

.badge-status.success { background: #d4edda; color: #155724; }
.badge-status.danger { background: #f8d7da; color: #721c24; }
.badge-status.warning { background: #fff3cd; color: #856404; }
.badge-status.info { background: #d1ecf1; color: #0c5460; }
.badge-status.primary { background: #cce5ff; color: #004085; }

/* Quick Actions Grid */
.quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 12px;
    padding: 20px;
}

.quick-action-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 16px 12px;
    background: #f8f9fa;
    border-radius: 10px;
    text-decoration: none;
    color: var(--text-dark);
    transition: var(--transition);
    border: 2px solid transparent;
}

.quick-action-item:hover {
    border-color: var(--primary);
    background: #fff;
    transform: translateY(-2px);
    box-shadow: var(--shadow);
}

.quick-action-item i {
    font-size: 1.6rem;
    margin-bottom: 6px;
    color: var(--primary);
}

.quick-action-item span {
    font-size: 0.75rem;
    font-weight: 500;
    text-align: center;
}

/* Low Stock Item */
.low-stock-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 16px;
    border-bottom: 1px solid #f0f0f0;
}

.low-stock-item:last-child {
    border-bottom: none;
}

.low-stock-item .item-info .name {
    font-weight: 500;
    font-size: 0.85rem;
}

.low-stock-item .item-info .category {
    font-size: 0.7rem;
    color: var(--text-light);
}

.low-stock-item .stock-info {
    text-align: right;
}

.low-stock-item .stock-info .stock {
    font-weight: 600;
    font-size: 0.85rem;
}

.low-stock-item .stock-info .stock.danger {
    color: var(--accent);
}

.low-stock-item .stock-info .stock.warning {
    color: var(--secondary);
}

/* Responsive */
@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr 1fr;
    }
    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }
    .quick-actions {
        grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
    }
}

@media (max-width: 480px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    .stat-card .stat-value {
        font-size: 1.4rem;
    }
}
</style>

<div class="dashboard-wrapper">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1>
                <i class="fas fa-tachometer-alt" style="color: var(--primary);"></i> 
                Dashboard
                <small>Welcome back, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Admin'); ?></small>
            </h1>
        </div>
        <div class="header-actions">
            <a href="sales_report.php" class="btn btn-secondary">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="backup_restore.php" class="btn btn-secondary">
                <i class="fas fa-database"></i> Backup
            </a>
            <a href="menu_management.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add Menu Item
            </a>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats-grid">
        <div class="stat-card grad-green">
            <div class="stat-top">
                <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
            </div>
            <div class="stat-value"><?php echo $stats['today_orders'] ?? 0; ?></div>
            <div class="stat-label">Today's Orders</div>
            <div class="stat-sub"><?php echo $stats['today_orders'] ?? 0; ?> transactions today</div>
        </div>
        <div class="stat-card grad-teal">
            <div class="stat-top">
                <div class="stat-icon"><i class="fas fa-money-bill-wave"></i></div>
            </div>
            <div class="stat-value"><?php echo '₱' . number_format($stats['today_sales'] ?? 0, 2); ?></div>
            <div class="stat-label">Today's Sales</div>
            <div class="stat-sub">as of <?php echo date('g:i A'); ?></div>
        </div>
        <div class="stat-card grad-gold">
            <div class="stat-top">
                <div class="stat-icon"><i class="fas fa-boxes"></i></div>
            </div>
            <div class="stat-value"><?php echo $stats['total_menu_items'] ?? 0; ?></div>
            <div class="stat-label">Menu Items</div>
            <div class="stat-sub">across all categories</div>
        </div>
        <div class="stat-card grad-red">
            <div class="stat-top">
                <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
            </div>
            <div class="stat-value"><?php echo $stats['out_of_stock'] ?? 0; ?></div>
            <div class="stat-label">Out of Stock</div>
            <div class="stat-sub">needs restock</div>
        </div>
        <div class="stat-card grad-purple">
            <div class="stat-top">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
            </div>
            <div class="stat-value"><?php 
                $countStmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'cashier' AND status = 'active'");
                $countResult = $countStmt->fetch();
                echo $countResult['count'] ?? 0; 
            ?></div>
            <div class="stat-label">Active Cashiers</div>
            <div class="stat-sub">currently enabled</div>
        </div>
    </div>

    <!-- Best Sellers -->
    <div class="table-container" style="margin-bottom: 30px;">
        <div class="table-header">
            <h3><i class="fas fa-trophy" style="color: #f39c12;"></i> Best Sellers</h3>
            <div class="bs-tabs">
                <button class="bs-tab active" data-tab="today" onclick="switchBSTab('today')">Today</button>
                <button class="bs-tab" data-tab="week" onclick="switchBSTab('week')">This Week</button>
                <button class="bs-tab" data-tab="month" onclick="switchBSTab('month')">This Month</button>
            </div>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1.3fr; gap: 0; min-width: 0;" class="bs-layout">
            <div style="min-width: 0;">
                <?php
                $bsPanels = ['today' => $bestSellersToday, 'week' => $bestSellersWeek, 'month' => $bestSellersMonth];
                foreach ($bsPanels as $tabKey => $panelItems):
                ?>
                <div class="bs-panel" id="bsPanel-<?php echo $tabKey; ?>" style="<?php echo $tabKey !== 'today' ? 'display:none;' : ''; ?>">
                    <?php if (empty($panelItems)): ?>
                    <div style="padding: 24px; text-align: center; color: var(--text-light);">No sales data yet</div>
                    <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Item</th>
                                <th class="text-right">Qty</th>
                                <th class="text-right">Sales</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $rank = 1; foreach ($panelItems as $item): ?>
                            <tr>
                                <td><?php echo $rank <= 3 ? '🏆' : '#' . $rank; ?></td>
                                <td><strong><?php echo htmlspecialchars($item['name']); ?></strong></td>
                                <td class="text-right"><?php echo $item['total_quantity']; ?></td>
                                <td class="text-right">₱<?php echo number_format($item['total_sales'], 2); ?></td>
                            </tr>
                            <?php $rank++; endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <div style="padding: 16px 20px; border-left: 1px solid #f0f0f0; min-width: 0;">
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--text-light); margin-bottom: 8px;">
                    <i class="fas fa-chart-bar"></i> Best Sellers Chart
                </div>
                <div style="overflow-x: auto;">
                    <canvas id="bestSellersBarChart" height="180"></canvas>
                </div>
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--text-light); margin: 18px 0 8px;">
                    <div style="display:flex; align-items:center; gap:10px; flex-wrap: wrap; margin-bottom: 8px;">
                        <span><i class="fas fa-chart-line"></i> Sales Trend</span>
                        <span id="trendTotalValue" style="color: var(--text-dark); font-size: 0.95rem; font-weight: 700;"></span>
                        <span id="trendChangeBadge" class="trend-change-badge"></span>
                    </div>
                    <div class="bs-tabs">
                        <button class="bs-tab active" data-trend-tab="today" onclick="switchTrendTab('today')">Today</button>
                        <button class="bs-tab" data-trend-tab="week" onclick="switchTrendTab('week')">Weekly</button>
                        <button class="bs-tab" data-trend-tab="month" onclick="switchTrendTab('month')">Monthly</button>
                    </div>
                </div>
                <div style="overflow-x: auto; position: relative;" id="salesTrendWrap">
                    <canvas id="salesTrendChart" height="200"></canvas>
                    <div id="salesTrendTooltip" class="chart-tooltip"></div>
                    <div id="salesTrendEmpty" class="chart-empty-msg" style="display:none;">
                        <i class="fas fa-chart-line"></i>
                        <span id="salesTrendEmptyText">No sales recorded yet</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sales Summary: Daily / Weekly / Monthly -->
    <div class="table-container" style="margin-bottom: 30px;">
        <div class="table-header">
            <h3><i class="fas fa-chart-pie" style="color: var(--primary);"></i> Sales Summary</h3>
            <div class="bs-tabs">
                <button class="bs-tab active" data-ss-tab="daily" onclick="switchSalesSummary('daily')">Daily</button>
                <button class="bs-tab" data-ss-tab="weekly" onclick="switchSalesSummary('weekly')">Weekly</button>
                <button class="bs-tab" data-ss-tab="monthly" onclick="switchSalesSummary('monthly')">Monthly</button>
            </div>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0;" class="bs-layout">
            <div style="padding: 20px;">
                <div class="ss-stats-grid">
                    <div class="ss-stat">
                        <div class="ss-stat-label">Total Sales</div>
                        <div class="ss-stat-value" id="ssTotalSales">₱0.00</div>
                    </div>
                    <div class="ss-stat">
                        <div class="ss-stat-label">Total Orders</div>
                        <div class="ss-stat-value" id="ssTotalOrders">0</div>
                    </div>
                    <div class="ss-stat">
                        <div class="ss-stat-label"><span style="color:#2c5f2d;">&#9679;</span> Dine In</div>
                        <div class="ss-stat-value" id="ssDineIn">₱0.00</div>
                    </div>
                    <div class="ss-stat">
                        <div class="ss-stat-label"><span style="color:#f5a623;">&#9679;</span> Take Out</div>
                        <div class="ss-stat-value" id="ssTakeout">₱0.00</div>
                    </div>
                </div>
            </div>
            <div style="padding: 16px 20px; border-left: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: center;">
                <canvas id="salesSummaryPieChart" width="260" height="260"></canvas>
            </div>
        </div>
    </div>

    <style>
    .ss-stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .ss-stat { background: var(--bg-light); border-radius: 10px; padding: 14px 16px; }
    .ss-stat-label { font-size: 0.75rem; color: var(--text-light); font-weight: 500; margin-bottom: 6px; }
    .ss-stat-value { font-size: 1.15rem; font-weight: 700; color: var(--text-dark); }
    </style>

    <style>
    .bs-tabs { display: flex; gap: 6px; flex-wrap: wrap; }
    .bs-tab {
        border: none; background: var(--bg-light); color: var(--text-dark);
        padding: 6px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 500;
        cursor: pointer; font-family: 'Poppins', sans-serif; transition: var(--transition);
    }
    .bs-tab.active { background: var(--primary); color: #fff; }
    @media (max-width: 768px) {
        .bs-layout { grid-template-columns: 1fr !important; }
        .bs-layout > div:last-child { border-left: none !important; border-top: 1px solid #f0f0f0; }
    }
    </style>

    <!-- Main Content -->
    <div class="admin-grid">
        <!-- Recent Orders -->
        <div class="table-container">
            <div class="table-header">
                <h3><i class="fas fa-clock" style="color: var(--primary);"></i> Recent Orders</h3>
                <span class="badge"><?php echo count($recentOrders); ?> orders</span>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Cashier</th>
                            <th>Type</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recentOrders)): ?>
                        <tr><td colspan="6" style="text-align: center; padding: 30px; color: var(--text-light);">
                            <i class="fas fa-receipt" style="font-size: 2rem; display: block; margin-bottom: 8px;"></i>
                            No orders yet
                        </td></tr>
                        <?php else: ?>
                        <?php foreach ($recentOrders as $order): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($order['order_number']); ?></strong></td>
                            <td><?php echo htmlspecialchars($order['cashier_name'] ?? 'N/A'); ?></td>
                            <td>
                                <span class="badge-status <?php echo $order['order_type'] == 'dine_in' ? 'primary' : 'warning'; ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $order['order_type'])); ?>
                                </span>
                            </td>
                            <td><strong>₱<?php echo number_format($order['total'], 2); ?></strong></td>
                            <td>
                                <span class="badge-status <?php echo $order['status'] == 'completed' ? 'success' : 'warning'; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('h:i A', strtotime($order['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Quick Actions & Low Stock -->
        <div>
            <!-- Quick Actions -->
            <div class="table-container" style="margin-bottom: 20px;">
                <div class="table-header">
                    <h3><i class="fas fa-bolt" style="color: var(--secondary);"></i> Quick Actions</h3>
                </div>
                <div class="quick-actions">
                    <a href="menu_management.php" class="quick-action-item">
                        <i class="fas fa-utensils"></i>
                        <span>Menu</span>
                    </a>
                    <a href="category_management.php" class="quick-action-item">
                        <i class="fas fa-tags"></i>
                        <span>Categories</span>
                    </a>
                    <a href="cashier_management.php" class="quick-action-item">
                        <i class="fas fa-users"></i>
                        <span>Cashiers</span>
                    </a>
                    <a href="view_stocks.php" class="quick-action-item">
                        <i class="fas fa-warehouse"></i>
                        <span>Stocks</span>
                    </a>
                    <a href="sales_report.php" class="quick-action-item">
                        <i class="fas fa-chart-bar"></i>
                        <span>Reports</span>
                    </a>
                    <a href="transaction_history.php" class="quick-action-item">
                        <i class="fas fa-history"></i>
                        <span>History</span>
                    </a>
                </div>
            </div>

            <!-- Low Stock Alert -->
            <div class="table-container">
                <div class="table-header">
                    <h3><i class="fas fa-exclamation-triangle" style="color: var(--accent);"></i> Low Stock Alert</h3>
                    <span class="badge" style="background: var(--accent);"><?php echo count($lowStockItems); ?></span>
                </div>
                <?php if (empty($lowStockItems)): ?>
                <div style="padding: 20px; text-align: center; color: var(--text-light);">
                    <i class="fas fa-check-circle" style="color: var(--primary); font-size: 1.5rem; display: block; margin-bottom: 8px;"></i>
                    All items are well stocked
                </div>
                <?php else: ?>
                <?php foreach ($lowStockItems as $item): ?>
                <div class="low-stock-item">
                    <div class="item-info">
                        <div class="name"><?php echo htmlspecialchars($item['name']); ?></div>
                        <div class="category">₱<?php echo number_format($item['price'], 2); ?></div>
                    </div>
                    <div class="stock-info">
                        <div class="stock <?php echo $item['stock'] <= 0 ? 'danger' : 'warning'; ?>">
                            <?php echo $item['stock']; ?> / <?php echo $item['min_stock']; ?>
                        </div>
                        <div style="font-size: 0.65rem; color: var(--text-light);">min stock</div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>

<script>
function switchBSTab(tab) {
    document.querySelectorAll('.bs-panel').forEach(function(p) { p.style.display = 'none'; });
    document.getElementById('bsPanel-' + tab).style.display = '';
    document.querySelectorAll('.bs-tab[data-tab]').forEach(function(b) { b.classList.remove('active'); });
    document.querySelector('.bs-tab[data-tab="' + tab + '"]').classList.add('active');
    drawBestSellersBarChart(tab);
}

// Best Sellers bar chart - no external library, so it keeps
// working with no internet connection.
var bestSellersData = <?php echo json_encode([
    'today' => array_map(function($d) { return ['label' => $d['name'], 'qty' => (int)$d['total_quantity']]; }, $bestSellersToday),
    'week'  => array_map(function($d) { return ['label' => $d['name'], 'qty' => (int)$d['total_quantity']]; }, $bestSellersWeek),
    'month' => array_map(function($d) { return ['label' => $d['name'], 'qty' => (int)$d['total_quantity']]; }, $bestSellersMonth),
]); ?>;
var currentBSTab = 'today';

function drawBestSellersBarChart(tab) {
    currentBSTab = tab || currentBSTab;
    var canvas = document.getElementById('bestSellersBarChart');
    if (!canvas) return;
    var data = bestSellersData[currentBSTab] || [];

    var dpr = window.devicePixelRatio || 1;
    var cssWidth = canvas.parentElement.clientWidth;
    var cssHeight = 180;
    canvas.style.width = cssWidth + 'px';
    canvas.style.height = cssHeight + 'px';
    canvas.width = cssWidth * dpr;
    canvas.height = cssHeight * dpr;

    var ctx = canvas.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, cssWidth, cssHeight);

    if (data.length === 0) {
        ctx.fillStyle = '#888';
        ctx.font = '12px Poppins, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('No sales data yet', cssWidth / 2, cssHeight / 2);
        return;
    }

    var padding = { top: 22, right: 16, bottom: 34, left: 36 };
    var chartW = cssWidth - padding.left - padding.right;
    var chartH = cssHeight - padding.top - padding.bottom;
    var maxQty = Math.max.apply(null, data.map(function(d) { return d.qty; }).concat([1]));
    var niceMax = Math.ceil(maxQty * 1.15);

    // Gridlines + Y labels
    ctx.strokeStyle = '#eef1ee';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#9aa1a5';
    ctx.font = '10px Poppins, sans-serif';
    ctx.textAlign = 'right';
    var steps = 4;
    for (var i = 0; i <= steps; i++) {
        var y = padding.top + chartH - (chartH * i / steps);
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(padding.left + chartW, y);
        ctx.stroke();
        ctx.fillText(Math.round(niceMax * i / steps), padding.left - 8, y + 3);
    }

    var barPalette = [
        ['#3d8b40', '#2c5f2d'],
        ['#4fae52', '#3d8b40'],
        ['#f7b84a', '#e6941a'],
        ['#f0954e', '#dc7328'],
        ['#ec6f63', '#d94f42']
    ];
    var slotWidth = chartW / data.length;
    var barWidth = Math.min(slotWidth * 0.5, 52);
    var radius = Math.min(8, barWidth / 2);

    function roundedTopRect(x, y, w, h, r) {
        r = Math.min(r, w / 2, h);
        ctx.beginPath();
        ctx.moveTo(x, y + h);
        ctx.lineTo(x, y + r);
        ctx.arcTo(x, y, x + r, y, r);
        ctx.lineTo(x + w - r, y);
        ctx.arcTo(x + w, y, x + w, y + r, r);
        ctx.lineTo(x + w, y + h);
        ctx.closePath();
    }

    data.forEach(function(d, i) {
        var barHeight = niceMax > 0 ? Math.max((d.qty / niceMax) * chartH, d.qty > 0 ? 3 : 0) : 0;
        var x = padding.left + slotWidth * i + (slotWidth - barWidth) / 2;
        var y = padding.top + chartH - barHeight;
        var colors = barPalette[i % barPalette.length];

        // soft drop shadow under the bar
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.14)';
        ctx.shadowBlur = 6;
        ctx.shadowOffsetY = 3;
        var grad = ctx.createLinearGradient(0, y, 0, y + barHeight);
        grad.addColorStop(0, colors[0]);
        grad.addColorStop(1, colors[1]);
        ctx.fillStyle = grad;
        roundedTopRect(x, y, barWidth, barHeight, radius);
        ctx.fill();
        ctx.restore();

        ctx.fillStyle = '#2d3436';
        ctx.font = '600 10px Poppins, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(d.qty, x + barWidth / 2, y - 6);

        var label = d.label.length > 10 ? d.label.substring(0, 9) + '…' : d.label;
        ctx.fillStyle = '#636e72';
        ctx.font = '9px Poppins, sans-serif';
        ctx.fillText(label, x + barWidth / 2, padding.top + chartH + 16);
    });
}

// Sales trend line chart - no external library, so it keeps
// working with no internet connection.
var trendDataSets = {
    today: <?php echo json_encode(array_map(function($d) { return ['label' => $d['label'], 'sales' => round($d['sales'], 2)]; }, $salesTrendToday)); ?>,
    week:  <?php echo json_encode(array_map(function($d) { return ['label' => $d['label'], 'sales' => round($d['sales'], 2)]; }, $salesTrendWeek)); ?>,
    month: <?php echo json_encode(array_map(function($d) { return ['label' => $d['label'], 'sales' => round($d['sales'], 2)]; }, $salesTrendMonth)); ?>
};
var trendTotals = <?php echo json_encode($trendTotals); ?>;
var trendPeriodLabel = { today: 'vs yesterday', week: 'vs last week', month: 'vs prior 30 days' };
var currentTrendTab = 'today';
var trendData = trendDataSets[currentTrendTab];

function updateTrendBadge(tab) {
    var totalEl = document.getElementById('trendTotalValue');
    var badgeEl = document.getElementById('trendChangeBadge');
    if (!totalEl || !badgeEl) return;
    var info = trendTotals[tab];
    totalEl.textContent = '₱' + info.current.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    if (info.change === null) {
        badgeEl.className = 'trend-change-badge flat';
        badgeEl.innerHTML = 'no prior data';
    } else if (info.change > 0) {
        badgeEl.className = 'trend-change-badge up';
        badgeEl.innerHTML = '<i class="fas fa-arrow-up"></i> ' + info.change + '% ' + trendPeriodLabel[tab];
    } else if (info.change < 0) {
        badgeEl.className = 'trend-change-badge down';
        badgeEl.innerHTML = '<i class="fas fa-arrow-down"></i> ' + Math.abs(info.change) + '% ' + trendPeriodLabel[tab];
    } else {
        badgeEl.className = 'trend-change-badge flat';
        badgeEl.innerHTML = 'no change ' + trendPeriodLabel[tab];
    }
}

function switchTrendTab(tab) {
    currentTrendTab = tab;
    trendData = trendDataSets[tab];
    document.querySelectorAll('.bs-tab[data-trend-tab]').forEach(function(b) { b.classList.remove('active'); });
    document.querySelector('.bs-tab[data-trend-tab="' + tab + '"]').classList.add('active');
    updateTrendBadge(tab);
    drawTrendChart();
}

var trendChartLayout = null; // updated on every draw, used by the hover handler below

function drawTrendChart() {
    var canvas = document.getElementById('salesTrendChart');
    if (!canvas) return;

    var emptyMsgBox = document.getElementById('salesTrendEmpty');
    var emptyMsgText = document.getElementById('salesTrendEmptyText');
    var rawMax = Math.max.apply(null, trendData.map(function(d) { return d.sales; }).concat([0]));
    if (emptyMsgBox) {
        if (rawMax === 0) {
            var periodLabel = currentTrendTab === 'today' ? 'today' : (currentTrendTab === 'week' ? 'this week' : 'this month');
            emptyMsgText.textContent = 'No sales recorded yet ' + periodLabel;
            emptyMsgBox.style.display = 'block';
        } else {
            emptyMsgBox.style.display = 'none';
        }
    }

    var dpr = window.devicePixelRatio || 1;
    var cssWidth = Math.max(canvas.parentElement.clientWidth, trendData.length * 45);
    var cssHeight = 200;
    canvas.style.width = cssWidth + 'px';
    canvas.style.height = cssHeight + 'px';
    canvas.width = cssWidth * dpr;
    canvas.height = cssHeight * dpr;

    var ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, cssWidth, cssHeight);

    var padding = { top: 18, right: 20, bottom: 30, left: 58 };
    var chartW = cssWidth - padding.left - padding.right;
    var chartH = cssHeight - padding.top - padding.bottom;

    var maxSales = Math.max.apply(null, trendData.map(function(d) { return d.sales; }).concat([1]));
    var niceMax = maxSales === 0 ? 100 : Math.ceil(maxSales * 1.15 / 5) * 5;

    // Gridlines + Y labels
    ctx.strokeStyle = '#eef1ee';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#9aa1a5';
    ctx.font = '10px Poppins, sans-serif';
    ctx.textAlign = 'right';
    var steps = 4;
    for (var i = 0; i <= steps; i++) {
        var y = padding.top + chartH - (chartH * i / steps);
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(padding.left + chartW, y);
        ctx.stroke();
        ctx.fillText('\u20b1' + Math.round(niceMax * i / steps), padding.left - 8, y + 3);
    }

    function pointAt(i) {
        var x = padding.left + (trendData.length === 1 ? chartW / 2 : (chartW * i / (trendData.length - 1)));
        var y = padding.top + chartH - (niceMax > 0 ? (trendData[i].sales / niceMax) * chartH : 0);
        return { x: x, y: y };
    }

    // Build a smooth (Catmull-Rom -> Bezier) path through the points
    // instead of straight segments, for a more polished, professional
    // curve.
    function smoothPath(points) {
        ctx.moveTo(points[0].x, points[0].y);
        for (var i = 0; i < points.length - 1; i++) {
            var p0 = points[i === 0 ? i : i - 1];
            var p1 = points[i];
            var p2 = points[i + 1];
            var p3 = points[i + 2 < points.length ? i + 2 : i + 1];
            var cp1x = p1.x + (p2.x - p0.x) / 6;
            var cp1y = p1.y + (p2.y - p0.y) / 6;
            var cp2x = p2.x - (p3.x - p1.x) / 6;
            var cp2y = p2.y - (p3.y - p1.y) / 6;
            ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, p2.x, p2.y);
        }
    }

    var points = trendData.map(function(d, i) { return pointAt(i); });

    // Filled gradient area under the curve
    ctx.beginPath();
    smoothPath(points);
    ctx.lineTo(points[points.length - 1].x, padding.top + chartH);
    ctx.lineTo(points[0].x, padding.top + chartH);
    ctx.closePath();
    var areaGrad = ctx.createLinearGradient(0, padding.top, 0, padding.top + chartH);
    areaGrad.addColorStop(0, 'rgba(44, 95, 45, 0.22)');
    areaGrad.addColorStop(1, 'rgba(44, 95, 45, 0.02)');
    ctx.fillStyle = areaGrad;
    ctx.fill();

    // Smooth line, with a subtle glow
    ctx.save();
    ctx.beginPath();
    smoothPath(points);
    ctx.shadowColor = 'rgba(44, 95, 45, 0.35)';
    ctx.shadowBlur = 6;
    ctx.strokeStyle = '#2c5f2d';
    ctx.lineWidth = 2.75;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();
    ctx.restore();

    // Points + X labels
    ctx.textAlign = 'center';
    trendData.forEach(function(d, i) {
        var p = points[i];
        ctx.beginPath();
        ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = '#fff';
        ctx.fill();
        ctx.lineWidth = 2.25;
        ctx.strokeStyle = '#2c5f2d';
        ctx.stroke();

        if (i % Math.ceil(trendData.length / 7) === 0 || i === trendData.length - 1) {
            ctx.fillStyle = '#636e72';
            ctx.font = '9px Poppins, sans-serif';
            ctx.fillText(d.label, p.x, padding.top + chartH + 16);
        }
    });

    trendChartLayout = { points: points, data: trendData, cssWidth: cssWidth, cssHeight: cssHeight, padding: padding };
    setupTrendChartHover();
}

var trendChartHoverBound = false;
function setupTrendChartHover() {
    if (trendChartHoverBound) return;
    trendChartHoverBound = true;

    var canvas = document.getElementById('salesTrendChart');
    var wrap = document.getElementById('salesTrendWrap');
    var tooltip = document.getElementById('salesTrendTooltip');
    if (!canvas || !wrap || !tooltip) return;

    canvas.addEventListener('mousemove', function(e) {
        if (!trendChartLayout) return;
        var rect = canvas.getBoundingClientRect();
        var mouseX = e.clientX - rect.left;

        // Find the closest point to the cursor's X position
        var closest = 0;
        var closestDist = Infinity;
        trendChartLayout.points.forEach(function(p, i) {
            var dist = Math.abs(p.x - mouseX);
            if (dist < closestDist) { closestDist = dist; closest = i; }
        });

        var p = trendChartLayout.points[closest];
        var d = trendChartLayout.data[closest];

        tooltip.innerHTML = '<span class="tt-label">' + d.label + '</span><span class="tt-value">\u20b1' + Number(d.sales).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) + '</span>';
        tooltip.style.left = p.x + 'px';
        tooltip.style.top = (p.y - 10) + 'px';
        tooltip.style.display = 'block';
    });

    canvas.addEventListener('mouseleave', function() {
        tooltip.style.display = 'none';
    });
}

window.addEventListener('resize', function() { drawTrendChart(); drawBestSellersBarChart(); drawSalesSummaryPieChart(); });
document.addEventListener('DOMContentLoaded', function() { updateTrendBadge('today'); drawTrendChart(); drawBestSellersBarChart('today'); switchSalesSummary('daily'); });

// Sales Summary pie chart (Dine In vs Take Out) - no external
// library, so it keeps working with no internet connection.
var salesSummaryData = <?php echo json_encode($salesSummary); ?>;
var currentSSTab = 'daily';

function switchSalesSummary(tab) {
    currentSSTab = tab;
    document.querySelectorAll('.bs-tab[data-ss-tab]').forEach(function(b) { b.classList.remove('active'); });
    document.querySelector('.bs-tab[data-ss-tab="' + tab + '"]').classList.add('active');

    var d = salesSummaryData[tab];
    document.getElementById('ssTotalSales').textContent = '\u20b1' + Number(d.total_sales).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    document.getElementById('ssTotalOrders').textContent = d.total_orders;
    document.getElementById('ssDineIn').textContent = '\u20b1' + Number(d.dine_in_sales).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    document.getElementById('ssTakeout').textContent = '\u20b1' + Number(d.takeout_sales).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});

    drawSalesSummaryPieChart();
}

function drawSalesSummaryPieChart() {
    var canvas = document.getElementById('salesSummaryPieChart');
    if (!canvas) return;
    var d = salesSummaryData[currentSSTab];
    var dineIn = Number(d.dine_in_sales) || 0;
    var takeout = Number(d.takeout_sales) || 0;
    var total = dineIn + takeout;

    var dpr = window.devicePixelRatio || 1;
    var size = 260;
    canvas.style.width = size + 'px';
    canvas.style.height = size + 'px';
    canvas.width = size * dpr;
    canvas.height = size * dpr;

    var ctx = canvas.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, size, size);

    var cx = size / 2, cy = size / 2 - 10, radius = 88, innerRadius = radius * 0.55;

    if (total <= 0) {
        ctx.fillStyle = '#f0f2f0';
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#999';
        ctx.font = '12px Poppins, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('No sales data yet', cx, cy);
        return;
    }

    var slices = [
        { label: 'Dine In', value: dineIn, colors: ['#3d8b40', '#204a21'] },
        { label: 'Take Out', value: takeout, colors: ['#f7b84a', '#e6941a'] }
    ];

    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.15)';
    ctx.shadowBlur = 10;
    var startAngle = -Math.PI / 2;
    slices.forEach(function(s) {
        var sliceAngle = (s.value / total) * Math.PI * 2;
        if (s.value <= 0) return;
        var midAngle0 = startAngle + sliceAngle / 2;
        var grad = ctx.createRadialGradient(cx, cy, innerRadius, cx, cy, radius);
        grad.addColorStop(0, s.colors[0]);
        grad.addColorStop(1, s.colors[1]);
        ctx.beginPath();
        ctx.arc(cx, cy, radius, startAngle, startAngle + sliceAngle);
        ctx.arc(cx, cy, innerRadius, startAngle + sliceAngle, startAngle, true);
        ctx.closePath();
        ctx.fillStyle = grad;
        ctx.fill();
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 2;
        ctx.stroke();
        startAngle += sliceAngle;
    });
    ctx.restore();

    startAngle = -Math.PI / 2;
    slices.forEach(function(s) {
        var sliceAngle = (s.value / total) * Math.PI * 2;
        if (s.value <= 0) return;
        var midAngle = startAngle + sliceAngle / 2;
        var pct = Math.round((s.value / total) * 100);
        if (pct > 0) {
            var lx = cx + Math.cos(midAngle) * ((radius + innerRadius) / 2);
            var ly = cy + Math.sin(midAngle) * ((radius + innerRadius) / 2);
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 12px Poppins, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(pct + '%', lx, ly);
        }
        startAngle += sliceAngle;
    });

    // Center total label (donut hole)
    ctx.fillStyle = '#9aa1a5';
    ctx.font = '9px Poppins, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('TOTAL', cx, cy - 6);
    ctx.fillStyle = '#2d3436';
    ctx.font = 'bold 13px Poppins, sans-serif';
    ctx.fillText('\u20b1' + total.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0}), cx, cy + 12);

    // Legend
    ctx.textAlign = 'left';
    ctx.font = '11px Poppins, sans-serif';
    slices.forEach(function(s, i) {
        var ly = cy + radius + 26 + i * 18;
        ctx.fillStyle = s.colors[0];
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(cx - 70, ly - 9, 10, 10, 3) : ctx.rect(cx - 70, ly - 9, 10, 10);
        ctx.fill();
        ctx.fillStyle = '#2d3436';
        ctx.fillText(s.label, cx - 55, ly);
    });
}
</script>