<?php
// ======================================================
// TOGGLE STATUS (AJAX)
// ======================================================
require_once '../../../config/database.php';

if (!isLoggedIn() || !isAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$id = (int)($_POST['id'] ?? 0);
$type = $_POST['type'] ?? '';
$status = $_POST['status'] ?? '';

if ($id <= 0 || empty($type) || empty($status)) {
    echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
    exit;
}

$pdo = getDBConnection();

try {
    if ($type === 'user') {
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
    } elseif ($type === 'category') {
        $stmt = $pdo->prepare("UPDATE categories SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
    } elseif ($type === 'menu_item') {
        $stmt = $pdo->prepare("UPDATE menu_items SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid type']);
        exit;
    }
    
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'toggle_status', ?)");
    $stmt->execute([$_SESSION['user_id'], "Changed $type #$id status to: $status"]);
    
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>