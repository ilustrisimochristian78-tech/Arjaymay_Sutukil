<?php
// ======================================================
// SYSTEM SETTINGS - Logo, Favicon & Background
// ======================================================
require_once '../../config/database.php';
requireAdmin();

$pdo = getDBConnection();
$error = '';
$success = '';

// Get current settings
$stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
$settings = $stmt->fetch();

// If no settings, create default
if (!$settings) {
    $stmt = $pdo->prepare("INSERT INTO settings (id, site_name, site_logo, site_favicon, background_image) VALUES (1, 'Arjaymay Sutukil', '', '', '')");
    $stmt->execute();
    $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
    $settings = $stmt->fetch();
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Update site name
    if (isset($_POST['site_name'])) {
        $site_name = sanitize($_POST['site_name'] ?? 'Arjaymay Sutukil');
        $stmt = $pdo->prepare("UPDATE settings SET site_name = ? WHERE id = 1");
        $stmt->execute([$site_name]);
        $success = 'Site name updated successfully!';
        
        $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
        $settings = $stmt->fetch();
    }
    
    // Handle logo upload
    if (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['site_logo'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
        $maxSize = 2 * 1024 * 1024;
        
        $mimeType = mime_content_type($file['tmp_name']);
        
        if (!in_array($mimeType, $allowedTypes)) {
            $error = 'Only JPG, PNG, GIF, WEBP, and SVG images are allowed for logo.';
        } elseif ($file['size'] > $maxSize) {
            $error = 'Logo size must be less than 2MB.';
        } else {
            $uploadDir = '../../assets/images/logo/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            if (!empty($settings['site_logo']) && file_exists($uploadDir . $settings['site_logo'])) {
                unlink($uploadDir . $settings['site_logo']);
            }
            
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'logo.' . $extension;
            $filepath = $uploadDir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $stmt = $pdo->prepare("UPDATE settings SET site_logo = ? WHERE id = 1");
                $stmt->execute([$filename]);
                $success = 'Logo updated successfully!';
                
                $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
                $settings = $stmt->fetch();
            } else {
                $error = 'Failed to upload logo. Please check folder permissions.';
            }
        }
    }
    
    // Handle favicon upload
    if (isset($_FILES['site_favicon']) && $_FILES['site_favicon']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['site_favicon'];
        $allowedTypes = ['image/x-icon', 'image/vnd.microsoft.icon', 'image/png', 'image/jpeg'];
        $maxSize = 1 * 1024 * 1024;
        
        $mimeType = mime_content_type($file['tmp_name']);
        
        if (!in_array($mimeType, $allowedTypes) && !in_array($file['type'], $allowedTypes)) {
            $error = 'Only ICO, PNG, and JPG images are allowed for favicon.';
        } elseif ($file['size'] > $maxSize) {
            $error = 'Favicon size must be less than 1MB.';
        } else {
            $uploadDir = '../../assets/images/logo/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            if (!empty($settings['site_favicon']) && file_exists($uploadDir . $settings['site_favicon'])) {
                unlink($uploadDir . $settings['site_favicon']);
            }
            
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'favicon.' . $extension;
            $filepath = $uploadDir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $stmt = $pdo->prepare("UPDATE settings SET site_favicon = ? WHERE id = 1");
                $stmt->execute([$filename]);
                $success = 'Favicon updated successfully!';
                
                $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
                $settings = $stmt->fetch();
            } else {
                $error = 'Failed to upload favicon. Please check folder permissions.';
            }
        }
    }
    
    // Handle background image upload
    if (isset($_FILES['background_image']) && $_FILES['background_image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['background_image'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 5 * 1024 * 1024;
        
        $mimeType = mime_content_type($file['tmp_name']);
        
        if (!in_array($mimeType, $allowedTypes)) {
            $error = 'Only JPG, PNG, GIF, and WEBP images are allowed for background.';
        } elseif ($file['size'] > $maxSize) {
            $error = 'Background image size must be less than 5MB.';
        } else {
            $uploadDir = '../../assets/images/background/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            if (!empty($settings['background_image']) && file_exists($uploadDir . $settings['background_image'])) {
                unlink($uploadDir . $settings['background_image']);
            }
            
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'background_' . time() . '.' . $extension;
            $filepath = $uploadDir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $stmt = $pdo->prepare("UPDATE settings SET background_image = ? WHERE id = 1");
                $stmt->execute([$filename]);
                $success = 'Background image updated successfully!';
                
                $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
                $settings = $stmt->fetch();
            } else {
                $error = 'Failed to upload background image. Please check folder permissions.';
            }
        }
    }
    
    // Handle remove logo
    if (isset($_POST['remove_logo'])) {
        if (!empty($settings['site_logo'])) {
            $uploadDir = '../../assets/images/logo/';
            if (file_exists($uploadDir . $settings['site_logo'])) {
                unlink($uploadDir . $settings['site_logo']);
            }
            $stmt = $pdo->prepare("UPDATE settings SET site_logo = '' WHERE id = 1");
            $stmt->execute();
            $success = 'Logo removed successfully!';
            
            $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
            $settings = $stmt->fetch();
        }
    }
    
    // Handle remove favicon
    if (isset($_POST['remove_favicon'])) {
        if (!empty($settings['site_favicon'])) {
            $uploadDir = '../../assets/images/logo/';
            if (file_exists($uploadDir . $settings['site_favicon'])) {
                unlink($uploadDir . $settings['site_favicon']);
            }
            $stmt = $pdo->prepare("UPDATE settings SET site_favicon = '' WHERE id = 1");
            $stmt->execute();
            $success = 'Favicon removed successfully!';
            
            $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
            $settings = $stmt->fetch();
        }
    }
    
    // Handle remove background
    if (isset($_POST['remove_background'])) {
        if (!empty($settings['background_image'])) {
            $uploadDir = '../../assets/images/background/';
            if (file_exists($uploadDir . $settings['background_image'])) {
                unlink($uploadDir . $settings['background_image']);
            }
            $stmt = $pdo->prepare("UPDATE settings SET background_image = '' WHERE id = 1");
            $stmt->execute();
            $success = 'Background image removed successfully!';
            
            $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
            $settings = $stmt->fetch();
        }
    }
    
    // Update GCash number & account name
    if (isset($_POST['gcash_number']) || isset($_POST['gcash_name'])) {
        $gcashNumber = sanitize($_POST['gcash_number'] ?? '');
        $gcashName = sanitize($_POST['gcash_name'] ?? '');
        $stmt = $pdo->prepare("UPDATE settings SET gcash_number = ?, gcash_name = ? WHERE id = 1");
        $stmt->execute([$gcashNumber, $gcashName]);
        $success = 'GCash details updated successfully!';
        
        $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
        $settings = $stmt->fetch();
    }
    
    // Update Senior Citizen / PWD discount rates
    if (isset($_POST['senior_discount_rate']) && isset($_POST['pwd_discount_rate'])) {
        $seniorRate = (float)$_POST['senior_discount_rate'];
        $pwdRate = (float)$_POST['pwd_discount_rate'];
        // Clamp to a sane 0-100% range
        $seniorRate = max(0, min(100, $seniorRate));
        $pwdRate = max(0, min(100, $pwdRate));
        $stmt = $pdo->prepare("UPDATE settings SET senior_discount_rate = ?, pwd_discount_rate = ? WHERE id = 1");
        $stmt->execute([$seniorRate, $pwdRate]);
        $success = 'Discount rates updated successfully!';
        
        $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
        $settings = $stmt->fetch();
    }
    
    // Handle GCash QR code upload
    if (isset($_FILES['gcash_qr_image']) && $_FILES['gcash_qr_image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['gcash_qr_image'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 3 * 1024 * 1024;
        
        $mimeType = mime_content_type($file['tmp_name']);
        
        if (!in_array($mimeType, $allowedTypes)) {
            $error = 'Only JPG, PNG, GIF, and WEBP images are allowed for the GCash QR code.';
        } elseif ($file['size'] > $maxSize) {
            $error = 'GCash QR image size must be less than 3MB.';
        } else {
            $uploadDir = '../../assets/images/payment/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            if (!empty($settings['gcash_qr_image']) && file_exists($uploadDir . $settings['gcash_qr_image'])) {
                unlink($uploadDir . $settings['gcash_qr_image']);
            }
            
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'gcash_qr_' . time() . '.' . $extension;
            $filepath = $uploadDir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $stmt = $pdo->prepare("UPDATE settings SET gcash_qr_image = ? WHERE id = 1");
                $stmt->execute([$filename]);
                $success = 'GCash QR code updated successfully!';
                
                $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
                $settings = $stmt->fetch();
            } else {
                $error = 'Failed to upload GCash QR code. Please check folder permissions.';
            }
        }
    }
    
    // Handle remove GCash QR code
    if (isset($_POST['remove_gcash_qr'])) {
        if (!empty($settings['gcash_qr_image'])) {
            $uploadDir = '../../assets/images/payment/';
            if (file_exists($uploadDir . $settings['gcash_qr_image'])) {
                unlink($uploadDir . $settings['gcash_qr_image']);
            }
            $stmt = $pdo->prepare("UPDATE settings SET gcash_qr_image = '' WHERE id = 1");
            $stmt->execute();
            $success = 'GCash QR code removed successfully!';
            
            $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
            $settings = $stmt->fetch();
        }
    }
}

include '../../includes/header.php';
?>

<style>
.settings-container {
    max-width: 800px;
    margin: 0 auto;
}
.settings-card {
    background: #fff;
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    overflow: hidden;
    margin-bottom: 24px;
}
.settings-card .card-header {
    padding: 16px 24px;
    border-bottom: 1px solid #eee;
    background: #f8f9fa;
}
.settings-card .card-header h3 {
    margin: 0;
    font-size: 1.1rem;
}
.settings-card .card-body {
    padding: 24px;
}
.logo-preview {
    display: flex;
    align-items: center;
    gap: 20px;
    padding: 16px;
    background: #f8f9fa;
    border-radius: 8px;
    margin-bottom: 16px;
    flex-wrap: wrap;
}
.logo-preview .logo-image {
    max-width: 150px;
    max-height: 80px;
    object-fit: contain;
}
.logo-preview .logo-placeholder {
    width: 150px;
    height: 80px;
    border: 2px dashed #ccc;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #999;
    font-size: 0.85rem;
}
.logo-preview .logo-info {
    font-size: 0.85rem;
    color: var(--text-light);
}
.background-preview {
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 16px;
    background: #f8f9fa;
    border-radius: 8px;
    margin-bottom: 16px;
}
.background-preview .bg-image {
    max-width: 100%;
    max-height: 200px;
    border-radius: 8px;
    object-fit: cover;
    border: 2px solid #e0e0e0;
}
.background-preview .bg-placeholder {
    width: 100%;
    height: 150px;
    border: 2px dashed #ccc;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #999;
    font-size: 0.9rem;
    background: #f0f2f5;
}
.background-preview .bg-placeholder i {
    font-size: 2rem;
    display: block;
    margin-bottom: 8px;
}
.upload-btn-wrapper {
    position: relative;
    overflow: hidden;
    display: inline-block;
}
.upload-btn-wrapper input[type="file"] {
    position: absolute;
    left: 0;
    top: 0;
    opacity: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
}
.btn-upload {
    background: var(--primary);
    color: #fff;
    padding: 10px 24px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-family: 'Poppins', sans-serif;
    font-size: 0.85rem;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s;
}
.btn-upload:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
}
.btn-remove {
    background: #e74c3c;
    color: #fff;
    padding: 8px 20px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-family: 'Poppins', sans-serif;
    font-size: 0.85rem;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s;
}
.btn-remove:hover {
    background: #c0392b;
    transform: translateY(-2px);
}
.logo-helper {
    font-size: 0.75rem;
    color: var(--text-light);
    margin-top: 4px;
}
.alert-info {
    background: #d1ecf1;
    color: #0c5460;
    padding: 12px 18px;
    border-radius: 8px;
    border: 1px solid #bee5eb;
}
.alert-info i {
    margin-right: 8px;
}
.form-group {
    margin-bottom: 16px;
}
.form-group label {
    display: block;
    font-size: 0.85rem;
    font-weight: 500;
    color: var(--text-dark);
    margin-bottom: 4px;
}
.form-group input[type="text"] {
    width: 100%;
    padding: 10px 14px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-size: 0.95rem;
    transition: all 0.3s;
}
.form-group input[type="text"]:focus {
    border-color: var(--primary);
    outline: none;
    box-shadow: 0 0 0 3px rgba(44,95,45,0.1);
}
.btn-primary {
    background: var(--primary);
    color: #fff;
    padding: 10px 24px;
    border: none;
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}
.btn-primary:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
}
</style>

<div class="settings-container">
    <div class="page-header">
        <h2><i class="fas fa-cog"></i> System Settings</h2>
        <p>Manage your logo, favicon, background, and branding</p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
    <?php endif; ?>

    <!-- Site Name -->
    <div class="settings-card">
        <div class="card-header">
            <h3><i class="fas fa-pencil-alt"></i> Site Settings</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="form-group">
                    <label for="site_name">Site Name</label>
                    <input type="text" id="site_name" name="site_name" value="<?php echo htmlspecialchars($settings['site_name'] ?? 'Arjaymay Sutukil'); ?>">
                </div>
                <button type="submit" class="btn-primary"><i class="fas fa-save"></i> Save Site Name</button>
            </form>
        </div>
    </div>

    <!-- Logo -->
    <div class="settings-card">
        <div class="card-header">
            <h3><i class="fas fa-image"></i> Logo</h3>
        </div>
        <div class="card-body">
            <div class="logo-preview">
                <?php 
                $logoPath = '../../assets/images/logo/' . ($settings['site_logo'] ?? '');
                if (!empty($settings['site_logo']) && file_exists($logoPath)): 
                ?>
                    <img src="<?php echo SITE_URL; ?>assets/images/logo/<?php echo $settings['site_logo']; ?>" alt="Site Logo" class="logo-image">
                <?php else: ?>
                    <div class="logo-placeholder">
                        <i class="fas fa-image" style="font-size: 2rem;"></i>
                    </div>
                <?php endif; ?>
                <div class="logo-info">
                    <strong>Current Logo</strong><br>
                    <?php if (!empty($settings['site_logo'])): ?>
                        <span style="color: var(--primary);">✓ Logo uploaded</span>
                    <?php else: ?>
                        <span style="color: var(--text-light);">No logo uploaded</span>
                    <?php endif; ?>
                </div>
            </div>

            <form method="POST" action="" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Upload New Logo</label>
                    <div class="upload-btn-wrapper">
                        <button type="button" class="btn-upload"><i class="fas fa-upload"></i> Choose Logo Image</button>
                        <input type="file" name="site_logo" accept="image/*">
                    </div>
                    <div class="logo-helper">
                        <i class="fas fa-info-circle"></i> Recommended size: 200x80px. Max 2MB. JPG, PNG, GIF, WEBP, SVG
                    </div>
                </div>
                <button type="submit" class="btn-primary" style="margin-top:8px;"><i class="fas fa-upload"></i> Upload Logo</button>
            </form>

            <?php if (!empty($settings['site_logo'])): ?>
            <form method="POST" action="" style="margin-top: 8px;" onsubmit="return confirm('Remove the site logo?')">
                <button type="submit" name="remove_logo" value="1" class="btn-remove"><i class="fas fa-trash"></i> Remove Logo</button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Favicon -->
    <div class="settings-card">
        <div class="card-header">
            <h3><i class="fas fa-star"></i> Favicon (Browser Tab Icon)</h3>
        </div>
        <div class="card-body">
            <div class="logo-preview">
                <?php 
                $faviconPath = '../../assets/images/logo/' . ($settings['site_favicon'] ?? '');
                if (!empty($settings['site_favicon']) && file_exists($faviconPath)): 
                ?>
                    <img src="<?php echo SITE_URL; ?>assets/images/logo/<?php echo $settings['site_favicon']; ?>" alt="Favicon" style="width: 32px; height: 32px; object-fit: contain;">
                <?php else: ?>
                    <div style="width: 32px; height: 32px; border: 2px dashed #ccc; border-radius: 4px; display: flex; align-items: center; justify-content: center; color: #999; font-size: 0.7rem;">
                        <i class="fas fa-star"></i>
                    </div>
                <?php endif; ?>
                <div class="logo-info">
                    <strong>Current Favicon</strong><br>
                    <?php if (!empty($settings['site_favicon'])): ?>
                        <span style="color: var(--primary);">✓ Favicon uploaded</span>
                    <?php else: ?>
                        <span style="color: var(--text-light);">No favicon uploaded</span>
                    <?php endif; ?>
                </div>
            </div>

            <form method="POST" action="" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Upload Favicon</label>
                    <div class="upload-btn-wrapper">
                        <button type="button" class="btn-upload"><i class="fas fa-upload"></i> Choose Favicon</button>
                        <input type="file" name="site_favicon" accept=".ico,image/png,image/jpeg">
                    </div>
                    <div class="logo-helper">
                        <i class="fas fa-info-circle"></i> Recommended: 32x32px or 16x16px. ICO, PNG, JPG. Max 1MB.
                    </div>
                </div>
                <button type="submit" class="btn-primary" style="margin-top:8px;"><i class="fas fa-upload"></i> Upload Favicon</button>
            </form>

            <?php if (!empty($settings['site_favicon'])): ?>
            <form method="POST" action="" style="margin-top: 8px;" onsubmit="return confirm('Remove the favicon?')">
                <button type="submit" name="remove_favicon" value="1" class="btn-remove"><i class="fas fa-trash"></i> Remove Favicon</button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Background Image -->
    <div class="settings-card">
        <div class="card-header">
            <h3><i class="fas fa-image"></i> Login Page Background</h3>
        </div>
        <div class="card-body">
            <div class="background-preview">
                <?php 
                $bgPath = '../../assets/images/background/' . ($settings['background_image'] ?? '');
                if (!empty($settings['background_image']) && file_exists($bgPath)): 
                ?>
                    <img src="<?php echo SITE_URL; ?>assets/images/background/<?php echo $settings['background_image']; ?>" alt="Background Image" class="bg-image">
                <?php else: ?>
                    <div class="bg-placeholder">
                        <div>
                            <i class="fas fa-image"></i>
                            <p>No background image uploaded</p>
                            <small style="color: #bbb;">Default gradient will be used</small>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="logo-info">
                    <strong>Current Background</strong><br>
                    <?php if (!empty($settings['background_image'])): ?>
                        <span style="color: var(--primary);">✓ Background uploaded</span>
                    <?php else: ?>
                        <span style="color: var(--text-light);">Using default gradient background</span>
                    <?php endif; ?>
                </div>
            </div>

            <form method="POST" action="" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Upload Background Image</label>
                    <div class="upload-btn-wrapper">
                        <button type="button" class="btn-upload"><i class="fas fa-upload"></i> Choose Background Image</button>
                        <input type="file" name="background_image" accept="image/*">
                    </div>
                    <div class="logo-helper">
                        <i class="fas fa-info-circle"></i> Recommended size: 1920x1080px. Max 5MB. JPG, PNG, GIF, WEBP
                    </div>
                </div>
                <button type="submit" class="btn-primary" style="margin-top:8px;"><i class="fas fa-upload"></i> Upload Background</button>
            </form>

            <?php if (!empty($settings['background_image'])): ?>
            <form method="POST" action="" style="margin-top: 8px;" onsubmit="return confirm('Remove the background image?')">
                <button type="submit" name="remove_background" value="1" class="btn-remove"><i class="fas fa-trash"></i> Remove Background</button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- GCash Payment -->
    <div class="settings-card">
        <div class="card-header">
            <h3><i class="fas fa-mobile-alt"></i> GCash Payment</h3>
        </div>
        <div class="card-body">
            <div class="background-preview" id="gcashPreviewBox">
                <?php 
                $gcashQrPath = '../../assets/images/payment/' . ($settings['gcash_qr_image'] ?? '');
                if (!empty($settings['gcash_qr_image']) && file_exists($gcashQrPath)): 
                ?>
                    <img src="<?php echo SITE_URL; ?>assets/images/payment/<?php echo $settings['gcash_qr_image']; ?>?v=<?php echo time(); ?>" alt="GCash QR Code" class="bg-image" id="gcashPreviewImg" style="max-height: 260px; width: auto; max-width: 220px; margin: 0 auto;">
                <?php else: ?>
                    <div class="bg-placeholder" id="gcashPlaceholder">
                        <div>
                            <i class="fas fa-qrcode"></i>
                            <p>No GCash QR code uploaded</p>
                            <small style="color: #bbb;">Cashiers will only see the reference number field</small>
                        </div>
                    </div>
                    <img src="" alt="GCash QR Code" class="bg-image" id="gcashPreviewImg" style="display:none; max-height: 260px; width: auto; max-width: 220px; margin: 0 auto;">
                <?php endif; ?>
                <div class="logo-info" id="gcashStatusText">
                    <strong>Current QR Code</strong><br>
                    <?php if (!empty($settings['gcash_qr_image'])): ?>
                        <span style="color: var(--primary);">✓ QR code uploaded</span>
                    <?php else: ?>
                        <span style="color: var(--text-light);">No QR code uploaded</span>
                    <?php endif; ?>
                </div>
            </div>

            <form method="POST" action="" enctype="multipart/form-data" id="gcashForm">
                <div class="form-group">
                    <label>GCash QR Code Image</label>
                    <div class="upload-btn-wrapper">
                        <button type="button" class="btn-upload"><i class="fas fa-upload"></i> Choose QR Code Image</button>
                        <input type="file" name="gcash_qr_image" id="gcashQrInput" accept="image/*">
                    </div>
                    <div class="logo-helper">
                        <i class="fas fa-info-circle"></i> Upload a screenshot of your GCash "Receive Money" QR code. Max 3MB. JPG, PNG, GIF, WEBP. Leave empty to keep the current QR code.
                    </div>
                </div>
                <div class="form-group">
                    <label for="gcash_number">GCash Mobile Number</label>
                    <input type="text" id="gcash_number" name="gcash_number" placeholder="e.g. +63 977 382 0000" value="<?php echo htmlspecialchars($settings['gcash_number'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="gcash_name">GCash Account Name</label>
                    <input type="text" id="gcash_name" name="gcash_name" placeholder="e.g. Juan D." value="<?php echo htmlspecialchars($settings['gcash_name'] ?? ''); ?>">
                </div>
                <button type="submit" class="btn-primary"><i class="fas fa-save"></i> Save GCash Settings</button>
            </form>

            <?php if (!empty($settings['gcash_qr_image'])): ?>
            <form method="POST" action="" style="margin-top: 8px;" onsubmit="return confirm('Remove the GCash QR code?')">
                <button type="submit" name="remove_gcash_qr" value="1" class="btn-remove"><i class="fas fa-trash"></i> Remove QR Code</button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Senior Citizen / PWD Discount -->
    <div class="settings-card">
        <div class="card-header">
            <h3><i class="fas fa-id-card"></i> Senior Citizen / PWD Discount</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="form-group">
                    <label for="senior_discount_rate">Senior Citizen Discount (%)</label>
                    <input type="number" id="senior_discount_rate" name="senior_discount_rate" min="0" max="100" step="0.01" value="<?php echo htmlspecialchars($settings['senior_discount_rate'] ?? '20.00'); ?>">
                </div>
                <div class="form-group">
                    <label for="pwd_discount_rate">PWD Discount (%)</label>
                    <input type="number" id="pwd_discount_rate" name="pwd_discount_rate" min="0" max="100" step="0.01" value="<?php echo htmlspecialchars($settings['pwd_discount_rate'] ?? '20.00'); ?>">
                </div>
                <div class="logo-helper">
                    <i class="fas fa-info-circle"></i> These rates apply automatically at checkout when a cashier selects Senior Citizen or PWD as the discount type. RA 9994 / RA 10754 currently set this at 20% by law - only change this if your local guidelines differ.
                </div>
                <button type="submit" class="btn-primary" style="margin-top:8px;"><i class="fas fa-save"></i> Save Discount Rates</button>
            </form>
            <div class="logo-helper" style="margin-top:12px;">
                <i class="fas fa-id-card"></i> To view every Senior/PWD order along with the scanned ID photos, go to <a href="<?php echo SITE_URL; ?>modules/admin/discounts.php">Senior/PWD Discounts</a> in the sidebar.
            </div>
        </div>
    </div>

    <div class="alert-info">
        <i class="fas fa-info-circle"></i>
        <strong>Note:</strong> After uploading a new logo or background, you may need to clear your browser cache (Ctrl+F5) to see the changes.
    </div>
</div>

<script>
document.querySelectorAll('input[type="file"]').forEach(function(input) {
    if (input.id === 'gcashQrInput') return; // handled separately below - shows a preview instead of auto-submitting
    input.addEventListener('change', function() {
        if (this.files.length > 0) {
            var file = this.files[0];
            var maxSize = this.name === 'background_image' ? 5 * 1024 * 1024 : 2 * 1024 * 1024;
            
            if (file.size > maxSize) {
                alert('File size is too large! Maximum size is ' + (maxSize / 1024 / 1024) + 'MB.');
                this.value = '';
                return;
            }
            
            this.closest('form').submit();
        }
    });
});

// GCash QR: show a live preview of the chosen image before the admin saves,
// instead of uploading blind.
var gcashQrInput = document.getElementById('gcashQrInput');
if (gcashQrInput) {
    gcashQrInput.addEventListener('change', function() {
        if (this.files.length === 0) return;
        var file = this.files[0];
        var maxSize = 3 * 1024 * 1024;
        
        if (file.size > maxSize) {
            alert('File size is too large! Maximum size is 3MB.');
            this.value = '';
            return;
        }
        if (!file.type.startsWith('image/')) {
            alert('Please choose an image file.');
            this.value = '';
            return;
        }
        
        var reader = new FileReader();
        reader.onload = function(e) {
            var img = document.getElementById('gcashPreviewImg');
            var placeholder = document.getElementById('gcashPlaceholder');
            var statusText = document.getElementById('gcashStatusText');
            img.src = e.target.result;
            img.style.display = 'block';
            if (placeholder) placeholder.style.display = 'none';
            statusText.innerHTML = '<strong>New QR Code (preview)</strong><br><span style="color: var(--primary);">✓ Ready to save - click "Save GCash Settings" below</span>';
        };
        reader.readAsDataURL(file);
    });
}
</script>

<?php include '../../includes/footer.php'; ?>