<?php
// ======================================================
// NOTIFICATIONS (API) - New orders + low stock, for the
// admin dashboard notification bell.
// ======================================================
require_once '../../config/database.php';

if (!isLoggedIn() || !isAdmin()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

$pdo = getDBConnection();

// New / pending orders (not yet completed - i.e. still with the kitchen)
$stmt = $pdo->query("
    SELECT o.id, o.order_number, o.order_type, o.total, o.created_at
    FROM orders o
    WHERE o.status = 'pending'
    ORDER BY o.created_at DESC
    LIMIT 15
");
$pendingOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Low stock + out of stock items
$stmt = $pdo->query("
    SELECT id, name, stock, min_stock
    FROM menu_items
    WHERE stock <= min_stock
    ORDER BY stock ASC
    LIMIT 15
");
$lowStockItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'success' => true,
    'pending_orders' => $pendingOrders,
    'pending_count' => count($pendingOrders),
    'low_stock' => $lowStockItems,
    'low_stock_count' => count($lowStockItems),
    'total_count' => count($pendingOrders) + count($lowStockItems),
]);
