<?php
// ======================================================
// FOOTER FILE
// ======================================================
?>
    </main>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            <p class="footer-powered">Powered by Arjaymay Sutukil POS System v1.0</p>
        </div>
    </footer>
    
    <!-- Custom JavaScript -->
    <script src="<?php echo SITE_URL; ?>assets/js/script.js"></script>
</body>
</html>